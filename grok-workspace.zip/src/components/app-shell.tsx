import { Link, useRouterState } from "@tanstack/react-router";
import {
  BookOpen,
  Clock3,
  House,
  LayoutGrid,
  ScrollText,
  Search,
} from "lucide-react";
import { cn } from "@/lib/cn";
import { useT } from "@/lib/use-t";
import type { I18nKey } from "@/lib/i18n";

const TABS: { to: string; key: I18nKey; icon: typeof House }[] = [
  { to: "/", key: "home", icon: House },
  { to: "/quran", key: "quran", icon: BookOpen },
  { to: "/prayer", key: "prayer", icon: Clock3 },
  { to: "/adhkar", key: "adhkar", icon: ScrollText },
  { to: "/more", key: "more", icon: LayoutGrid },
];

export function AppShell({ children }: { children: React.ReactNode }) {
  const { t } = useT();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const hideNav =
    pathname.startsWith("/quran/") ||
    pathname.startsWith("/duas/") ||
    pathname.startsWith("/adhkar/");

  return (
    <div className="mx-auto flex min-h-dvh w-full max-w-lg flex-col bg-bg">
      <header className="top-safe sticky top-0 z-20 flex items-center justify-between border-b border-border bg-bg/92 px-4 py-3 backdrop-blur-md">
        <Link to="/" className="text-lg font-medium tracking-tight text-fg">
          {t("appName")}
        </Link>
        <Link
          to="/search"
          aria-label={t("search")}
          className="inline-flex size-11 items-center justify-center rounded-[12px] text-fg"
        >
          <Search className="size-5" strokeWidth={1.75} />
        </Link>
      </header>
      <main className={cn("flex-1 px-4 pb-28 pt-4", hideNav && "pb-8")}>{children}</main>
      {!hideNav ? (
        <nav className="bottom-nav fixed inset-x-0 bottom-0 z-30 mx-auto w-full max-w-lg border-t border-border bg-surface/95 backdrop-blur-md">
          <ul className="grid grid-cols-5">
            {TABS.map((tab) => {
              const active =
                tab.to === "/"
                  ? pathname === "/"
                  : pathname === tab.to || pathname.startsWith(`${tab.to}/`);
              const Icon = tab.icon;
              return (
                <li key={tab.to}>
                  <Link
                    to={tab.to}
                    className={cn(
                      "flex min-h-[64px] flex-col items-center justify-center gap-1 text-[11px]",
                      active ? "text-accent" : "text-muted",
                    )}
                  >
                    <Icon className="size-5" strokeWidth={active ? 2.2 : 1.7} />
                    <span>{t(tab.key)}</span>
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>
      ) : null}
    </div>
  );
}
