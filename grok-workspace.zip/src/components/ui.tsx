import type { ButtonHTMLAttributes, HTMLAttributes, InputHTMLAttributes } from "react";
import { cn } from "@/lib/cn";

export function Button({
  variant = "primary",
  className,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "ghost" | "outline" | "danger";
}) {
  const styles = {
    primary: "bg-accent text-accent-fg hover:opacity-92",
    ghost: "bg-transparent text-fg hover:bg-surface-2",
    outline: "bg-transparent text-fg border border-border-strong hover:bg-surface-2",
    danger: "bg-danger text-fg hover:opacity-92",
  } as const;
  return (
    <button
      className={cn(
        "inline-flex min-h-11 items-center justify-center gap-2 rounded-[12px] px-4 text-sm font-medium transition-opacity duration-150 disabled:opacity-40",
        styles[variant],
        className,
      )}
      {...props}
    />
  );
}

export function Card({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn("rounded-[24px] border border-border bg-surface p-4 shadow-soft", className)}
      {...props}
    />
  );
}

export function Input({ className, ...props }: InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      className={cn(
        "h-11 w-full rounded-[12px] border border-border bg-surface-2 px-3 text-base text-fg outline-none placeholder:text-faint focus:border-border-strong",
        className,
      )}
      {...props}
    />
  );
}

export function SectionTitle({ className, ...props }: HTMLAttributes<HTMLHeadingElement>) {
  return <h2 className={cn("text-sm font-medium text-muted", className)} {...props} />;
}

export function Chip({
  active,
  className,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { active?: boolean }) {
  return (
    <button
      className={cn(
        "inline-flex min-h-10 items-center rounded-full border px-3 text-sm",
        active
          ? "border-accent bg-accent text-accent-fg"
          : "border-border bg-surface-2 text-fg",
        className,
      )}
      {...props}
    />
  );
}

export function Empty({ children }: { children: React.ReactNode }) {
  return (
    <div className="px-6 py-16 text-center text-sm text-muted">{children}</div>
  );
}

export function Spinner() {
  return (
    <div className="flex items-center justify-center py-16" role="status">
      <div className="h-6 w-6 animate-spin rounded-full border-2 border-border-strong border-t-accent" />
    </div>
  );
}
