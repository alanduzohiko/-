import { LANGS } from "@/lib/locale";
import { CITIES, cityName } from "@/lib/cities";
import { useAppStore } from "@/lib/store";
import { useT } from "@/lib/use-t";
import { Button, Card } from "@/components/ui";
import { useState } from "react";

export function Onboarding() {
  const { t, lang } = useT();
  const setLang = useAppStore((s) => s.setLang);
  const setCityId = useAppStore((s) => s.setCityId);
  const cityId = useAppStore((s) => s.cityId);
  const complete = useAppStore((s) => s.completeOnboarding);
  const [step, setStep] = useState<0 | 1>(0);

  return (
    <div className="mx-auto flex min-h-dvh max-w-lg flex-col bg-bg px-5 py-10">
      <div className="mb-10">
        <p className="text-sm text-muted">{t("appName")}</p>
        <h1 className="mt-2 text-3xl font-medium tracking-tight">{t("chooseLanguage")}</h1>
        <p className="mt-3 max-w-prose text-sm leading-relaxed text-muted">
          {step === 0 ? t("chooseLanguageHint") : t("onboardingCityHint")}
        </p>
      </div>

      {step === 0 ? (
        <div className="grid gap-3">
          {LANGS.map((l) => (
            <button
              key={l.id}
              type="button"
              onClick={() => setLang(l.id)}
              className={`rounded-[20px] border px-4 py-4 text-start ${
                lang === l.id ? "border-accent bg-surface" : "border-border bg-surface-2"
              }`}
            >
              <div className="text-lg">{l.native}</div>
              <div className="mt-1 text-sm text-muted">{l.latin}</div>
            </button>
          ))}
        </div>
      ) : (
        <div className="grid max-h-[55vh] gap-2 overflow-auto pr-1">
          {CITIES.map((c) => (
            <button
              key={c.id}
              type="button"
              onClick={() => setCityId(c.id)}
              className={`rounded-[16px] border px-4 py-3 text-start ${
                cityId === c.id ? "border-accent bg-surface" : "border-border bg-surface-2"
              }`}
            >
              {cityName(c, lang)}
            </button>
          ))}
        </div>
      )}

      <div className="mt-auto flex gap-3 pt-8">
        {step === 1 ? (
          <Button variant="ghost" className="flex-1" onClick={() => setStep(0)}>
            {t("back")}
          </Button>
        ) : null}
        <Button
          className="flex-1"
          onClick={() => {
            if (step === 0) setStep(1);
            else complete();
          }}
        >
          {step === 0 ? t("continue") : t("start")}
        </Button>
      </div>
      <Card className="mt-4 p-3 text-xs leading-relaxed text-muted">{t("preserveNote")}</Card>
    </div>
  );
}
