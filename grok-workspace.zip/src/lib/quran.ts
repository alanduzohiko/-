export type SurahMeta = {
  n: number;
  ayahs: number;
  rev: "M" | "D";
  ar: string;
  en: string;
  enMean: string;
  ku: string;
};

type Cache = {
  meta: SurahMeta[] | null;
  ar: string[][] | null;
  ku: string[][] | null;
  en: string[][] | null;
};

const cache: Cache = { meta: null, ar: null, ku: null, en: null };

async function loadJson<T>(path: string): Promise<T> {
  const res = await fetch(path);
  if (!res.ok) throw new Error(`Failed ${path}`);
  return (await res.json()) as T;
}

export async function loadMeta(): Promise<SurahMeta[]> {
  if (cache.meta) return cache.meta;
  const data = await loadJson<{ surahs: SurahMeta[] }>("/data/quran-meta.json");
  cache.meta = data.surahs;
  return cache.meta;
}

export async function loadArabic(): Promise<string[][]> {
  if (cache.ar) return cache.ar;
  cache.ar = await loadJson<string[][]>("/data/quran-ar.json");
  return cache.ar;
}

export async function loadKu(): Promise<string[][]> {
  if (cache.ku) return cache.ku;
  cache.ku = await loadJson<string[][]>("/data/quran-ku.json");
  return cache.ku;
}

export async function loadEn(): Promise<string[][]> {
  if (cache.en) return cache.en;
  cache.en = await loadJson<string[][]>("/data/quran-en.json");
  return cache.en;
}

export function globalAyahIndex(surah: number, ayah: number, meta: SurahMeta[]): number {
  let n = 0;
  for (const s of meta) {
    if (s.n < surah) n += s.ayahs;
  }
  return n + ayah; // 1-based
}

export function reciterAudioUrl(reciter: string, globalIndex: number): string {
  return `https://cdn.islamic.network/quran/audio/128/${reciter}/${globalIndex}.mp3`;
}

export function surahAudioUrl(reciter: string, surah: number): string {
  return `https://cdn.islamic.network/quran/audio-surah/128/${reciter}/${surah}.mp3`;
}

export function surahDisplayName(s: SurahMeta, lang: "ku" | "ar" | "en"): string {
  if (lang === "ku") return s.ku;
  if (lang === "ar") return s.ar.replace(/^سُورَةُ\s*/, "");
  return s.en;
}
