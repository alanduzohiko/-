let audio: HTMLAudioElement | null = null;

function getAudio() {
  if (typeof window === "undefined") return null;
  if (!audio) {
    audio = new Audio();
    audio.preload = "none";
  }
  return audio;
}

export async function playUrl(url: string): Promise<void> {
  const el = getAudio();
  if (!el) throw new Error("no audio");
  if (el.src !== url) {
    el.src = url;
  }
  await el.play();
}

export function pauseAudio() {
  getAudio()?.pause();
}

export function stopAudio() {
  const el = getAudio();
  if (!el) return;
  el.pause();
  el.currentTime = 0;
}

export function onAudioEnded(cb: () => void) {
  const el = getAudio();
  if (!el) return () => {};
  const handler = () => cb();
  el.addEventListener("ended", handler);
  return () => el.removeEventListener("ended", handler);
}

export function isPlaying(): boolean {
  const el = getAudio();
  return !!el && !el.paused && !el.ended;
}
