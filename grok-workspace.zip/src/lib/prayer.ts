import {
  CalculationMethod,
  Coordinates,
  Madhab,
  Prayer,
  PrayerTimes,
  Qibla,
  SunnahTimes,
} from "adhan";
import type { CalcMethod, Madhab as MadhabPref } from "./store";

export type PrayerId = "fajr" | "sunrise" | "dhuhr" | "asr" | "maghrib" | "isha";

export const PRAYER_ORDER: PrayerId[] = ["fajr", "sunrise", "dhuhr", "asr", "maghrib", "isha"];

function paramsFor(method: CalcMethod, madhab: MadhabPref) {
  const factory =
    method === "Egyptian"
      ? CalculationMethod.Egyptian
      : method === "UmmAlQura"
        ? CalculationMethod.UmmAlQura
        : method === "Karachi"
          ? CalculationMethod.Karachi
          : method === "NorthAmerica"
            ? CalculationMethod.NorthAmerica
            : method === "Tehran"
              ? CalculationMethod.Tehran
              : method === "Turkey"
                ? CalculationMethod.Turkey
                : CalculationMethod.MuslimWorldLeague;
  const p = factory();
  p.madhab = madhab === "hanafi" ? Madhab.Hanafi : Madhab.Shafi;
  return p;
}

export function computePrayerTimes(
  lat: number,
  lng: number,
  date: Date,
  method: CalcMethod,
  madhab: MadhabPref,
): Record<PrayerId, Date> {
  const coords = new Coordinates(lat, lng);
  const pt = new PrayerTimes(coords, date, paramsFor(method, madhab));
  return {
    fajr: pt.fajr,
    sunrise: pt.sunrise,
    dhuhr: pt.dhuhr,
    asr: pt.asr,
    maghrib: pt.maghrib,
    isha: pt.isha,
  };
}

export function nextPrayer(
  times: Record<PrayerId, Date>,
  now = new Date(),
): { id: PrayerId; at: Date } | null {
  for (const id of PRAYER_ORDER) {
    if (id === "sunrise") continue;
    if (times[id].getTime() > now.getTime()) return { id, at: times[id] };
  }
  return null;
}

export function currentPrayer(
  times: Record<PrayerId, Date>,
  now = new Date(),
): PrayerId | null {
  const seq: PrayerId[] = ["fajr", "dhuhr", "asr", "maghrib", "isha"];
  let cur: PrayerId | null = null;
  for (const id of seq) {
    if (now.getTime() >= times[id].getTime()) cur = id;
  }
  return cur;
}

export function qiblaBearing(lat: number, lng: number): number {
  return Qibla(new Coordinates(lat, lng));
}

export function sunnahTimes(lat: number, lng: number, date: Date, method: CalcMethod, madhab: MadhabPref) {
  const coords = new Coordinates(lat, lng);
  const pt = new PrayerTimes(coords, date, paramsFor(method, madhab));
  const s = new SunnahTimes(pt);
  return { middleOfTheNight: s.middleOfTheNight, lastThird: s.lastThirdOfTheNight };
}

export { Prayer };
