import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import type { Lang } from "./locale";
import { CITIES } from "./cities";

export type Theme = "dark" | "light";
export type TranslationMode = "none" | "ku" | "en";
export type ReciterId = "ar.alafasy" | "ar.husary" | "ar.minshawi";
export type CalcMethod =
  | "MuslimWorldLeague"
  | "Egyptian"
  | "UmmAlQura"
  | "Karachi"
  | "NorthAmerica"
  | "Tehran"
  | "Turkey";
export type Madhab = "shafi" | "hanafi";

export type AyahBookmark = { kind: "ayah"; surah: number; ayah: number };
export type DuaBookmark = { kind: "dua"; id: string };
export type Bookmark = AyahBookmark | DuaBookmark;

export type LastRead = { surah: number; ayah: number; at: number };

type State = {
  hydrated: boolean;
  onboarded: boolean;
  lang: Lang;
  theme: Theme;
  cityId: string;
  customLat: number | null;
  customLng: number | null;
  customLabel: string | null;
  method: CalcMethod;
  madhab: Madhab;
  translation: TranslationMode;
  reciter: ReciterId;
  quranScale: number;
  uiScale: number;
  notifications: boolean;
  bookmarks: Bookmark[];
  lastRead: LastRead | null;
  tasbihCount: number;
  tasbihTarget: number;
  adhkarProgress: Record<string, number>;
  setHydrated: (v: boolean) => void;
  completeOnboarding: () => void;
  setLang: (lang: Lang) => void;
  setTheme: (theme: Theme) => void;
  setCityId: (id: string) => void;
  setCustomLocation: (lat: number, lng: number, label: string) => void;
  clearCustomLocation: () => void;
  setMethod: (m: CalcMethod) => void;
  setMadhab: (m: Madhab) => void;
  setTranslation: (t: TranslationMode) => void;
  setReciter: (r: ReciterId) => void;
  setQuranScale: (n: number) => void;
  setUiScale: (n: number) => void;
  setNotifications: (v: boolean) => void;
  toggleBookmark: (b: Bookmark) => void;
  isBookmarked: (b: Bookmark) => boolean;
  setLastRead: (surah: number, ayah: number) => void;
  bumpTasbih: () => void;
  resetTasbih: () => void;
  setTasbihTarget: (n: number) => void;
  setAdhkarProgress: (id: string, n: number) => void;
  resetAdhkarProgress: (ids: string[]) => void;
};

function bookmarkKey(b: Bookmark): string {
  return b.kind === "ayah" ? `a:${b.surah}:${b.ayah}` : `d:${b.id}`;
}

export const useAppStore = create<State>()(
  persist(
    (set, get) => ({
      hydrated: false,
      onboarded: false,
      lang: "ku",
      theme: "dark",
      cityId: "erbil",
      customLat: null,
      customLng: null,
      customLabel: null,
      method: "MuslimWorldLeague",
      madhab: "shafi",
      translation: "ku",
      reciter: "ar.alafasy",
      quranScale: 1,
      uiScale: 1,
      notifications: false,
      bookmarks: [],
      lastRead: null,
      tasbihCount: 0,
      tasbihTarget: 33,
      adhkarProgress: {},
      setHydrated: (v) => set({ hydrated: v }),
      completeOnboarding: () => set({ onboarded: true }),
      setLang: (lang) => set({ lang }),
      setTheme: (theme) => set({ theme }),
      setCityId: (id) =>
        set({
          cityId: id,
          customLat: null,
          customLng: null,
          customLabel: null,
        }),
      setCustomLocation: (lat, lng, label) =>
        set({ customLat: lat, customLng: lng, customLabel: label, cityId: "custom" }),
      clearCustomLocation: () =>
        set({ customLat: null, customLng: null, customLabel: null, cityId: "erbil" }),
      setMethod: (method) => set({ method }),
      setMadhab: (madhab) => set({ madhab }),
      setTranslation: (translation) => set({ translation }),
      setReciter: (reciter) => set({ reciter }),
      setQuranScale: (quranScale) => set({ quranScale }),
      setUiScale: (uiScale) => set({ uiScale }),
      setNotifications: (notifications) => set({ notifications }),
      toggleBookmark: (b) => {
        const key = bookmarkKey(b);
        const cur = get().bookmarks;
        const exists = cur.some((x) => bookmarkKey(x) === key);
        set({
          bookmarks: exists ? cur.filter((x) => bookmarkKey(x) !== key) : [b, ...cur],
        });
      },
      isBookmarked: (b) => get().bookmarks.some((x) => bookmarkKey(x) === bookmarkKey(b)),
      setLastRead: (surah, ayah) => set({ lastRead: { surah, ayah, at: Date.now() } }),
      bumpTasbih: () => set({ tasbihCount: get().tasbihCount + 1 }),
      resetTasbih: () => set({ tasbihCount: 0 }),
      setTasbihTarget: (tasbihTarget) => set({ tasbihTarget, tasbihCount: 0 }),
      setAdhkarProgress: (id, n) =>
        set({ adhkarProgress: { ...get().adhkarProgress, [id]: n } }),
      resetAdhkarProgress: (ids) => {
        const next = { ...get().adhkarProgress };
        for (const id of ids) delete next[id];
        set({ adhkarProgress: next });
      },
    }),
    {
      name: "mihrab-v1",
      storage: createJSONStorage(() => localStorage),
      skipHydration: true,
      partialize: (s) => ({
        onboarded: s.onboarded,
        lang: s.lang,
        theme: s.theme,
        cityId: s.cityId,
        customLat: s.customLat,
        customLng: s.customLng,
        customLabel: s.customLabel,
        method: s.method,
        madhab: s.madhab,
        translation: s.translation,
        reciter: s.reciter,
        quranScale: s.quranScale,
        uiScale: s.uiScale,
        notifications: s.notifications,
        bookmarks: s.bookmarks,
        lastRead: s.lastRead,
        tasbihCount: s.tasbihCount,
        tasbihTarget: s.tasbihTarget,
        adhkarProgress: s.adhkarProgress,
      }),
    },
  ),
);

export function getActiveCoords(): { lat: number; lng: number; labelKu: string; labelAr: string; labelEn: string } {
  const s = useAppStore.getState();
  if (s.customLat != null && s.customLng != null) {
    const label = s.customLabel ?? "GPS";
    return { lat: s.customLat, lng: s.customLng, labelKu: label, labelAr: label, labelEn: label };
  }
  const city = CITIES.find((c) => c.id === s.cityId) ?? CITIES[0]!;
  return { lat: city.lat, lng: city.lng, labelKu: city.ku, labelAr: city.ar, labelEn: city.en };
}
