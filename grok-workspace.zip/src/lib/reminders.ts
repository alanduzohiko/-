import { t } from "./i18n";
import { computePrayerTimes, nextPrayer } from "./prayer";
import { getActiveCoords, useAppStore } from "./store";

const KEY = "mihrab-notified";

export function startPrayerReminders(): () => void {
  const tick = () => {
    const s = useAppStore.getState();
    if (!s.notifications || typeof Notification === "undefined" || Notification.permission !== "granted") return;
    const coords = getActiveCoords();
    const now = new Date();
    const times = computePrayerTimes(coords.lat, coords.lng, now, s.method, s.madhab);
    const upcoming = nextPrayer(times, now);
    if (!upcoming) return;
    const diff = upcoming.at.getTime() - now.getTime();
    if (diff > 90_000 || diff < 0) return;
    const stamp = `${now.toDateString()}-${upcoming.id}`;
    if (sessionStorage.getItem(KEY) === stamp) return;
    sessionStorage.setItem(KEY, stamp);
    const name = t(s.lang, upcoming.id === "sunrise" ? "sunrise" : upcoming.id);
    try {
      new Notification(t(s.lang, "appName"), { body: `${t(s.lang, "nextPrayer")}: ${name}` });
    } catch {
      /* ignore */
    }
  };
  tick();
  const id = window.setInterval(tick, 30000);
  return () => window.clearInterval(id);
}
