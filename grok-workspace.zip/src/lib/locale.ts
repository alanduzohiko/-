export type Lang = "ku" | "ar" | "en";

export const LANGS: { id: Lang; native: string; latin: string; dir: "rtl" | "ltr"; html: string }[] = [
  { id: "ku", native: "کوردی (سۆرانی)", latin: "Sorani Kurdish", dir: "rtl", html: "ckb" },
  { id: "ar", native: "العربية", latin: "Arabic", dir: "rtl", html: "ar" },
  { id: "en", native: "English", latin: "English", dir: "ltr", html: "en" },
];

export function isRtl(lang: Lang): boolean {
  return lang !== "en";
}

export function htmlLang(lang: Lang): string {
  return LANGS.find((l) => l.id === lang)?.html ?? "ckb";
}

const ARABIC_DIGITS = "٠١٢٣٤٥٦٧٨٩";

export function formatNumber(n: number | string, lang: Lang): string {
  const s = String(n);
  if (lang === "en") return s;
  return s.replace(/[0-9]/g, (d) => ARABIC_DIGITS[Number(d)] ?? d);
}

export function pad2(n: number): string {
  return n < 10 ? `0${n}` : String(n);
}

export function formatClock(date: Date, lang: Lang): string {
  const h = date.getHours();
  const m = date.getMinutes();
  if (lang === "en") {
    const ap = h >= 12 ? "PM" : "AM";
    const hr = h % 12 || 12;
    return `${hr}:${pad2(m)} ${ap}`;
  }
  return `${formatNumber(pad2(h), lang)}:${formatNumber(pad2(m), lang)}`;
}

export function formatDuration(ms: number, lang: Lang, t: (k: "hour" | "minute") => string): string {
  if (ms < 0) ms = 0;
  const totalMin = Math.floor(ms / 60000);
  const h = Math.floor(totalMin / 60);
  const m = totalMin % 60;
  if (h <= 0) return `${formatNumber(m, lang)} ${t("minute")}`;
  return `${formatNumber(h, lang)} ${t("hour")} ${formatNumber(m, lang)} ${t("minute")}`;
}

const HIJRI_MONTHS: Record<Lang, string[]> = {
  ku: [
    "محەڕەم",
    "سەفەر",
    "ڕەبیعولئەووەل",
    "ڕەبیعولئاخیر",
    "جومادالئوولا",
    "جومادالئاخیرە",
    "ڕەجەب",
    "شەعبان",
    "ڕەمەزان",
    "شەووال",
    "زولقەعدە",
    "زولحیججە",
  ],
  ar: [
    "محرم",
    "صفر",
    "ربيع الأول",
    "ربيع الآخر",
    "جمادى الأولى",
    "جمادى الآخرة",
    "رجب",
    "شعبان",
    "رمضان",
    "شوال",
    "ذو القعدة",
    "ذو الحجة",
  ],
  en: [
    "Muharram",
    "Safar",
    "Rabi' al-Awwal",
    "Rabi' al-Thani",
    "Jumada al-Ula",
    "Jumada al-Akhirah",
    "Rajab",
    "Sha'ban",
    "Ramadan",
    "Shawwal",
    "Dhul-Qa'dah",
    "Dhul-Hijjah",
  ],
};

const GREG_MONTHS: Record<Lang, string[]> = {
  ku: ["کانوونی دووەم","شوبات","ئازار","نیسان","ئایار","حوزەیران","تەممووز","ئاب","ئەیلوول","تشرینی یەکەم","تشرینی دووەم","کانوونی یەکەم"],
  ar: ["يناير","فبراير","مارس","أبريل","مايو","يونيو","يوليو","أغسطس","سبتمبر","أكتوبر","نوفمبر","ديسمبر"],
  en: ["January","February","March","April","May","June","July","August","September","October","November","December"],
};

const WEEKDAYS: Record<Lang, string[]> = {
  ku: ["یەکشەممە","دووشەممە","سێشەممە","چوارشەممە","پێنجشەممە","هەینی","شەممە"],
  ar: ["الأحد","الاثنين","الثلاثاء","الأربعاء","الخميس","الجمعة","السبت"],
  en: ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],
};

export function weekdayName(date: Date, lang: Lang): string {
  return WEEKDAYS[lang][date.getDay()] ?? "";
}

export function formatGregorian(date: Date, lang: Lang): string {
  const d = date.getDate();
  const m = GREG_MONTHS[lang][date.getMonth()];
  const y = date.getFullYear();
  return `${formatNumber(d, lang)} ${m} ${formatNumber(y, lang)}`;
}

export function formatHijri(date: Date, lang: Lang): string {
  try {
    const parts = new Intl.DateTimeFormat("en-u-ca-islamic-umalqura", {
      day: "numeric",
      month: "numeric",
      year: "numeric",
    }).formatToParts(date);
    const day = Number(parts.find((p) => p.type === "day")?.value ?? "1");
    const month = Number(parts.find((p) => p.type === "month")?.value ?? "1");
    const year = Number(parts.find((p) => p.type === "year")?.value ?? "1447");
    const monthName = HIJRI_MONTHS[lang][month - 1] ?? "";
    return `${formatNumber(day, lang)} ${monthName} ${formatNumber(year, lang)}`;
  } catch {
    return "";
  }
}
