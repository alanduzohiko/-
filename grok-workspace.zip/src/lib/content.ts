export type DailyDhikr = {
  id: string;
  order: number;
  ar: string;
  en: string;
  ku: string;
  count: number;
  countAr: string;
  countEn: string;
  countKu: string;
  fadlAr: string;
  fadlEn: string;
  sourceAr: string;
  sourceEn: string;
  type: number;
  audio: string;
};

export type HisnItem = {
  id: string;
  ar: string;
  ku: string;
  en: string;
  texts: string[];
  notes: string[];
};

let daily: DailyDhikr[] | null = null;
let hisn: HisnItem[] | null = null;

async function loadJson<T>(path: string): Promise<T> {
  const res = await fetch(path);
  if (!res.ok) throw new Error(`Failed ${path}`);
  return (await res.json()) as T;
}

export async function loadDaily(): Promise<DailyDhikr[]> {
  if (daily) return daily;
  daily = await loadJson<DailyDhikr[]>("/data/adhkar-daily.json");
  return daily;
}

export async function loadHisn(): Promise<HisnItem[]> {
  if (hisn) return hisn;
  hisn = await loadJson<HisnItem[]>("/data/hisn.json");
  return hisn;
}

export function filterDaily(items: DailyDhikr[], which: "morning" | "evening"): DailyDhikr[] {
  return items.filter((x) => x.type === 0 || (which === "morning" ? x.type === 1 : x.type === 2));
}

export function findHisn(list: HisnItem[], arabicTitle: string): HisnItem | undefined {
  return list.find((x) => x.ar === arabicTitle);
}

export const FEATURED_HISN: { key: "afterPrayer" | "sleepAdhkar" | "wakeAdhkar"; ar: string }[] = [
  { key: "afterPrayer", ar: "الأذكار بعد السلام من الصلاة" },
  { key: "sleepAdhkar", ar: "أذكار النوم" },
  { key: "wakeAdhkar", ar: "أذكار الاستيقاظ من النوم" },
];
