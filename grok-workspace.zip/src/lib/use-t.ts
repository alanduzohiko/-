import { t, type I18nKey } from "./i18n";
import { useAppStore } from "./store";

export function useT() {
  const lang = useAppStore((s) => s.lang);
  return {
    lang,
    t: (key: I18nKey) => t(lang, key),
  };
}
