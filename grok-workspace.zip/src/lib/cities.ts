export type City = {
  id: string;
  ku: string;
  ar: string;
  en: string;
  lat: number;
  lng: number;
  tz: string;
};

export const CITIES: City[] = [
  { id: "erbil", ku: "هەولێر", ar: "أربيل", en: "Erbil", lat: 36.1911, lng: 44.0094, tz: "Asia/Baghdad" },
  { id: "slemani", ku: "سلێمانی", ar: "السليمانية", en: "Sulaymaniyah", lat: 35.5616, lng: 45.4376, tz: "Asia/Baghdad" },
  { id: "duhok", ku: "دهۆک", ar: "دهوك", en: "Duhok", lat: 36.8674, lng: 42.9884, tz: "Asia/Baghdad" },
  { id: "kirkuk", ku: "کەرکووک", ar: "كركوك", en: "Kirkuk", lat: 35.4681, lng: 44.3922, tz: "Asia/Baghdad" },
  { id: "halabja", ku: "هەڵەبجە", ar: "حلبجة", en: "Halabja", lat: 35.1778, lng: 45.9861, tz: "Asia/Baghdad" },
  { id: "zakho", ku: "زاخۆ", ar: "زاخو", en: "Zakho", lat: 37.1441, lng: 42.6855, tz: "Asia/Baghdad" },
  { id: "ranya", ku: "ڕانیە", ar: "رانية", en: "Ranya", lat: 36.255, lng: 44.882, tz: "Asia/Baghdad" },
  { id: "koya", ku: "کۆیە", ar: "كويسنجق", en: "Koya", lat: 36.0828, lng: 44.6278, tz: "Asia/Baghdad" },
  { id: "baghdad", ku: "بەغدا", ar: "بغداد", en: "Baghdad", lat: 33.3152, lng: 44.3661, tz: "Asia/Baghdad" },
  { id: "mosul", ku: "مووسڵ", ar: "الموصل", en: "Mosul", lat: 36.335, lng: 43.1189, tz: "Asia/Baghdad" },
  { id: "basra", ku: "بەسرە", ar: "البصرة", en: "Basra", lat: 30.5085, lng: 47.7804, tz: "Asia/Baghdad" },
  { id: "najaf", ku: "نەجەف", ar: "النجف", en: "Najaf", lat: 32.0, lng: 44.3356, tz: "Asia/Baghdad" },
  { id: "karbala", ku: "کەربەلا", ar: "كربلاء", en: "Karbala", lat: 32.616, lng: 44.0243, tz: "Asia/Baghdad" },
  { id: "makkah", ku: "مەککە", ar: "مكة المكرمة", en: "Makkah", lat: 21.4225, lng: 39.8262, tz: "Asia/Riyadh" },
  { id: "madinah", ku: "مەدینە", ar: "المدينة المنورة", en: "Madinah", lat: 24.4672, lng: 39.6111, tz: "Asia/Riyadh" },
  { id: "istanbul", ku: "ئیستەنبوڵ", ar: "إسطنبول", en: "Istanbul", lat: 41.0082, lng: 28.9784, tz: "Europe/Istanbul" },
  { id: "tehran", ku: "تاران", ar: "طهران", en: "Tehran", lat: 35.6892, lng: 51.389, tz: "Asia/Tehran" },
  { id: "amman", ku: "عەممان", ar: "عمّان", en: "Amman", lat: 31.9539, lng: 35.9106, tz: "Asia/Amman" },
  { id: "cairo", ku: "قاهیرە", ar: "القاهرة", en: "Cairo", lat: 30.0444, lng: 31.2357, tz: "Africa/Cairo" },
  { id: "london", ku: "لەندەن", ar: "لندن", en: "London", lat: 51.5074, lng: -0.1278, tz: "Europe/London" },
];

export function cityName(city: City, lang: "ku" | "ar" | "en"): string {
  return city[lang];
}

export function findCity(id: string): City {
  return CITIES.find((c) => c.id === id) ?? CITIES[0]!;
}
