import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Input, SectionTitle, Spinner } from "@/components/ui";
import { loadArabic, loadEn, loadKu, loadMeta, surahDisplayName, type SurahMeta } from "@/lib/quran";
import { loadHisn, type HisnItem } from "@/lib/content";
import { ASMA } from "@/lib/asma";
import { useAppStore } from "@/lib/store";
import { useT } from "@/lib/use-t";
import { formatNumber } from "@/lib/locale";

export const Route = createFileRoute("/search")({ component: SearchPage });

type AyahHit = { surah: number; ayah: number; ar: string; tr?: string; name: string };
type DuaHit = { id: string; title: string; snippet: string };

function SearchPage() {
  const { t, lang } = useT();
  const translation = useAppStore((s) => s.translation);
  const [q, setQ] = useState("");
  const [ready, setReady] = useState(false);
  const [meta, setMeta] = useState<SurahMeta[]>([]);
  const [ar, setAr] = useState<string[][]>([]);
  const [tr, setTr] = useState<string[][] | null>(null);
  const [hisn, setHisn] = useState<HisnItem[]>([]);
  const [ayahHits, setAyahHits] = useState<AyahHit[]>([]);
  const [duaHits, setDuaHits] = useState<DuaHit[]>([]);
  const [nameHits, setNameHits] = useState<typeof ASMA>([]);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    void (async () => {
      const [m, a, h] = await Promise.all([loadMeta(), loadArabic(), loadHisn()]);
      setMeta(m);
      setAr(a);
      setHisn(h);
      setReady(true);
    })();
  }, []);

  useEffect(() => {
    if (translation === "none") {
      setTr(null);
      return;
    }
    void (translation === "ku" ? loadKu() : loadEn()).then(setTr);
  }, [translation]);

  useEffect(() => {
    const s = q.trim();
    if (s.length < 2) {
      setAyahHits([]);
      setDuaHits([]);
      setNameHits([]);
      return;
    }
    setBusy(true);
    const id = window.setTimeout(() => {
      const low = s.toLowerCase();
      const ayahs: AyahHit[] = [];
      outer: for (let si = 0; si < ar.length; si++) {
        const verses = ar[si] ?? [];
        for (let ai = 0; ai < verses.length; ai++) {
          const text = verses[ai] ?? "";
          const meaning = tr?.[si]?.[ai] ?? "";
          if (text.includes(s) || meaning.toLowerCase().includes(low)) {
            const surah = meta[si];
            ayahs.push({
              surah: si + 1,
              ayah: ai + 1,
              ar: text,
              tr: meaning || undefined,
              name: surah ? surahDisplayName(surah, lang) : String(si + 1),
            });
            if (ayahs.length >= 30) break outer;
          }
        }
      }
      const duas: DuaHit[] = [];
      for (const item of hisn) {
        const title = lang === "ku" ? item.ku : lang === "ar" ? item.ar : item.en;
        const blob = `${item.ar} ${item.ku} ${item.en} ${item.texts.join(" ")}`;
        if (blob.toLowerCase().includes(low) || blob.includes(s)) {
          duas.push({ id: item.id, title, snippet: item.texts[0] ?? item.ar });
          if (duas.length >= 20) break;
        }
      }
      const names = ASMA.filter(
        (n) => n.ar.includes(s) || n.ku.includes(s) || n.en.toLowerCase().includes(low) || n.tr.toLowerCase().includes(low),
      ).slice(0, 12);
      setAyahHits(ayahs);
      setDuaHits(duas);
      setNameHits(names);
      setBusy(false);
    }, 180);
    return () => window.clearTimeout(id);
  }, [q, ar, tr, hisn, meta, lang]);

  if (!ready) return <Spinner />;

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-medium">{t("search")}</h1>
      <Input
        value={q}
        onChange={(e) => setQ(e.target.value)}
        placeholder={t("searchPlaceholder")}
        autoFocus
      />
      {q.trim().length < 2 ? <p className="text-sm text-muted">{t("emptySearch")}</p> : null}
      {busy ? <p className="text-xs text-faint">{t("loading")}</p> : null}
      {q.trim().length >= 2 && !busy && !ayahHits.length && !duaHits.length && !nameHits.length ? (
        <p className="text-sm text-muted">{t("noResults")}</p>
      ) : null}

      {ayahHits.length ? (
        <section>
          <SectionTitle className="mb-2">
            {t("inQuran")} · {formatNumber(ayahHits.length, lang)}
          </SectionTitle>
          <ul className="space-y-2">
            {ayahHits.map((h) => (
              <li key={`${h.surah}:${h.ayah}`}>
                <Link
                  to="/quran/$n"
                  params={{ n: String(h.surah) }}
                  search={{ ayah: h.ayah }}
                  className="block rounded-[16px] border border-border bg-surface p-3"
                >
                  <p className="text-xs text-muted">
                    {h.name} · {t("ayah")} {formatNumber(h.ayah, lang)}
                  </p>
                  <p className="font-quran mt-1 line-clamp-2" dir="rtl">
                    {h.ar}
                  </p>
                </Link>
              </li>
            ))}
          </ul>
        </section>
      ) : null}

      {duaHits.length ? (
        <section>
          <SectionTitle className="mb-2">{t("inDuas")}</SectionTitle>
          <ul className="space-y-2">
            {duaHits.map((h) => (
              <li key={h.id}>
                <Link to="/duas/$id" params={{ id: h.id }} className="block rounded-[16px] border border-border bg-surface p-3">
                  <p className="font-medium">{h.title}</p>
                  <p className="font-quran mt-1 line-clamp-2 text-sm" dir="rtl">
                    {h.snippet}
                  </p>
                </Link>
              </li>
            ))}
          </ul>
        </section>
      ) : null}

      {nameHits.length ? (
        <section>
          <SectionTitle className="mb-2">{t("inNames")}</SectionTitle>
          <ul className="space-y-2">
            {nameHits.map((n) => (
              <li key={n.n} className="rounded-[16px] border border-border bg-surface p-3">
                <p className="font-quran text-xl" dir="rtl">
                  {n.ar}
                </p>
                <p className="text-sm text-muted">{lang === "ku" ? n.ku : lang === "ar" ? n.tr : n.en}</p>
              </li>
            ))}
          </ul>
        </section>
      ) : null}
    </div>
  );
}
