import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Bookmark, BookmarkCheck, ChevronLeft, ChevronRight, Copy } from "lucide-react";
import { toast } from "sonner";
import { Card, Spinner } from "@/components/ui";
import { loadHisn, type HisnItem } from "@/lib/content";
import { useAppStore } from "@/lib/store";
import { useT } from "@/lib/use-t";
import { isRtl } from "@/lib/locale";

export const Route = createFileRoute("/duas/$id")({ component: DuaDetail });

function DuaDetail() {
  const { id } = Route.useParams();
  const { t, lang } = useT();
  const [item, setItem] = useState<HisnItem | null | undefined>(undefined);
  const toggle = useAppStore((s) => s.toggleBookmark);
  const saved = useAppStore((s) => s.bookmarks.some((b) => b.kind === "dua" && b.id === id));
  const rtl = isRtl(lang);

  useEffect(() => {
    void loadHisn().then((list) => setItem(list.find((x) => x.id === id) ?? null));
  }, [id]);

  if (item === undefined) return <Spinner />;
  if (!item) return <p className="text-sm text-muted">{t("nothingHere")}</p>;

  const title = lang === "ku" ? item.ku : lang === "ar" ? item.ar : item.en;

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Link to="/duas" className="inline-flex size-11 items-center justify-center" aria-label={t("back")}>
          {rtl ? <ChevronRight className="size-5" /> : <ChevronLeft className="size-5" />}
        </Link>
        <h1 className="flex-1 text-lg font-medium">{title}</h1>
        <button
          type="button"
          className="size-11"
          aria-label={saved ? t("removeBookmark") : t("addBookmark")}
          onClick={() => {
            toggle({ kind: "dua", id });
            toast.success(saved ? t("bookmarkRemoved") : t("bookmarkAdded"));
          }}
        >
          {saved ? <BookmarkCheck className="size-5 text-accent" /> : <Bookmark className="size-5" />}
        </button>
      </div>
      {lang !== "ar" ? (
        <p className="text-sm text-muted" dir="rtl">
          {item.ar}
        </p>
      ) : (
        <p className="text-sm text-muted">{item.en}</p>
      )}
      {item.texts.map((text, i) => (
        <Card key={i} className="p-4">
          <p className="font-quran text-xl leading-loose" dir="rtl">
            {text}
          </p>
          <button
            type="button"
            className="mt-3 inline-flex items-center gap-2 text-sm text-muted"
            onClick={async () => {
              await navigator.clipboard.writeText(text);
              toast.success(t("copied"));
            }}
          >
            <Copy className="size-4" />
            {t("copy")}
          </button>
        </Card>
      ))}
      {item.notes.map((n, i) => (
        <p key={i} className="text-sm leading-relaxed text-muted" dir="rtl">
          {n}
        </p>
      ))}
    </div>
  );
}
