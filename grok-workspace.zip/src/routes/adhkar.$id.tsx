import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Button, Card, Spinner } from "@/components/ui";
import { FEATURED_HISN, filterDaily, loadDaily, loadHisn, type DailyDhikr, type HisnItem } from "@/lib/content";
import { useAppStore } from "@/lib/store";
import { useT } from "@/lib/use-t";
import { formatNumber, isRtl } from "@/lib/locale";
import { cn } from "@/lib/cn";

export const Route = createFileRoute("/adhkar/$id")({ component: AdhkarDetail });

function AdhkarDetail() {
  const { id } = Route.useParams();
  const { t, lang } = useT();
  const progress = useAppStore((s) => s.adhkarProgress);
  const setProgress = useAppStore((s) => s.setAdhkarProgress);
  const reset = useAppStore((s) => s.resetAdhkarProgress);
  const [daily, setDaily] = useState<DailyDhikr[] | null>(null);
  const [hisn, setHisn] = useState<HisnItem | null | undefined>(undefined);

  useEffect(() => {
    if (id === "morning" || id === "evening") {
      void loadDaily().then(setDaily);
    } else {
      const map: Record<string, string> = {
        after: FEATURED_HISN[0]!.ar,
        sleep: FEATURED_HISN[1]!.ar,
        wake: FEATURED_HISN[2]!.ar,
      };
      void loadHisn().then((list) => {
        const title = map[id];
        setHisn(title ? list.find((x) => x.ar === title) ?? null : list.find((x) => x.id === id) ?? null);
      });
    }
  }, [id]);

  const items = useMemo(() => {
    if (!daily) return [];
    if (id === "morning") return filterDaily(daily, "morning");
    if (id === "evening") return filterDaily(daily, "evening");
    return [];
  }, [daily, id]);

  const title =
    id === "morning"
      ? t("morningAdhkar")
      : id === "evening"
        ? t("eveningAdhkar")
        : id === "after"
          ? t("afterPrayer")
          : id === "sleep"
            ? t("sleepAdhkar")
            : id === "wake"
              ? t("wakeAdhkar")
              : hisn
                ? lang === "ku"
                  ? hisn.ku
                  : lang === "ar"
                    ? hisn.ar
                    : hisn.en
                : t("adhkar");

  const ids = items.map((x) => x.id);
  const rtl = isRtl(lang);

  if ((id === "morning" || id === "evening") && !daily) return <Spinner />;
  if (id !== "morning" && id !== "evening" && hisn === undefined) return <Spinner />;

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Link to="/adhkar" className="inline-flex size-11 items-center justify-center" aria-label={t("back")}>
          {rtl ? <ChevronRight className="size-5" /> : <ChevronLeft className="size-5" />}
        </Link>
        <h1 className="text-xl font-medium">{title}</h1>
      </div>

      {items.length ? (
        <>
          <Button variant="outline" className="w-full" onClick={() => reset(ids)}>
            {t("resetProgress")}
          </Button>
          <ul className="space-y-3">
            {items.map((item) => {
              const done = progress[item.id] ?? 0;
              const target = item.count || 1;
              const complete = done >= target;
              return (
                <li key={item.id}>
                  <Card className={cn("p-4", complete && "opacity-70")}>
                    <p className="font-quran text-xl" dir="rtl">
                      {item.ar}
                    </p>
                    {lang !== "ar" ? (
                      <p className="mt-3 text-sm leading-relaxed text-muted">{lang === "ku" ? item.ku : item.en}</p>
                    ) : null}
                    <div className="mt-3 flex items-center justify-between gap-3">
                      <p className="text-xs text-faint">
                        {t("repeat")}: {lang === "ku" ? item.countKu : lang === "ar" ? item.countAr : item.countEn}
                      </p>
                      <button
                        type="button"
                        onClick={() => setProgress(item.id, complete ? 0 : done + 1)}
                        className="min-h-11 min-w-24 rounded-full bg-accent px-4 text-sm font-medium text-accent-fg"
                      >
                        {complete
                          ? t("completed")
                          : `${formatNumber(done, lang)} / ${formatNumber(target, lang)}`}
                      </button>
                    </div>
                    {item.sourceAr ? (
                      <p className="mt-2 text-xs text-faint">
                        {t("source")}: {lang === "en" ? item.sourceEn || item.sourceAr : item.sourceAr}
                      </p>
                    ) : null}
                  </Card>
                </li>
              );
            })}
          </ul>
        </>
      ) : hisn ? (
        <HisnView item={hisn} />
      ) : (
        <p className="text-sm text-muted">{t("nothingHere")}</p>
      )}
    </div>
  );
}

function HisnView({ item }: { item: HisnItem }) {
  const { t, lang } = useT();
  const saved = useAppStore((s) => s.isBookmarked({ kind: "dua", id: item.id }));
  const toggle = useAppStore((s) => s.toggleBookmark);
  return (
    <div className="space-y-3">
      <Button
        variant="outline"
        className="w-full"
        onClick={() => toggle({ kind: "dua", id: item.id })}
      >
        {saved ? t("removeBookmark") : t("addBookmark")}
      </Button>
      {item.texts.map((text, i) => (
        <Card key={i} className="p-4">
          <p className="font-quran text-xl leading-loose" dir="rtl">
            {text}
          </p>
        </Card>
      ))}
      {item.notes.length ? (
        <Card className="p-4">
          <p className="text-xs text-muted">{t("notes")}</p>
          {item.notes.map((n, i) => (
            <p key={i} className="mt-2 text-sm leading-relaxed text-muted" dir="rtl">
              {n}
            </p>
          ))}
        </Card>
      ) : null}
      <p className="text-xs text-faint">{lang === "ku" ? item.ku : lang === "en" ? item.en : item.ar}</p>
    </div>
  );
}
