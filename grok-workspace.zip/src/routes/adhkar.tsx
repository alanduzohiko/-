import { createFileRoute, Link } from "@tanstack/react-router";
import { Moon, ScrollText, Sun, Sunrise } from "lucide-react";
import { useT } from "@/lib/use-t";
import { Card, SectionTitle } from "@/components/ui";

export const Route = createFileRoute("/adhkar")({ component: AdhkarHome });

function AdhkarHome() {
  const { t } = useT();
  const items = [
    { to: "/adhkar/morning", label: t("morningAdhkar"), icon: Sun, hint: t("morning") },
    { to: "/adhkar/evening", label: t("eveningAdhkar"), icon: Moon, hint: t("evening") },
    { to: "/adhkar/after", label: t("afterPrayer"), icon: Sunrise, hint: t("afterPrayerShort") },
    { to: "/adhkar/sleep", label: t("sleepAdhkar"), icon: Moon, hint: t("night") },
    { to: "/adhkar/wake", label: t("wakeAdhkar"), icon: Sunrise, hint: t("morning") },
    { to: "/duas", label: t("fortress"), icon: ScrollText, hint: t("allCategories") },
  ];
  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-medium">{t("adhkar")}</h1>
        <p className="mt-1 text-sm text-muted">{t("collections")}</p>
      </div>
      <div className="grid gap-3">
        {items.map((it) => {
          const Icon = it.icon;
          return (
            <Link key={it.to} to={it.to}>
              <Card className="flex items-center gap-4 p-4">
                <span className="flex size-11 items-center justify-center rounded-[12px] bg-surface-2 text-accent">
                  <Icon className="size-5" />
                </span>
                <span className="flex-1">
                  <span className="block font-medium">{it.label}</span>
                  <span className="block text-xs text-muted">{it.hint}</span>
                </span>
              </Card>
            </Link>
          );
        })}
      </div>
      <SectionTitle>{t("tasbih")}</SectionTitle>
      <Link to="/tasbih">
        <Card className="p-4 font-medium">{t("tasbih")}</Card>
      </Link>
    </div>
  );
}
