import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { BookOpen, Compass, Moon, ScrollText, Sun, Hash } from "lucide-react";
import { Card, SectionTitle } from "@/components/ui";
import { useAppStore, getActiveCoords } from "@/lib/store";
import { useT } from "@/lib/use-t";
import { computePrayerTimes, nextPrayer, type PrayerId } from "@/lib/prayer";
import { formatClock, formatDuration, formatGregorian, formatHijri, weekdayName } from "@/lib/locale";
import { t as tr, type I18nKey } from "@/lib/i18n";
import { loadMeta, loadArabic, surahDisplayName } from "@/lib/quran";

export const Route = createFileRoute("/")({ component: Home });

const PRAYER_KEYS: Record<Exclude<PrayerId, "sunrise">, I18nKey> = {
  fajr: "fajr",
  dhuhr: "dhuhr",
  asr: "asr",
  maghrib: "maghrib",
  isha: "isha",
};

function Home() {
  const { t, lang } = useT();
  const method = useAppStore((s) => s.method);
  const madhab = useAppStore((s) => s.madhab);
  const lastRead = useAppStore((s) => s.lastRead);
  const coords = getActiveCoords();
  const [now, setNow] = useState(() => new Date());
  const [verse, setVerse] = useState<{ n: number; ayah: number; ar: string; name: string } | null>(null);

  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 30000);
    return () => clearInterval(id);
  }, []);

  const times = useMemo(
    () => computePrayerTimes(coords.lat, coords.lng, now, method, madhab),
    [coords.lat, coords.lng, method, madhab, now],
  );
  const upcoming = nextPrayer(times, now) ?? { id: "fajr" as const, at: times.fajr };

  useEffect(() => {
    let alive = true;
    void (async () => {
      const [meta, ar] = await Promise.all([loadMeta(), loadArabic()]);
      const day = Math.floor(Date.now() / 86400000);
      const s = meta[day % meta.length]!;
      const ayah = (day % s.ayahs) + 1;
      if (!alive) return;
      setVerse({
        n: s.n,
        ayah,
        ar: ar[s.n - 1]?.[ayah - 1] ?? "",
        name: surahDisplayName(s, lang),
      });
    })();
    return () => {
      alive = false;
    };
  }, [lang]);

  const cityLabel = lang === "ku" ? coords.labelKu : lang === "ar" ? coords.labelAr : coords.labelEn;
  const remain = upcoming.at.getTime() - now.getTime();

  return (
    <div className="space-y-5 rise">
      <div>
        <p className="text-sm text-muted">
          {weekdayName(now, lang)} · {cityLabel}
        </p>
        <h1 className="mt-1 text-2xl font-medium tracking-tight">{t("appName")}</h1>
        <p className="mt-1 text-sm text-muted">{formatHijri(now, lang)}</p>
        <p className="text-sm text-faint">{formatGregorian(now, lang)}</p>
      </div>

      <Card className="p-5">
        <SectionTitle>{t("nextPrayer")}</SectionTitle>
        <div className="mt-2 flex items-end justify-between gap-3">
          <div>
            <p className="text-3xl font-medium tracking-tight">
              {t(PRAYER_KEYS[upcoming.id === "sunrise" ? "fajr" : upcoming.id])}
            </p>
            <p className="mt-1 tabular-nums text-muted">{formatClock(upcoming.at, lang)}</p>
          </div>
          <div className="text-end">
            <p className="text-xs text-faint">{t("remaining")}</p>
            <p className="tabular-nums text-accent">{formatDuration(remain, lang, (k) => t(k))}</p>
          </div>
        </div>
        <Link
          to="/prayer"
          className="mt-4 inline-flex text-sm text-accent"
        >
          {t("todayTimes")}
        </Link>
      </Card>

      {lastRead ? (
        <Link to="/quran/$n" params={{ n: String(lastRead.surah) }} search={{ ayah: lastRead.ayah }}>
          <Card className="flex items-center justify-between p-4">
            <div>
              <SectionTitle>{t("continueReading")}</SectionTitle>
              <p className="mt-1 text-sm">
                {t("surah")} {lastRead.surah} · {t("ayah")} {lastRead.ayah}
              </p>
            </div>
            <BookOpen className="size-5 text-muted" />
          </Card>
        </Link>
      ) : null}

      <div>
        <SectionTitle className="mb-3">{t("quickActions")}</SectionTitle>
        <div className="grid grid-cols-2 gap-3">
          <Quick to="/adhkar/morning" label={t("morningAdhkar")} icon={Sun} />
          <Quick to="/adhkar/evening" label={t("eveningAdhkar")} icon={Moon} />
          <Quick to="/quran" label={t("readQuran")} icon={BookOpen} />
          <Quick to="/qibla" label={t("qibla")} icon={Compass} />
          <Quick to="/duas" label={t("fortress")} icon={ScrollText} />
          <Quick to="/tasbih" label={t("tasbih")} icon={Hash} />
        </div>
      </div>

      {verse ? (
        <Link to="/quran/$n" params={{ n: String(verse.n) }} search={{ ayah: verse.ayah }}>
          <Card className="p-5">
            <SectionTitle>{t("verseOfMoment")}</SectionTitle>
            <p className="font-quran mt-3 text-xl leading-loose" dir="rtl">
              {verse.ar}
            </p>
            <p className="mt-3 text-sm text-muted">
              {verse.name} · {tr(lang, "ayah")} {verse.ayah}
            </p>
          </Card>
        </Link>
      ) : null}
    </div>
  );
}

function Quick({
  to,
  label,
  icon: Icon,
}: {
  to: string;
  label: string;
  icon: typeof BookOpen;
}) {
  return (
    <Link
      to={to}
      className="flex min-h-[88px] flex-col justify-between rounded-[20px] border border-border bg-surface p-4"
    >
      <Icon className="size-5 text-accent" strokeWidth={1.75} />
      <span className="text-sm font-medium">{label}</span>
    </Link>
  );
}
