import { createFileRoute } from "@tanstack/react-router";
import { LANGS } from "@/lib/locale";
import { CITIES, cityName } from "@/lib/cities";
import { useAppStore, type CalcMethod, type ReciterId, type TranslationMode } from "@/lib/store";
import { useT } from "@/lib/use-t";
import { Button, Card, Chip, SectionTitle } from "@/components/ui";
import { toast } from "sonner";
import type { I18nKey } from "@/lib/i18n";

export const Route = createFileRoute("/settings")({ component: SettingsPage });

const METHODS: { id: CalcMethod; key: I18nKey }[] = [
  { id: "MuslimWorldLeague", key: "methodMWL" },
  { id: "Egyptian", key: "methodEgypt" },
  { id: "UmmAlQura", key: "methodUmmAlQura" },
  { id: "Karachi", key: "methodKarachi" },
  { id: "NorthAmerica", key: "methodISNA" },
  { id: "Tehran", key: "methodTehran" },
  { id: "Turkey", key: "methodTurkey" },
];

const RECITERS: { id: ReciterId; key: I18nKey }[] = [
  { id: "ar.alafasy", key: "reciterAlafasy" },
  { id: "ar.husary", key: "reciterHusary" },
  { id: "ar.minshawi", key: "reciterMinshawi" },
];

function SettingsPage() {
  const { t, lang } = useT();
  const store = useAppStore();

  async function enableNotes() {
    if (!("Notification" in window)) {
      toast.error(t("notificationsDenied"));
      return;
    }
    const perm = await Notification.requestPermission();
    if (perm === "granted") {
      store.setNotifications(true);
      toast.success(t("notificationsOn"));
    } else {
      store.setNotifications(false);
      toast.error(t("notificationsDenied"));
    }
  }

  async function detect() {
    toast.message(t("locating"));
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        store.setCustomLocation(pos.coords.latitude, pos.coords.longitude, t("customLocation"));
        toast.success(t("settingsSaved"));
      },
      () => toast.error(t("locationFailed")),
      { enableHighAccuracy: true, timeout: 8000 },
    );
  }

  return (
    <div className="space-y-6 pb-8">
      <h1 className="text-2xl font-medium">{t("settings")}</h1>

      <section>
        <SectionTitle className="mb-2">{t("language")}</SectionTitle>
        <p className="mb-3 text-xs text-muted">{t("languagePersists")}</p>
        <div className="grid gap-2">
          {LANGS.map((l) => (
            <Chip key={l.id} active={lang === l.id} onClick={() => store.setLang(l.id)}>
              {l.native}
            </Chip>
          ))}
        </div>
      </section>

      <section>
        <SectionTitle className="mb-2">{t("theme")}</SectionTitle>
        <div className="flex flex-wrap gap-2">
          <Chip active={store.theme === "dark"} onClick={() => store.setTheme("dark")}>
            {t("themeDark")}
          </Chip>
          <Chip active={store.theme === "light"} onClick={() => store.setTheme("light")}>
            {t("themeLight")}
          </Chip>
        </div>
      </section>

      <section>
        <SectionTitle className="mb-2">{t("city")}</SectionTitle>
        <Button variant="outline" className="mb-3 w-full" onClick={() => void detect()}>
          {t("detectLocation")}
        </Button>
        <div className="grid max-h-56 gap-2 overflow-auto">
          {CITIES.map((c) => (
            <button
              key={c.id}
              type="button"
              onClick={() => store.setCityId(c.id)}
              className={`rounded-[14px] border px-3 py-2 text-start text-sm ${
                store.cityId === c.id && store.customLat == null
                  ? "border-accent bg-surface"
                  : "border-border bg-surface-2"
              }`}
            >
              {cityName(c, lang)}
            </button>
          ))}
        </div>
      </section>

      <section>
        <SectionTitle className="mb-2">{t("calculationMethod")}</SectionTitle>
        <p className="mb-2 text-xs text-muted">{t("methodHelp")}</p>
        <div className="grid gap-2">
          {METHODS.map((m) => (
            <Chip key={m.id} active={store.method === m.id} onClick={() => store.setMethod(m.id)}>
              {t(m.key)}
            </Chip>
          ))}
        </div>
      </section>

      <section>
        <SectionTitle className="mb-2">{t("asrMadhab")}</SectionTitle>
        <div className="flex flex-wrap gap-2">
          <Chip active={store.madhab === "shafi"} onClick={() => store.setMadhab("shafi")}>
            {t("shafi")}
          </Chip>
          <Chip active={store.madhab === "hanafi"} onClick={() => store.setMadhab("hanafi")}>
            {t("hanafi")}
          </Chip>
        </div>
      </section>

      <section>
        <SectionTitle className="mb-2">{t("translation")}</SectionTitle>
        {(
          [
            ["none", "translationNone"],
            ["ku", "translationKu"],
            ["en", "translationEn"],
          ] as [TranslationMode, I18nKey][]
        ).map(([id, key]) => (
          <Chip key={id} className="mb-2 me-2" active={store.translation === id} onClick={() => store.setTranslation(id)}>
            {t(key)}
          </Chip>
        ))}
      </section>

      <section>
        <SectionTitle className="mb-2">{t("reciter")}</SectionTitle>
        {RECITERS.map((r) => (
          <Chip key={r.id} className="mb-2 me-2" active={store.reciter === r.id} onClick={() => store.setReciter(r.id)}>
            {t(r.key)}
          </Chip>
        ))}
      </section>

      <section>
        <SectionTitle className="mb-2">{t("quranFontSize")}</SectionTitle>
        <input
          type="range"
          min={0.85}
          max={1.45}
          step={0.05}
          value={store.quranScale}
          onChange={(e) => store.setQuranScale(Number(e.target.value))}
          className="w-full"
        />
      </section>

      <section>
        <SectionTitle className="mb-2">{t("fontSize")}</SectionTitle>
        <input
          type="range"
          min={0.9}
          max={1.25}
          step={0.05}
          value={store.uiScale}
          onChange={(e) => store.setUiScale(Number(e.target.value))}
          className="w-full"
        />
      </section>

      <section>
        <SectionTitle className="mb-2">{t("notifications")}</SectionTitle>
        <Card className="p-4">
          <p className="text-sm text-muted">{t("prayerReminders")}</p>
          <Button className="mt-3 w-full" onClick={() => void enableNotes()}>
            {t("enableNotifications")}
          </Button>
        </Card>
      </section>
    </div>
  );
}
