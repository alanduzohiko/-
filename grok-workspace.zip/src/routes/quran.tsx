import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Input, Spinner } from "@/components/ui";
import { loadMeta, surahDisplayName, type SurahMeta } from "@/lib/quran";
import { useT } from "@/lib/use-t";
import { formatNumber } from "@/lib/locale";
import { useAppStore } from "@/lib/store";

export const Route = createFileRoute("/quran")({ component: QuranList });

function QuranList() {
  const { t, lang } = useT();
  const lastRead = useAppStore((s) => s.lastRead);
  const [meta, setMeta] = useState<SurahMeta[] | null>(null);
  const [q, setQ] = useState("");
  const [err, setErr] = useState(false);

  useEffect(() => {
    void loadMeta()
      .then(setMeta)
      .catch(() => setErr(true));
  }, []);

  const filtered = useMemo(() => {
    if (!meta) return [];
    const s = q.trim().toLowerCase();
    if (!s) return meta;
    return meta.filter(
      (x) =>
        x.ku.includes(q) ||
        x.ar.includes(q) ||
        x.en.toLowerCase().includes(s) ||
        String(x.n) === s,
    );
  }, [meta, q]);

  if (err) return <p className="text-sm text-muted">{t("loadError")}</p>;
  if (!meta) return <Spinner />;

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-medium">{t("quran")}</h1>
        <p className="mt-1 text-sm text-muted">{t("preserveNote")}</p>
      </div>
      <Input
        value={q}
        onChange={(e) => setQ(e.target.value)}
        placeholder={t("searchQuran")}
        aria-label={t("searchQuran")}
      />
      {lastRead ? (
        <Link
          to="/quran/$n"
          params={{ n: String(lastRead.surah) }}
          search={{ ayah: lastRead.ayah }}
          className="block rounded-[16px] border border-border bg-surface-2 px-4 py-3 text-sm"
        >
          {t("continueReading")} · {t("surah")} {formatNumber(lastRead.surah, lang)} · {t("ayah")}{" "}
          {formatNumber(lastRead.ayah, lang)}
        </Link>
      ) : null}
      <ul className="divide-y divide-border overflow-hidden rounded-[24px] border border-border bg-surface">
        {filtered.map((s) => (
          <li key={s.n}>
            <Link
              to="/quran/$n"
              params={{ n: String(s.n) }}
              className="flex items-center gap-3 px-4 py-3"
            >
              <span className="flex size-10 shrink-0 items-center justify-center rounded-[12px] bg-surface-2 tabular-nums text-sm text-muted">
                {formatNumber(s.n, lang)}
              </span>
              <span className="min-w-0 flex-1">
                <span className="block font-medium">{surahDisplayName(s, lang)}</span>
                <span className="block text-xs text-muted">
                  {lang === "en" ? s.enMean : s.ar.replace(/^سُورَةُ\s*/, "")} · {formatNumber(s.ayahs, lang)}{" "}
                  {t("ayahs")} · {s.rev === "M" ? t("meccan") : t("medinan")}
                </span>
              </span>
              <span className="font-quran text-lg text-accent" dir="rtl">
                {s.ar.replace(/^سُورَةُ\s*/, "")}
              </span>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
