import { createFileRoute } from "@tanstack/react-router";
import { Card } from "@/components/ui";
import { useT } from "@/lib/use-t";

export const Route = createFileRoute("/about")({ component: AboutPage });

function AboutPage() {
  const { t } = useT();
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-medium">{t("aboutTitle")}</h1>
      <Card className="space-y-3 p-5 text-sm leading-relaxed text-muted">
        <p>{t("aboutBody")}</p>
        <p>{t("aboutQuran")}</p>
        <p>{t("aboutOffline")}</p>
        <p>{t("aboutReplacement")}</p>
      </Card>
      <Card className="space-y-2 p-5 text-sm leading-relaxed text-muted">
        <p className="font-medium text-fg">{t("privacy")}</p>
        <p>{t("privacyBody")}</p>
      </Card>
      <Card className="space-y-2 p-5 text-sm leading-relaxed text-muted">
        <p>
          {t("version")}: 1.0.0
        </p>
        <p>{t("installHint")}</p>
        <p>{t("androidNote")}</p>
      </Card>
      <div className="flex flex-col gap-2 text-sm">
        <a className="text-accent" href="/RELEASE_NOTES.md" target="_blank" rel="noreferrer">
          {t("releaseNotes")}
        </a>
        <a className="text-accent" href="/TECHNICAL_REPORT.md" target="_blank" rel="noreferrer">
          {t("downloadReport")}
        </a>
      </div>
    </div>
  );
}
