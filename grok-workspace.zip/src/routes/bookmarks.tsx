import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Empty, SectionTitle, Spinner } from "@/components/ui";
import { useAppStore } from "@/lib/store";
import { useT } from "@/lib/use-t";
import { loadHisn, type HisnItem } from "@/lib/content";
import { loadArabic, loadMeta, surahDisplayName, type SurahMeta } from "@/lib/quran";
import { formatNumber } from "@/lib/locale";

export const Route = createFileRoute("/bookmarks")({ component: BookmarksPage });

function BookmarksPage() {
  const { t, lang } = useT();
  const bookmarks = useAppStore((s) => s.bookmarks);
  const [meta, setMeta] = useState<SurahMeta[] | null>(null);
  const [ar, setAr] = useState<string[][] | null>(null);
  const [hisn, setHisn] = useState<HisnItem[] | null>(null);

  useEffect(() => {
    void Promise.all([loadMeta(), loadArabic(), loadHisn()]).then(([m, a, h]) => {
      setMeta(m);
      setAr(a);
      setHisn(h);
    });
  }, []);

  const ayahs = bookmarks.filter((b) => b.kind === "ayah");
  const duas = bookmarks.filter((b) => b.kind === "dua");

  if (!meta || !ar || !hisn) return <Spinner />;
  if (!bookmarks.length) return <Empty>{t("emptyBookmarks")}</Empty>;

  return (
    <div className="space-y-5">
      <h1 className="text-2xl font-medium">{t("bookmarks")}</h1>
      {ayahs.length ? (
        <section>
          <SectionTitle className="mb-2">{t("bookmarksAyah")}</SectionTitle>
          <ul className="space-y-2">
            {ayahs.map((b) => {
              if (b.kind !== "ayah") return null;
              const s = meta[b.surah - 1];
              const text = ar[b.surah - 1]?.[b.ayah - 1] ?? "";
              return (
                <li key={`a-${b.surah}-${b.ayah}`}>
                  <Link
                    to="/quran/$n"
                    params={{ n: String(b.surah) }}
                    search={{ ayah: b.ayah }}
                    className="block rounded-[16px] border border-border bg-surface p-3"
                  >
                    <p className="text-xs text-muted">
                      {s ? surahDisplayName(s, lang) : b.surah} · {t("ayah")} {formatNumber(b.ayah, lang)}
                    </p>
                    <p className="font-quran mt-1 line-clamp-3" dir="rtl">
                      {text}
                    </p>
                  </Link>
                </li>
              );
            })}
          </ul>
        </section>
      ) : null}
      {duas.length ? (
        <section>
          <SectionTitle className="mb-2">{t("bookmarksDua")}</SectionTitle>
          <ul className="space-y-2">
            {duas.map((b) => {
              if (b.kind !== "dua") return null;
              const item = hisn.find((x) => x.id === b.id);
              const title = item ? (lang === "ku" ? item.ku : lang === "ar" ? item.ar : item.en) : b.id;
              return (
                <li key={b.id}>
                  <Link to="/duas/$id" params={{ id: b.id }} className="block rounded-[16px] border border-border bg-surface p-3">
                    <p className="font-medium">{title}</p>
                    {item?.texts[0] ? (
                      <p className="font-quran mt-1 line-clamp-2 text-sm" dir="rtl">
                        {item.texts[0]}
                      </p>
                    ) : null}
                  </Link>
                </li>
              );
            })}
          </ul>
        </section>
      ) : null}
    </div>
  );
}
