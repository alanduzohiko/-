import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Card } from "@/components/ui";
import { getActiveCoords } from "@/lib/store";
import { qiblaBearing } from "@/lib/prayer";
import { useT } from "@/lib/use-t";
import { formatNumber } from "@/lib/locale";

export const Route = createFileRoute("/qibla")({ component: QiblaPage });

function QiblaPage() {
  const { t, lang } = useT();
  const coords = getActiveCoords();
  const bearing = useMemo(() => qiblaBearing(coords.lat, coords.lng), [coords.lat, coords.lng]);
  const [heading, setHeading] = useState<number | null>(null);

  useEffect(() => {
    const handler = (e: DeviceOrientationEvent) => {
      const anyE = e as DeviceOrientationEvent & { webkitCompassHeading?: number };
      const h = anyE.webkitCompassHeading ?? (typeof e.alpha === "number" ? 360 - e.alpha : null);
      if (h != null) setHeading(h);
    };
    window.addEventListener("deviceorientation", handler);
    return () => window.removeEventListener("deviceorientation", handler);
  }, []);

  const rotation = heading == null ? bearing : bearing - heading;
  const city = lang === "ku" ? coords.labelKu : lang === "ar" ? coords.labelAr : coords.labelEn;

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-medium">{t("qibla")}</h1>
        <p className="mt-1 text-sm text-muted">{city}</p>
      </div>
      <Card className="flex flex-col items-center p-6">
        <div className="relative size-64">
          <div className="absolute inset-0 rounded-full border border-border-strong" />
          <div className="absolute inset-6 rounded-full border border-border" />
          <div
            className="absolute inset-0 flex items-start justify-center pt-4 transition-transform duration-200"
            style={{ transform: `rotate(${rotation}deg)` }}
          >
            <div className="h-24 w-1 rounded-full bg-accent" />
          </div>
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="text-xs text-muted">{t("kaaba")}</span>
          </div>
          <span className="absolute top-2 left-1/2 -translate-x-1/2 text-[10px] text-faint">{t("north")}</span>
        </div>
        <p className="mt-6 tabular-nums text-2xl font-medium">
          {formatNumber(Math.round(bearing), lang)}°
        </p>
        <p className="mt-1 text-sm text-muted">{t("qiblaDegrees")}</p>
      </Card>
      <p className="text-sm leading-relaxed text-muted">
        {heading == null ? t("compassUnavailable") : t("qiblaHint")}
      </p>
    </div>
  );
}
