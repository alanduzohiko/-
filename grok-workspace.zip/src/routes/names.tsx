import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { ASMA } from "@/lib/asma";
import { Input } from "@/components/ui";
import { useT } from "@/lib/use-t";
import { formatNumber } from "@/lib/locale";

export const Route = createFileRoute("/names")({ component: NamesPage });

function NamesPage() {
  const { t, lang } = useT();
  const [q, setQ] = useState("");
  const list = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return ASMA;
    return ASMA.filter(
      (n) =>
        n.ar.includes(q) ||
        n.ku.includes(q) ||
        n.en.toLowerCase().includes(s) ||
        n.tr.toLowerCase().includes(s),
    );
  }, [q]);

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-medium">{t("namesOfAllah")}</h1>
        <p className="mt-1 text-sm text-muted">{t("namesHint")}</p>
      </div>
      <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t("search")} />
      <ul className="space-y-2">
        {list.map((n) => (
          <li key={n.n} className="rounded-[20px] border border-border bg-surface p-4">
            <div className="flex items-baseline justify-between gap-3">
              <p className="font-quran text-2xl" dir="rtl">
                {n.ar}
              </p>
              <span className="tabular-nums text-xs text-faint">{formatNumber(n.n, lang)}</span>
            </div>
            <p className="mt-2 text-sm text-muted">{n.tr}</p>
            <p className="mt-1 text-sm">{lang === "en" ? n.en : lang === "ar" ? n.en : n.ku}</p>
          </li>
        ))}
      </ul>
    </div>
  );
}
