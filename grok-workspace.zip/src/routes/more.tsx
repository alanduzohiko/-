import { createFileRoute, Link } from "@tanstack/react-router";
import {
  Bookmark,
  Compass,
  Hash,
  Info,
  Search,
  ScrollText,
  Settings,
  Sparkles,
} from "lucide-react";
import { useT } from "@/lib/use-t";
import type { I18nKey } from "@/lib/i18n";

export const Route = createFileRoute("/more")({ component: MorePage });

const ITEMS: { to: string; key: I18nKey; icon: typeof Settings }[] = [
  { to: "/duas", key: "duas", icon: ScrollText },
  { to: "/tasbih", key: "tasbih", icon: Hash },
  { to: "/qibla", key: "qibla", icon: Compass },
  { to: "/names", key: "names", icon: Sparkles },
  { to: "/bookmarks", key: "bookmarks", icon: Bookmark },
  { to: "/search", key: "search", icon: Search },
  { to: "/settings", key: "settings", icon: Settings },
  { to: "/about", key: "about", icon: Info },
];

function MorePage() {
  const { t } = useT();
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-medium">{t("more")}</h1>
      <ul className="overflow-hidden rounded-[24px] border border-border bg-surface">
        {ITEMS.map((it) => {
          const Icon = it.icon;
          return (
            <li key={it.to} className="border-b border-border last:border-0">
              <Link to={it.to} className="flex min-h-14 items-center gap-3 px-4 py-3">
                <Icon className="size-5 text-muted" strokeWidth={1.75} />
                <span>{t(it.key)}</span>
              </Link>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
