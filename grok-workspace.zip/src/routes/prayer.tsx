import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Card, SectionTitle } from "@/components/ui";
import { getActiveCoords, useAppStore } from "@/lib/store";
import { computePrayerTimes, currentPrayer, nextPrayer, PRAYER_ORDER, type PrayerId } from "@/lib/prayer";
import { useT } from "@/lib/use-t";
import { formatClock, formatDuration } from "@/lib/locale";
import type { I18nKey } from "@/lib/i18n";
import { cn } from "@/lib/cn";

export const Route = createFileRoute("/prayer")({ component: PrayerPage });

const KEYS: Record<PrayerId, I18nKey> = {
  fajr: "fajr",
  sunrise: "sunrise",
  dhuhr: "dhuhr",
  asr: "asr",
  maghrib: "maghrib",
  isha: "isha",
};

function PrayerPage() {
  const { t, lang } = useT();
  const method = useAppStore((s) => s.method);
  const madhab = useAppStore((s) => s.madhab);
  const coords = getActiveCoords();
  const [now, setNow] = useState(() => new Date());

  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 15000);
    return () => clearInterval(id);
  }, []);

  const times = useMemo(
    () => computePrayerTimes(coords.lat, coords.lng, now, method, madhab),
    [coords.lat, coords.lng, method, madhab, now],
  );
  const upcoming = nextPrayer(times, now);
  const current = currentPrayer(times, now);
  const city = lang === "ku" ? coords.labelKu : lang === "ar" ? coords.labelAr : coords.labelEn;

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-medium">{t("prayer")}</h1>
        <p className="mt-1 text-sm text-muted">
          {t("timesFor")} {city}
        </p>
      </div>
      {upcoming ? (
        <Card className="p-5">
          <SectionTitle>{t("nextPrayer")}</SectionTitle>
          <p className="mt-2 text-3xl font-medium">{t(KEYS[upcoming.id])}</p>
          <p className="mt-1 tabular-nums text-muted">
            {formatClock(upcoming.at, lang)} · {formatDuration(upcoming.at.getTime() - now.getTime(), lang, (k) => t(k))}
          </p>
        </Card>
      ) : (
        <Card className="p-5">
          <SectionTitle>{t("nextPrayer")}</SectionTitle>
          <p className="mt-2 text-xl">{t("fajr")}</p>
          <p className="text-sm text-muted">{t("tomorrow")}</p>
        </Card>
      )}
      <ul className="overflow-hidden rounded-[24px] border border-border bg-surface">
        {PRAYER_ORDER.map((id) => {
          const at = times[id];
          const isNext = upcoming?.id === id;
          const isNow = current === id;
          const passed = at.getTime() < now.getTime() && !isNow;
          return (
            <li
              key={id}
              className={cn(
                "flex items-center justify-between border-b border-border px-4 py-4 last:border-0",
                isNext && "bg-surface-2",
              )}
            >
              <div>
                <p className="font-medium">{t(KEYS[id])}</p>
                {isNext ? <p className="text-xs text-accent">{t("upcoming")}</p> : null}
                {passed ? <p className="text-xs text-faint">{t("passed")}</p> : null}
              </div>
              <p className="tabular-nums text-lg">{formatClock(at, lang)}</p>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
