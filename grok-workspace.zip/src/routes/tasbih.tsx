import { createFileRoute } from "@tanstack/react-router";
import { useAppStore } from "@/lib/store";
import { useT } from "@/lib/use-t";
import { Button, Chip } from "@/components/ui";
import { formatNumber } from "@/lib/locale";
import { toast } from "sonner";

export const Route = createFileRoute("/tasbih")({ component: TasbihPage });

const TARGETS = [33, 99, 100];

function TasbihPage() {
  const { t, lang } = useT();
  const count = useAppStore((s) => s.tasbihCount);
  const target = useAppStore((s) => s.tasbihTarget);
  const bump = useAppStore((s) => s.bumpTasbih);
  const reset = useAppStore((s) => s.resetTasbih);
  const setTarget = useAppStore((s) => s.setTasbihTarget);
  const round = Math.floor(count / target);
  const inRound = count % target;

  return (
    <div className="flex min-h-[70vh] flex-col items-center">
      <h1 className="self-start text-2xl font-medium">{t("tasbih")}</h1>
      <div className="mt-4 flex gap-2">
        {TARGETS.map((n) => (
          <Chip key={n} active={target === n} onClick={() => setTarget(n)}>
            {formatNumber(n, lang)}
          </Chip>
        ))}
      </div>
      <button
        type="button"
        onClick={() => {
          bump();
          if ((count + 1) % target === 0) toast.success(t("roundComplete"));
        }}
        className="tasbih-btn mt-10 flex size-56 flex-col items-center justify-center rounded-full border border-border-strong bg-surface text-fg shadow-soft"
        aria-label={t("tapToCount")}
      >
        <span className="tabular-nums text-6xl font-medium tracking-tight">{formatNumber(inRound, lang)}</span>
        <span className="mt-2 text-sm text-muted">
          {t("of")} {formatNumber(target, lang)}
        </span>
      </button>
      <p className="mt-6 text-sm text-muted">
        {t("progress")}: {formatNumber(count, lang)} · {t("roundComplete")} {formatNumber(round, lang)}
      </p>
      <Button variant="outline" className="mt-6" onClick={reset}>
        {t("tasbihReset")}
      </Button>
      <p className="mt-8 max-w-xs text-center text-sm text-faint">{t("tapToCount")}</p>
    </div>
  );
}
