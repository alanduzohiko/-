import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { Bookmark, BookmarkCheck, ChevronLeft, ChevronRight, Copy, Pause, Play } from "lucide-react";
import { toast } from "sonner";
import { Button, Chip, Spinner } from "@/components/ui";
import { loadArabic, loadEn, loadKu, loadMeta, globalAyahIndex, reciterAudioUrl, surahDisplayName, type SurahMeta } from "@/lib/quran";
import { useAppStore } from "@/lib/store";
import { useT } from "@/lib/use-t";
import { formatNumber, isRtl } from "@/lib/locale";
import { onAudioEnded, pauseAudio, playUrl, stopAudio } from "@/lib/player";
import { cn } from "@/lib/cn";

type Search = { ayah?: number };

export const Route = createFileRoute("/quran/$n")({
  validateSearch: (s: Record<string, unknown>): Search => ({
    ayah: typeof s.ayah === "number" ? s.ayah : s.ayah ? Number(s.ayah) : undefined,
  }),
  component: Reader,
});

function Reader() {
  const { n: nStr } = Route.useParams();
  const { ayah: jump } = Route.useSearch();
  const n = Number(nStr);
  const { t, lang } = useT();
  const navigate = useNavigate();
  const translation = useAppStore((s) => s.translation);
  const reciter = useAppStore((s) => s.reciter);
  const quranScale = useAppStore((s) => s.quranScale);
  const toggleBookmark = useAppStore((s) => s.toggleBookmark);
  const bookmarks = useAppStore((s) => s.bookmarks);
  const setLastRead = useAppStore((s) => s.setLastRead);
  const [meta, setMeta] = useState<SurahMeta[] | null>(null);
  const [ar, setAr] = useState<string[] | null>(null);
  const [tr, setTr] = useState<string[] | null>(null);
  const [playing, setPlaying] = useState<number | null>(null);
  const [err, setErr] = useState(false);
  const jumpRef = useRef<HTMLLIElement | null>(null);

  const surah = meta?.find((s) => s.n === n);

  useEffect(() => {
    let alive = true;
    void (async () => {
      try {
        const m = await loadMeta();
        const arabic = await loadArabic();
        if (!alive) return;
        setMeta(m);
        setAr(arabic[n - 1] ?? []);
      } catch {
        if (alive) setErr(true);
      }
    })();
    return () => {
      alive = false;
      stopAudio();
    };
  }, [n]);

  useEffect(() => {
    let alive = true;
    if (translation === "none") {
      setTr(null);
      return;
    }
    void (translation === "ku" ? loadKu() : loadEn()).then((all) => {
      if (alive) setTr(all[n - 1] ?? []);
    });
    return () => {
      alive = false;
    };
  }, [n, translation]);

  useEffect(() => {
    if (jump && jumpRef.current) {
      jumpRef.current.scrollIntoView({ block: "center" });
    }
  }, [jump, ar]);

  const ayahs = ar ?? [];
  const showBismillah = n !== 1 && n !== 9;

  async function playAyah(ayah: number) {
    if (!meta) return;
    try {
      const g = globalAyahIndex(n, ayah, meta);
      setPlaying(ayah);
      await playUrl(reciterAudioUrl(reciter, g));
    } catch {
      setPlaying(null);
      toast.error(t("audioError"));
    }
  }

  useEffect(() => {
    return onAudioEnded(() => setPlaying(null));
  }, []);

  const bookSet = useMemo(() => {
    const s = new Set<string>();
    for (const b of bookmarks) {
      if (b.kind === "ayah") s.add(`${b.surah}:${b.ayah}`);
    }
    return s;
  }, [bookmarks]);

  if (err) return <p className="text-sm text-muted">{t("loadError")}</p>;
  if (!surah || !ar) return <Spinner />;

  const rtl = isRtl(lang);

  return (
    <div className="space-y-4 pb-8">
      <div className="flex items-center gap-2">
        <Link
          to="/quran"
          className="inline-flex size-11 items-center justify-center rounded-[12px] text-fg"
          aria-label={t("back")}
        >
          {rtl ? <ChevronRight className="size-5" /> : <ChevronLeft className="size-5" />}
        </Link>
        <div className="min-w-0 flex-1">
          <h1 className="truncate text-lg font-medium">{surahDisplayName(surah, lang)}</h1>
          <p className="text-xs text-muted">
            {formatNumber(surah.n, lang)} · {formatNumber(surah.ayahs, lang)} {t("ayahs")} ·{" "}
            {surah.rev === "M" ? t("meccan") : t("medinan")}
          </p>
        </div>
        <div className="flex gap-1">
          {n > 1 ? (
            <button
              className="size-11 rounded-[12px]"
              aria-label={t("prev")}
              onClick={() => navigate({ to: "/quran/$n", params: { n: String(n - 1) } })}
            >
              {rtl ? <ChevronLeft className="size-5" /> : <ChevronRight className="size-5" />}
            </button>
          ) : null}
          {n < 114 ? (
            <button
              className="size-11 rounded-[12px]"
              aria-label={t("next")}
              onClick={() => navigate({ to: "/quran/$n", params: { n: String(n + 1) } })}
            >
              {rtl ? <ChevronRight className="size-5" /> : <ChevronLeft className="size-5" />}
            </button>
          ) : null}
        </div>
      </div>

      {showBismillah ? (
        <p className="font-quran py-2 text-center text-2xl" dir="rtl">
          {t("bismillah")}
        </p>
      ) : null}

      <div className="flex gap-2 overflow-auto">
        <Chip
          active={translation !== "none"}
          onClick={() =>
            useAppStore.getState().setTranslation(translation === "none" ? (lang === "en" ? "en" : "ku") : "none")
          }
        >
          {translation === "none" ? t("translationOn") : t("translationOff")}
        </Chip>
      </div>

      <ol className="space-y-3">
        {ayahs.map((text, i) => {
          const ayah = i + 1;
          const saved = bookSet.has(`${n}:${ayah}`);
          const isJump = jump === ayah;
          return (
            <li
              key={ayah}
              ref={isJump ? jumpRef : undefined}
              className={cn(
                "rounded-[20px] border border-border bg-surface p-4",
                isJump && "border-accent",
              )}
            >
              <p
                className="font-quran text-fg"
                dir="rtl"
                style={{ fontSize: `${1.35 * quranScale}rem` }}
                onClick={() => setLastRead(n, ayah)}
              >
                {text}
                <span className="ayah-num">{formatNumber(ayah, lang === "en" ? "en" : lang)}</span>
              </p>
              {tr?.[i] ? (
                <p className="mt-3 text-sm leading-relaxed text-muted" dir={translation === "en" ? "ltr" : "rtl"}>
                  {tr[i]}
                </p>
              ) : null}
              <div className="mt-3 flex gap-1">
                <IconBtn
                  label={playing === ayah ? t("pause") : t("playAyah")}
                  onClick={() => {
                    if (playing === ayah) {
                      pauseAudio();
                      setPlaying(null);
                    } else void playAyah(ayah);
                  }}
                >
                  {playing === ayah ? <Pause className="size-4" /> : <Play className="size-4" />}
                </IconBtn>
                <IconBtn
                  label={saved ? t("removeBookmark") : t("addBookmark")}
                  onClick={() => {
                    toggleBookmark({ kind: "ayah", surah: n, ayah });
                    toast.success(saved ? t("bookmarkRemoved") : t("bookmarkAdded"));
                  }}
                >
                  {saved ? <BookmarkCheck className="size-4" /> : <Bookmark className="size-4" />}
                </IconBtn>
                <IconBtn
                  label={t("copy")}
                  onClick={async () => {
                    await navigator.clipboard.writeText(text);
                    toast.success(t("copied"));
                  }}
                >
                  <Copy className="size-4" />
                </IconBtn>
              </div>
            </li>
          );
        })}
      </ol>
      <Button variant="outline" className="w-full" onClick={() => navigate({ to: "/quran" })}>
        {t("surahList")}
      </Button>
    </div>
  );
}

function IconBtn({
  children,
  onClick,
  label,
}: {
  children: React.ReactNode;
  onClick: () => void;
  label: string;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      onClick={onClick}
      className="inline-flex size-10 items-center justify-center rounded-[12px] text-muted hover:bg-surface-2 hover:text-fg"
    >
      {children}
    </button>
  );
}
