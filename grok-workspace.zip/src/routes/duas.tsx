import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Input, Spinner } from "@/components/ui";
import { loadHisn, type HisnItem } from "@/lib/content";
import { useT } from "@/lib/use-t";
import { formatNumber } from "@/lib/locale";

export const Route = createFileRoute("/duas")({ component: DuasPage });

function DuasPage() {
  const { t, lang } = useT();
  const [list, setList] = useState<HisnItem[] | null>(null);
  const [q, setQ] = useState("");
  const [err, setErr] = useState(false);

  useEffect(() => {
    void loadHisn()
      .then(setList)
      .catch(() => setErr(true));
  }, []);

  const filtered = useMemo(() => {
    if (!list) return [];
    const s = q.trim().toLowerCase();
    if (!s) return list.filter((x) => x.id !== "h001");
    return list.filter(
      (x) =>
        x.ku.includes(q) ||
        x.ar.includes(q) ||
        x.en.toLowerCase().includes(s) ||
        x.texts.some((tx) => tx.includes(q)),
    );
  }, [list, q]);

  if (err) return <p className="text-sm text-muted">{t("loadError")}</p>;
  if (!list) return <Spinner />;

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-medium">{t("fortress")}</h1>
        <p className="mt-1 text-sm text-muted">{t("duas")}</p>
      </div>
      <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t("searchDuas")} />
      <ul className="divide-y divide-border overflow-hidden rounded-[24px] border border-border bg-surface">
        {filtered.map((item, i) => (
          <li key={item.id}>
            <Link to="/duas/$id" params={{ id: item.id }} className="flex items-center gap-3 px-4 py-3">
              <span className="w-8 tabular-nums text-sm text-muted">{formatNumber(i + 1, lang)}</span>
              <span className="min-w-0 flex-1">
                <span className="block font-medium">
                  {lang === "ku" ? item.ku : lang === "ar" ? item.ar : item.en}
                </span>
                {lang !== "ar" ? (
                  <span className="block truncate text-xs text-muted" dir="rtl">
                    {item.ar}
                  </span>
                ) : (
                  <span className="block truncate text-xs text-muted">{item.en}</span>
                )}
              </span>
            </Link>
          </li>
        ))}
      </ul>
      {!filtered.length ? <p className="text-sm text-muted">{t("noResults")}</p> : null}
    </div>
  );
}
