import { createRootRoute, HeadContent, Outlet, Scripts } from "@tanstack/react-router";
import { AuthProvider } from "@/lib/auth/provider";
import { PreviewHostBridge } from "@/components/preview-host-bridge";
import { AppShell } from "@/components/app-shell";
import { Onboarding } from "@/components/onboarding";
import { useAppStore } from "@/lib/store";
import { htmlLang, isRtl } from "@/lib/locale";
import { Toaster } from "sonner";
import { useEffect } from "react";
import { startPrayerReminders } from "@/lib/reminders";
import appCss from "../styles.css?url";

const APP_NAME = "میحراب";

function RootInner() {
  const hydrated = useAppStore((s) => s.hydrated);
  const onboarded = useAppStore((s) => s.onboarded);
  const lang = useAppStore((s) => s.lang);
  const theme = useAppStore((s) => s.theme);
  const uiScale = useAppStore((s) => s.uiScale);
  const setHydrated = useAppStore((s) => s.setHydrated);

  useEffect(() => {
    const result = useAppStore.persist.rehydrate();
    void Promise.resolve(result).then(() => setHydrated(true));
  }, [setHydrated]);

  useEffect(() => {
    if (!hydrated) return;
    const root = document.documentElement;
    root.lang = htmlLang(lang);
    root.dir = isRtl(lang) ? "rtl" : "ltr";
    root.dataset.theme = theme;
    root.style.fontSize = `${16 * uiScale}px`;
  }, [hydrated, lang, theme, uiScale]);

  useEffect(() => {
    if (!hydrated) return;
    return startPrayerReminders();
  }, [hydrated]);

  if (!hydrated) {
    return (
      <div className="mx-auto flex min-h-dvh max-w-lg flex-col bg-bg px-6 py-16 text-fg">
        <p className="text-sm text-muted">میحراب</p>
        <h1 className="mt-2 text-3xl font-medium tracking-tight">میحراب</h1>
        <p className="mt-3 max-w-prose text-sm leading-relaxed text-muted">
          قورئان، نوێژ، دوعا و ئەذکار
        </p>
      </div>
    );
  }
  if (!onboarded) return <Onboarding />;
  return (
    <AppShell>
      <Outlet />
    </AppShell>
  );
}

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1, viewport-fit=cover" },
      { title: APP_NAME },
      { name: "theme-color", content: "#0c1210" },
      { name: "description", content: "قورئان، نوێژ، دوعا و ئەذکار بە کوردی سۆرانی" },
    ],
    links: [
      { rel: "icon", type: "image/svg+xml", href: "/favicon.svg" },
      { rel: "stylesheet", href: appCss },
      { rel: "manifest", href: "/__grok/manifest.webmanifest" },
      { rel: "apple-touch-icon", href: "/__grok/icon-180.png" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Noto+Naskh+Arabic:wght@400;500;600;700&family=Noto+Sans+Arabic:wght@400;500;600;700&display=swap",
      },
    ],
  }),
  component: () => (
    <html lang="ckb" dir="rtl" suppressHydrationWarning>
      <head>
        <HeadContent />
      </head>
      <body>
        <PreviewHostBridge />
        <AuthProvider>
          <RootInner />
        </AuthProvider>
        <Toaster position="top-center" theme="dark" />
        <Scripts />
      </body>
    </html>
  ),
});
