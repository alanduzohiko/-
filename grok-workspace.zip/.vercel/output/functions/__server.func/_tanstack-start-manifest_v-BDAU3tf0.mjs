//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BDAU3tf0.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/adhkar",
			"/bookmarks",
			"/duas",
			"/more",
			"/names",
			"/prayer",
			"/qibla",
			"/quran",
			"/search",
			"/settings",
			"/tasbih"
		],
		preloads: [
			"/assets/index-BhXEt9wN.js",
			"/assets/use-t-BfUePfk0.js",
			"/assets/preload-helper-DiWPThTg.js",
			"/assets/link-DrOgLQhC.js",
			"/assets/createLucideIcon-Lrhmr-Wf.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BhXEt9wN.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-0_r2tdkX.js",
			"/assets/hash-DUlTrEY8.js",
			"/assets/sun-DK42MwQz.js",
			"/assets/quran-CU3Fp6uA.js"
		]
	},
	"/about": {
		filePath: "/workspace/src/routes/about.tsx",
		children: void 0,
		preloads: ["/assets/about-oEzGGGrf.js"]
	},
	"/adhkar": {
		filePath: "/workspace/src/routes/adhkar.tsx",
		children: ["/adhkar/$id"],
		preloads: ["/assets/adhkar-D-VIg6rU.js", "/assets/sun-DK42MwQz.js"]
	},
	"/bookmarks": {
		filePath: "/workspace/src/routes/bookmarks.tsx",
		children: void 0,
		preloads: [
			"/assets/bookmarks-DS5tba9R.js",
			"/assets/content-B9Wd8Yxd.js",
			"/assets/quran-CU3Fp6uA.js"
		]
	},
	"/duas": {
		filePath: "/workspace/src/routes/duas.tsx",
		children: ["/duas/$id"],
		preloads: ["/assets/duas-JGWIXMJp.js", "/assets/content-B9Wd8Yxd.js"]
	},
	"/more": {
		filePath: "/workspace/src/routes/more.tsx",
		children: void 0,
		preloads: [
			"/assets/more-R0BVG7O4.js",
			"/assets/bookmark-_XHl2wd5.js",
			"/assets/hash-DUlTrEY8.js"
		]
	},
	"/names": {
		filePath: "/workspace/src/routes/names.tsx",
		children: void 0,
		preloads: ["/assets/names-DQjmdabH.js", "/assets/asma-Cfp2l50n.js"]
	},
	"/prayer": {
		filePath: "/workspace/src/routes/prayer.tsx",
		children: void 0,
		preloads: ["/assets/prayer-DB_N2ind.js"]
	},
	"/qibla": {
		filePath: "/workspace/src/routes/qibla.tsx",
		children: void 0,
		preloads: ["/assets/qibla-7UDWv3rT.js"]
	},
	"/quran": {
		filePath: "/workspace/src/routes/quran.tsx",
		children: ["/quran/$n"],
		preloads: ["/assets/quran-DbeSNQqf.js", "/assets/quran-CU3Fp6uA.js"]
	},
	"/search": {
		filePath: "/workspace/src/routes/search.tsx",
		children: void 0,
		preloads: [
			"/assets/search-CXP-CV_O.js",
			"/assets/content-B9Wd8Yxd.js",
			"/assets/quran-CU3Fp6uA.js",
			"/assets/asma-Cfp2l50n.js"
		]
	},
	"/settings": {
		filePath: "/workspace/src/routes/settings.tsx",
		children: void 0,
		preloads: ["/assets/settings-DWcivODZ.js"]
	},
	"/tasbih": {
		filePath: "/workspace/src/routes/tasbih.tsx",
		children: void 0,
		preloads: ["/assets/tasbih-DLLtm3S1.js"]
	},
	"/adhkar/$id": {
		filePath: "/workspace/src/routes/adhkar.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/adhkar._id-CRL_H_Ti.js",
			"/assets/chevron-right-CzMx_yim.js",
			"/assets/content-B9Wd8Yxd.js"
		]
	},
	"/duas/$id": {
		filePath: "/workspace/src/routes/duas.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/duas._id-Dtun3WMS.js",
			"/assets/copy-CNR0c0oi.js",
			"/assets/bookmark-_XHl2wd5.js",
			"/assets/chevron-right-CzMx_yim.js"
		]
	},
	"/quran/$n": {
		filePath: "/workspace/src/routes/quran.$n.tsx",
		children: void 0,
		preloads: [
			"/assets/quran._n-aRi848w8.js",
			"/assets/copy-CNR0c0oi.js",
			"/assets/bookmark-_XHl2wd5.js",
			"/assets/chevron-right-CzMx_yim.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
