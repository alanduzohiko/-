import { i as __toESM } from "../_runtime.mjs";
import { X as require_react, w as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { b as Bookmark, h as Copy, v as ChevronRight, x as BookmarkCheck, y as ChevronLeft } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { C as isRtl, D as useAppStore, T as useT, d as Card, g as Spinner, r as Route$1 } from "./router-YxvWRw5J.mjs";
import { i as loadHisn } from "./content-By8KyBT8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/duas._id-DOY5p_aa.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function DuaDetail() {
	const { id } = Route$1.useParams();
	const { t, lang } = useT();
	const [item, setItem] = (0, import_react.useState)(void 0);
	const toggle = useAppStore((s) => s.toggleBookmark);
	const saved = useAppStore((s) => s.bookmarks.some((b) => b.kind === "dua" && b.id === id));
	const rtl = isRtl(lang);
	(0, import_react.useEffect)(() => {
		loadHisn().then((list) => setItem(list.find((x) => x.id === id) ?? null));
	}, [id]);
	if (item === void 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spinner, {});
	if (!item) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children: t("nothingHere")
	});
	const title = lang === "ku" ? item.ku : lang === "ar" ? item.ar : item.en;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/duas",
						className: "inline-flex size-11 items-center justify-center",
						"aria-label": t("back"),
						children: rtl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "flex-1 text-lg font-medium",
						children: title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "size-11",
						"aria-label": saved ? t("removeBookmark") : t("addBookmark"),
						onClick: () => {
							toggle({
								kind: "dua",
								id
							});
							toast.success(saved ? t("bookmarkRemoved") : t("bookmarkAdded"));
						},
						children: saved ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookmarkCheck, { className: "size-5 text-accent" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: "size-5" })
					})
				]
			}),
			lang !== "ar" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				dir: "rtl",
				children: item.ar
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: item.en
			}),
			item.texts.map((text, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-quran text-xl leading-loose",
					dir: "rtl",
					children: text
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "mt-3 inline-flex items-center gap-2 text-sm text-muted",
					onClick: async () => {
						await navigator.clipboard.writeText(text);
						toast.success(t("copied"));
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" }), t("copy")]
				})]
			}, i)),
			item.notes.map((n, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm leading-relaxed text-muted",
				dir: "rtl",
				children: n
			}, i))
		]
	});
}
//#endregion
export { DuaDetail as component };
