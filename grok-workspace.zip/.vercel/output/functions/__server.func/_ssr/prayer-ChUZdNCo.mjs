import { i as __toESM } from "../_runtime.mjs";
import { X as require_react, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { D as useAppStore, E as getActiveCoords, T as useT, a as PRAYER_ORDER, c as nextPrayer, d as Card, h as SectionTitle, j as cn, o as computePrayerTimes, s as currentPrayer, v as formatClock, y as formatDuration } from "./router-YxvWRw5J.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/prayer-ChUZdNCo.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var KEYS = {
	fajr: "fajr",
	sunrise: "sunrise",
	dhuhr: "dhuhr",
	asr: "asr",
	maghrib: "maghrib",
	isha: "isha"
};
function PrayerPage() {
	const { t, lang } = useT();
	const method = useAppStore((s) => s.method);
	const madhab = useAppStore((s) => s.madhab);
	const coords = getActiveCoords();
	const [now, setNow] = (0, import_react.useState)(() => /* @__PURE__ */ new Date());
	(0, import_react.useEffect)(() => {
		const id = setInterval(() => setNow(/* @__PURE__ */ new Date()), 15e3);
		return () => clearInterval(id);
	}, []);
	const times = (0, import_react.useMemo)(() => computePrayerTimes(coords.lat, coords.lng, now, method, madhab), [
		coords.lat,
		coords.lng,
		method,
		madhab,
		now
	]);
	const upcoming = nextPrayer(times, now);
	const current = currentPrayer(times, now);
	const city = lang === "ku" ? coords.labelKu : lang === "ar" ? coords.labelAr : coords.labelEn;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-medium",
				children: t("prayer")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-sm text-muted",
				children: [
					t("timesFor"),
					" ",
					city
				]
			})] }),
			upcoming ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: t("nextPrayer") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-3xl font-medium",
						children: t(KEYS[upcoming.id])
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 tabular-nums text-muted",
						children: [
							formatClock(upcoming.at, lang),
							" · ",
							formatDuration(upcoming.at.getTime() - now.getTime(), lang, (k) => t(k))
						]
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: t("nextPrayer") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xl",
						children: t("fajr")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: t("tomorrow")
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "overflow-hidden rounded-[24px] border border-border bg-surface",
				children: PRAYER_ORDER.map((id) => {
					const at = times[id];
					const isNext = upcoming?.id === id;
					const isNow = current === id;
					const passed = at.getTime() < now.getTime() && !isNow;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: cn("flex items-center justify-between border-b border-border px-4 py-4 last:border-0", isNext && "bg-surface-2"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium",
								children: t(KEYS[id])
							}),
							isNext ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-accent",
								children: t("upcoming")
							}) : null,
							passed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-faint",
								children: t("passed")
							}) : null
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "tabular-nums text-lg",
							children: formatClock(at, lang)
						})]
					}, id);
				})
			})
		]
	});
}
//#endregion
export { PrayerPage as component };
