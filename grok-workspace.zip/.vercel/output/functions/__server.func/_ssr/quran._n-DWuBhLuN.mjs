import { i as __toESM } from "../_runtime.mjs";
import { S as useNavigate, X as require_react, w as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { b as Bookmark, c as Play, h as Copy, l as Pause, v as ChevronRight, x as BookmarkCheck, y as ChevronLeft } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { C as isRtl, D as useAppStore, S as formatNumber, T as useT, f as Chip, g as Spinner, j as cn, n as Route, u as Button } from "./router-YxvWRw5J.mjs";
import { a as loadMeta, i as loadKu, n as loadArabic, o as reciterAudioUrl, r as loadEn, s as surahDisplayName, t as globalAyahIndex } from "./quran-DO9SoaPp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/quran._n-DWuBhLuN.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var audio = null;
function getAudio() {
	if (typeof window === "undefined") return null;
	if (!audio) {
		audio = new Audio();
		audio.preload = "none";
	}
	return audio;
}
async function playUrl(url) {
	const el = getAudio();
	if (!el) throw new Error("no audio");
	if (el.src !== url) el.src = url;
	await el.play();
}
function pauseAudio() {
	getAudio()?.pause();
}
function stopAudio() {
	const el = getAudio();
	if (!el) return;
	el.pause();
	el.currentTime = 0;
}
function onAudioEnded(cb) {
	const el = getAudio();
	if (!el) return () => {};
	const handler = () => cb();
	el.addEventListener("ended", handler);
	return () => el.removeEventListener("ended", handler);
}
function Reader() {
	const { n: nStr } = Route.useParams();
	const { ayah: jump } = Route.useSearch();
	const n = Number(nStr);
	const { t, lang } = useT();
	const navigate = useNavigate();
	const translation = useAppStore((s) => s.translation);
	const reciter = useAppStore((s) => s.reciter);
	const quranScale = useAppStore((s) => s.quranScale);
	const toggleBookmark = useAppStore((s) => s.toggleBookmark);
	const bookmarks = useAppStore((s) => s.bookmarks);
	const setLastRead = useAppStore((s) => s.setLastRead);
	const [meta, setMeta] = (0, import_react.useState)(null);
	const [ar, setAr] = (0, import_react.useState)(null);
	const [tr, setTr] = (0, import_react.useState)(null);
	const [playing, setPlaying] = (0, import_react.useState)(null);
	const [err, setErr] = (0, import_react.useState)(false);
	const jumpRef = (0, import_react.useRef)(null);
	const surah = meta?.find((s) => s.n === n);
	(0, import_react.useEffect)(() => {
		let alive = true;
		(async () => {
			try {
				const m = await loadMeta();
				const arabic = await loadArabic();
				if (!alive) return;
				setMeta(m);
				setAr(arabic[n - 1] ?? []);
			} catch {
				if (alive) setErr(true);
			}
		})();
		return () => {
			alive = false;
			stopAudio();
		};
	}, [n]);
	(0, import_react.useEffect)(() => {
		let alive = true;
		if (translation === "none") {
			setTr(null);
			return;
		}
		(translation === "ku" ? loadKu() : loadEn()).then((all) => {
			if (alive) setTr(all[n - 1] ?? []);
		});
		return () => {
			alive = false;
		};
	}, [n, translation]);
	(0, import_react.useEffect)(() => {
		if (jump && jumpRef.current) jumpRef.current.scrollIntoView({ block: "center" });
	}, [jump, ar]);
	const ayahs = ar ?? [];
	const showBismillah = n !== 1 && n !== 9;
	async function playAyah(ayah) {
		if (!meta) return;
		try {
			const g = globalAyahIndex(n, ayah, meta);
			setPlaying(ayah);
			await playUrl(reciterAudioUrl(reciter, g));
		} catch {
			setPlaying(null);
			toast.error(t("audioError"));
		}
	}
	(0, import_react.useEffect)(() => {
		return onAudioEnded(() => setPlaying(null));
	}, []);
	const bookSet = (0, import_react.useMemo)(() => {
		const s = /* @__PURE__ */ new Set();
		for (const b of bookmarks) if (b.kind === "ayah") s.add(`${b.surah}:${b.ayah}`);
		return s;
	}, [bookmarks]);
	if (err) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children: t("loadError")
	});
	if (!surah || !ar) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spinner, {});
	const rtl = isRtl(lang);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/quran",
						className: "inline-flex size-11 items-center justify-center rounded-[12px] text-fg",
						"aria-label": t("back"),
						children: rtl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "truncate text-lg font-medium",
							children: surahDisplayName(surah, lang)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted",
							children: [
								formatNumber(surah.n, lang),
								" · ",
								formatNumber(surah.ayahs, lang),
								" ",
								t("ayahs"),
								" ·",
								" ",
								surah.rev === "M" ? t("meccan") : t("medinan")
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-1",
						children: [n > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "size-11 rounded-[12px]",
							"aria-label": t("prev"),
							onClick: () => navigate({
								to: "/quran/$n",
								params: { n: String(n - 1) }
							}),
							children: rtl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-5" })
						}) : null, n < 114 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "size-11 rounded-[12px]",
							"aria-label": t("next"),
							onClick: () => navigate({
								to: "/quran/$n",
								params: { n: String(n + 1) }
							}),
							children: rtl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
						}) : null]
					})
				]
			}),
			showBismillah ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-quran py-2 text-center text-2xl",
				dir: "rtl",
				children: t("bismillah")
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2 overflow-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
					active: translation !== "none",
					onClick: () => useAppStore.getState().setTranslation(translation === "none" ? lang === "en" ? "en" : "ku" : "none"),
					children: translation === "none" ? t("translationOn") : t("translationOff")
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "space-y-3",
				children: ayahs.map((text, i) => {
					const ayah = i + 1;
					const saved = bookSet.has(`${n}:${ayah}`);
					const isJump = jump === ayah;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						ref: isJump ? jumpRef : void 0,
						className: cn("rounded-[20px] border border-border bg-surface p-4", isJump && "border-accent"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-quran text-fg",
								dir: "rtl",
								style: { fontSize: `${1.35 * quranScale}rem` },
								onClick: () => setLastRead(n, ayah),
								children: [text, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "ayah-num",
									children: formatNumber(ayah, lang === "en" ? "en" : lang)
								})]
							}),
							tr?.[i] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm leading-relaxed text-muted",
								dir: translation === "en" ? "ltr" : "rtl",
								children: tr[i]
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex gap-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
										label: playing === ayah ? t("pause") : t("playAyah"),
										onClick: () => {
											if (playing === ayah) {
												pauseAudio();
												setPlaying(null);
											} else playAyah(ayah);
										},
										children: playing === ayah ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
										label: saved ? t("removeBookmark") : t("addBookmark"),
										onClick: () => {
											toggleBookmark({
												kind: "ayah",
												surah: n,
												ayah
											});
											toast.success(saved ? t("bookmarkRemoved") : t("bookmarkAdded"));
										},
										children: saved ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookmarkCheck, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, { className: "size-4" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconBtn, {
										label: t("copy"),
										onClick: async () => {
											await navigator.clipboard.writeText(text);
											toast.success(t("copied"));
										},
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" })
									})
								]
							})
						]
					}, ayah);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				className: "w-full",
				onClick: () => navigate({ to: "/quran" }),
				children: t("surahList")
			})
		]
	});
}
function IconBtn({ children, onClick, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-label": label,
		onClick,
		className: "inline-flex size-10 items-center justify-center rounded-[12px] text-muted hover:bg-surface-2 hover:text-fg",
		children
	});
}
//#endregion
export { Reader as component };
