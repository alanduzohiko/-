//#region node_modules/.nitro/vite/services/ssr/assets/asma-DPftgxM1.js
var ASMA = [
	{
		n: 1,
		ar: "الرَّحْمَٰنُ",
		tr: "Ar-Rahman",
		en: "The Most Merciful",
		ku: "بەخشندەی گەورە"
	},
	{
		n: 2,
		ar: "الرَّحِيمُ",
		tr: "Ar-Raheem",
		en: "The Especially Merciful",
		ku: "میهرەبان"
	},
	{
		n: 3,
		ar: "الْمَلِكُ",
		tr: "Al-Malik",
		en: "The King",
		ku: "پادشا"
	},
	{
		n: 4,
		ar: "الْقُدُّوسُ",
		tr: "Al-Quddus",
		en: "The Most Holy",
		ku: "پیرۆز"
	},
	{
		n: 5,
		ar: "السَّلَامُ",
		tr: "As-Salam",
		en: "The Source of Peace",
		ku: "سەلامەتی"
	},
	{
		n: 6,
		ar: "الْمُؤْمِنُ",
		tr: "Al-Mu'min",
		en: "The Granter of Security",
		ku: "بەخشەری ئیمان و ئارامی"
	},
	{
		n: 7,
		ar: "الْمُهَيْمِنُ",
		tr: "Al-Muhaymin",
		en: "The Guardian",
		ku: "چاودێری هەموو شت"
	},
	{
		n: 8,
		ar: "الْعَزِيزُ",
		tr: "Al-Aziz",
		en: "The Almighty",
		ku: "بەدەسەڵات"
	},
	{
		n: 9,
		ar: "الْجَبَّارُ",
		tr: "Al-Jabbar",
		en: "The Compeller",
		ku: "چاککەرەوەی بەزۆر"
	},
	{
		n: 10,
		ar: "الْمُتَكَبِّرُ",
		tr: "Al-Mutakabbir",
		en: "The Supreme",
		ku: "گەورەی بێهاوتا"
	},
	{
		n: 11,
		ar: "الْخَالِقُ",
		tr: "Al-Khaliq",
		en: "The Creator",
		ku: "دروستکەر"
	},
	{
		n: 12,
		ar: "الْبَارِئُ",
		tr: "Al-Bari'",
		en: "The Evolver",
		ku: "داهێنەر لە هیچ"
	},
	{
		n: 13,
		ar: "الْمُصَوِّرُ",
		tr: "Al-Musawwir",
		en: "The Fashioner",
		ku: "شێوەبەخش"
	},
	{
		n: 14,
		ar: "الْغَفَّارُ",
		tr: "Al-Ghaffar",
		en: "The Repeatedly Forgiving",
		ku: "زۆر لێخۆشبوو"
	},
	{
		n: 15,
		ar: "الْقَهَّارُ",
		tr: "Al-Qahhar",
		en: "The Subduer",
		ku: "زۆر زاڵ"
	},
	{
		n: 16,
		ar: "الْوَهَّابُ",
		tr: "Al-Wahhab",
		en: "The Bestower",
		ku: "بەخشندەی بێپاداشت"
	},
	{
		n: 17,
		ar: "الرَّزَّاقُ",
		tr: "Ar-Razzaq",
		en: "The Provider",
		ku: "ڕزقدەر"
	},
	{
		n: 18,
		ar: "الْفَتَّاحُ",
		tr: "Al-Fattah",
		en: "The Opener",
		ku: "کردنەوەی دەرگا داخراوەکان"
	},
	{
		n: 19,
		ar: "الْعَلِيمُ",
		tr: "Al-Alim",
		en: "The All-Knowing",
		ku: "زانای هەموو شت"
	},
	{
		n: 20,
		ar: "الْقَابِضُ",
		tr: "Al-Qabid",
		en: "The Withholder",
		ku: "تەنگکەرەوە"
	},
	{
		n: 21,
		ar: "الْبَاسِطُ",
		tr: "Al-Basit",
		en: "The Extender",
		ku: "فراوانکەرەوە"
	},
	{
		n: 22,
		ar: "الْخَافِضُ",
		tr: "Al-Khafid",
		en: "The Abaser",
		ku: "نزمکەرەوە"
	},
	{
		n: 23,
		ar: "الرَّافِعُ",
		tr: "Ar-Rafi",
		en: "The Exalter",
		ku: "بەرزکەرەوە"
	},
	{
		n: 24,
		ar: "الْمُعِزُّ",
		tr: "Al-Mu'izz",
		en: "The Honourer",
		ku: "عیززەتبەخش"
	},
	{
		n: 25,
		ar: "الْمُذِلُّ",
		tr: "Al-Mudhill",
		en: "The Humiliator",
		ku: "زەلیلکەر"
	},
	{
		n: 26,
		ar: "السَّمِيعُ",
		tr: "As-Sami",
		en: "The All-Hearing",
		ku: "بیستووی هەموو شت"
	},
	{
		n: 27,
		ar: "الْبَصِيرُ",
		tr: "Al-Basir",
		en: "The All-Seeing",
		ku: "بینەری هەموو شت"
	},
	{
		n: 28,
		ar: "الْحَكَمُ",
		tr: "Al-Hakam",
		en: "The Judge",
		ku: "دادوەر"
	},
	{
		n: 29,
		ar: "الْعَدْلُ",
		tr: "Al-Adl",
		en: "The Just",
		ku: "دادپەروەر"
	},
	{
		n: 30,
		ar: "اللَّطِيفُ",
		tr: "Al-Latif",
		en: "The Subtle",
		ku: "نازک و میهرەبان"
	},
	{
		n: 31,
		ar: "الْخَبِيرُ",
		tr: "Al-Khabir",
		en: "The All-Aware",
		ku: "ئاگاداری وردەکاری"
	},
	{
		n: 32,
		ar: "الْحَلِيمُ",
		tr: "Al-Halim",
		en: "The Forbearing",
		ku: "بوردبار"
	},
	{
		n: 33,
		ar: "الْعَظِيمُ",
		tr: "Al-Azim",
		en: "The Magnificent",
		ku: "گەورە و مەزن"
	},
	{
		n: 34,
		ar: "الْغَفُورُ",
		tr: "Al-Ghafur",
		en: "The Forgiving",
		ku: "لێخۆشبوو"
	},
	{
		n: 35,
		ar: "الشَّكُورُ",
		tr: "Ash-Shakur",
		en: "The Appreciative",
		ku: "شوکرکەرەوە"
	},
	{
		n: 36,
		ar: "الْعَلِيُّ",
		tr: "Al-Ali",
		en: "The Most High",
		ku: "بەرزترین"
	},
	{
		n: 37,
		ar: "الْكَبِيرُ",
		tr: "Al-Kabir",
		en: "The Greatest",
		ku: "گەورەترین"
	},
	{
		n: 38,
		ar: "الْحَفِيظُ",
		tr: "Al-Hafiz",
		en: "The Preserver",
		ku: "پارێزەر"
	},
	{
		n: 39,
		ar: "الْمُقِيتُ",
		tr: "Al-Muqit",
		en: "The Nourisher",
		ku: "خۆراکبەخش"
	},
	{
		n: 40,
		ar: "الْحَسِيبُ",
		tr: "Al-Hasib",
		en: "The Reckoner",
		ku: "حسابپێکردن"
	},
	{
		n: 41,
		ar: "الْجَلِيلُ",
		tr: "Al-Jalil",
		en: "The Majestic",
		ku: "بەشکۆ"
	},
	{
		n: 42,
		ar: "الْكَرِيمُ",
		tr: "Al-Karim",
		en: "The Generous",
		ku: "بەخشندە"
	},
	{
		n: 43,
		ar: "الرَّقِيبُ",
		tr: "Ar-Raqib",
		en: "The Watchful",
		ku: "چاودێر"
	},
	{
		n: 44,
		ar: "الْمُجِيبُ",
		tr: "Al-Mujib",
		en: "The Responsive",
		ku: "وەڵامدەرەوەی دوعا"
	},
	{
		n: 45,
		ar: "الْوَاسِعُ",
		tr: "Al-Wasi",
		en: "The All-Encompassing",
		ku: "فراوان"
	},
	{
		n: 46,
		ar: "الْحَكِيمُ",
		tr: "Al-Hakim",
		en: "The Wise",
		ku: "حیکمەتمەند"
	},
	{
		n: 47,
		ar: "الْوَدُودُ",
		tr: "Al-Wadud",
		en: "The Most Loving",
		ku: "خۆشەویست"
	},
	{
		n: 48,
		ar: "الْمَجِيدُ",
		tr: "Al-Majid",
		en: "The Glorious",
		ku: "شکۆدار"
	},
	{
		n: 49,
		ar: "الْبَاعِثُ",
		tr: "Al-Ba'ith",
		en: "The Resurrector",
		ku: "زیندووکەرەوە"
	},
	{
		n: 50,
		ar: "الشَّهِيدُ",
		tr: "Ash-Shahid",
		en: "The Witness",
		ku: "شایەت"
	},
	{
		n: 51,
		ar: "الْحَقُّ",
		tr: "Al-Haqq",
		en: "The Truth",
		ku: "هەق"
	},
	{
		n: 52,
		ar: "الْوَكِيلُ",
		tr: "Al-Wakil",
		en: "The Trustee",
		ku: "بڕواپێکراو"
	},
	{
		n: 53,
		ar: "الْقَوِيُّ",
		tr: "Al-Qawiyy",
		en: "The Strong",
		ku: "بەهێز"
	},
	{
		n: 54,
		ar: "الْمَتِينُ",
		tr: "Al-Matin",
		en: "The Firm",
		ku: "پته‌و"
	},
	{
		n: 55,
		ar: "الْوَلِيُّ",
		tr: "Al-Waliyy",
		en: "The Protecting Friend",
		ku: "دۆستی پارێزەر"
	},
	{
		n: 56,
		ar: "الْحَمِيدُ",
		tr: "Al-Hamid",
		en: "The Praiseworthy",
		ku: "شایستەی ستایش"
	},
	{
		n: 57,
		ar: "الْمُحْصِي",
		tr: "Al-Muhsi",
		en: "The Accounter",
		ku: "ژمێریاری هەموو شت"
	},
	{
		n: 58,
		ar: "الْمُبْدِئُ",
		tr: "Al-Mubdi",
		en: "The Originator",
		ku: "دەستپێکەر"
	},
	{
		n: 59,
		ar: "الْمُعِيدُ",
		tr: "Al-Mu'id",
		en: "The Restorer",
		ku: "گەڕێنەرەوە"
	},
	{
		n: 60,
		ar: "الْمُحْيِي",
		tr: "Al-Muhyi",
		en: "The Giver of Life",
		ku: "ژیانبەخش"
	},
	{
		n: 61,
		ar: "الْمُمِيتُ",
		tr: "Al-Mumit",
		en: "The Bringer of Death",
		ku: "مردنھێنەر"
	},
	{
		n: 62,
		ar: "الْحَيُّ",
		tr: "Al-Hayy",
		en: "The Ever-Living",
		ku: "زیندووی هەمیشەیی"
	},
	{
		n: 63,
		ar: "الْقَيُّومُ",
		tr: "Al-Qayyum",
		en: "The Self-Subsisting",
		ku: "هەمیشە بەرپادار"
	},
	{
		n: 64,
		ar: "الْوَاجِدُ",
		tr: "Al-Wajid",
		en: "The Finder",
		ku: "دۆزەرەوە"
	},
	{
		n: 65,
		ar: "الْمَاجِدُ",
		tr: "Al-Majid",
		en: "The Noble",
		ku: "بەشکۆ و بەخشندە"
	},
	{
		n: 66,
		ar: "الْوَاحِدُ",
		tr: "Al-Wahid",
		en: "The One",
		ku: "یەکتا"
	},
	{
		n: 67,
		ar: "الْأَحَدُ",
		tr: "Al-Ahad",
		en: "The Unique",
		ku: "تاک"
	},
	{
		n: 68,
		ar: "الصَّمَدُ",
		tr: "As-Samad",
		en: "The Eternal Refuge",
		ku: "پەناگای هەمیشەیی"
	},
	{
		n: 69,
		ar: "الْقَادِرُ",
		tr: "Al-Qadir",
		en: "The Able",
		ku: "توانا"
	},
	{
		n: 70,
		ar: "الْمُقْتَدِرُ",
		tr: "Al-Muqtadir",
		en: "The Powerful",
		ku: "تەواوی دەسەڵات"
	},
	{
		n: 71,
		ar: "الْمُقَدِّمُ",
		tr: "Al-Muqaddim",
		en: "The Expediter",
		ku: "پێشخەر"
	},
	{
		n: 72,
		ar: "الْمُؤَخِّرُ",
		tr: "Al-Mu'akhkhir",
		en: "The Delayer",
		ku: "دواخەر"
	},
	{
		n: 73,
		ar: "الْأَوَّلُ",
		tr: "Al-Awwal",
		en: "The First",
		ku: "یەکەم"
	},
	{
		n: 74,
		ar: "الْآخِرُ",
		tr: "Al-Akhir",
		en: "The Last",
		ku: "کۆتایی"
	},
	{
		n: 75,
		ar: "الظَّاهِرُ",
		tr: "Az-Zahir",
		en: "The Manifest",
		ku: "ئاشکرا"
	},
	{
		n: 76,
		ar: "الْبَاطِنُ",
		tr: "Al-Batin",
		en: "The Hidden",
		ku: "شاراوە"
	},
	{
		n: 77,
		ar: "الْوَالِي",
		tr: "Al-Wali",
		en: "The Governor",
		ku: "سەرپەرشتیار"
	},
	{
		n: 78,
		ar: "الْمُتَعَالِي",
		tr: "Al-Muta'ali",
		en: "The Most Exalted",
		ku: "بەرزتر لە هەموو شت"
	},
	{
		n: 79,
		ar: "الْبَرُّ",
		tr: "Al-Barr",
		en: "The Source of Goodness",
		ku: "سەرچاوەی چاکە"
	},
	{
		n: 80,
		ar: "التَّوَّابُ",
		tr: "At-Tawwab",
		en: "The Accepter of Repentance",
		ku: "تەوبەوەرگر"
	},
	{
		n: 81,
		ar: "الْمُنْتَقِمُ",
		tr: "Al-Muntaqim",
		en: "The Avenger",
		ku: "تۆڵەسەندنەوە"
	},
	{
		n: 82,
		ar: "الْعَفُوُّ",
		tr: "Al-Afuww",
		en: "The Pardoner",
		ku: "لێبووردە"
	},
	{
		n: 83,
		ar: "الرَّؤُوفُ",
		tr: "Ar-Ra'uf",
		en: "The Kind",
		ku: "نەرم و سۆزدار"
	},
	{
		n: 84,
		ar: "مَالِكُ الْمُلْكِ",
		tr: "Malik-ul-Mulk",
		en: "Owner of Sovereignty",
		ku: "خاوەنی مولک"
	},
	{
		n: 85,
		ar: "ذُو الْجَلَالِ وَالْإِكْرَامِ",
		tr: "Dhul-Jalali wal-Ikram",
		en: "Lord of Majesty and Honour",
		ku: "خاوەنی گەورەیی و ڕێز"
	},
	{
		n: 86,
		ar: "الْمُقْسِطُ",
		tr: "Al-Muqsit",
		en: "The Equitable",
		ku: "دادگەر"
	},
	{
		n: 87,
		ar: "الْجَامِعُ",
		tr: "Al-Jami",
		en: "The Gatherer",
		ku: "کۆکەرەوە"
	},
	{
		n: 88,
		ar: "الْغَنِيُّ",
		tr: "Al-Ghaniyy",
		en: "The Self-Sufficient",
		ku: "بێپێویست"
	},
	{
		n: 89,
		ar: "الْمُغْنِي",
		tr: "Al-Mughni",
		en: "The Enricher",
		ku: "دەوڵەمەندکەر"
	},
	{
		n: 90,
		ar: "الْمَانِعُ",
		tr: "Al-Mani",
		en: "The Preventer",
		ku: "قەدەغەکەر"
	},
	{
		n: 91,
		ar: "الضَّارُّ",
		tr: "Ad-Darr",
		en: "The Distresser",
		ku: "زیانبەخش بە حیکمەت"
	},
	{
		n: 92,
		ar: "النَّافِعُ",
		tr: "An-Nafi",
		en: "The Benefactor",
		ku: "سودبەخش"
	},
	{
		n: 93,
		ar: "النُّورُ",
		tr: "An-Nur",
		en: "The Light",
		ku: "ڕووناکی"
	},
	{
		n: 94,
		ar: "الْهَادِي",
		tr: "Al-Hadi",
		en: "The Guide",
		ku: "ڕێنیشانده‌ر"
	},
	{
		n: 95,
		ar: "الْبَدِيعُ",
		tr: "Al-Badi",
		en: "The Incomparable Originator",
		ku: "داهێنەری بێوێنە"
	},
	{
		n: 96,
		ar: "الْبَاقِي",
		tr: "Al-Baqi",
		en: "The Everlasting",
		ku: "هەمیشە ماو"
	},
	{
		n: 97,
		ar: "الْوَارِثُ",
		tr: "Al-Warith",
		en: "The Inheritor",
		ku: "میراتگر"
	},
	{
		n: 98,
		ar: "الرَّشِيدُ",
		tr: "Ar-Rashid",
		en: "The Guide to the Right Path",
		ku: "ڕێپیشاندەری ڕاست"
	},
	{
		n: 99,
		ar: "الصَّبُورُ",
		tr: "As-Sabur",
		en: "The Patient",
		ku: "زۆر ئارام"
	}
];
//#endregion
export { ASMA as t };
