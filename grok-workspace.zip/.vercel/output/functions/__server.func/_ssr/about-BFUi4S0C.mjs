import { w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { T as useT, d as Card } from "./router-YxvWRw5J.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-BFUi4S0C.js
var import_jsx_runtime = require_jsx_runtime();
function AboutPage() {
	const { t } = useT();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-medium",
				children: t("aboutTitle")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "space-y-3 p-5 text-sm leading-relaxed text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t("aboutBody") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t("aboutQuran") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t("aboutOffline") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t("aboutReplacement") })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "space-y-2 p-5 text-sm leading-relaxed text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-medium text-fg",
					children: t("privacy")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t("privacyBody") })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "space-y-2 p-5 text-sm leading-relaxed text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [t("version"), ": 1.0.0"] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t("installHint") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: t("androidNote") })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					className: "text-accent",
					href: "/RELEASE_NOTES.md",
					target: "_blank",
					rel: "noreferrer",
					children: t("releaseNotes")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					className: "text-accent",
					href: "/TECHNICAL_REPORT.md",
					target: "_blank",
					rel: "noreferrer",
					children: t("downloadReport")
				})]
			})
		]
	});
}
//#endregion
export { AboutPage as component };
