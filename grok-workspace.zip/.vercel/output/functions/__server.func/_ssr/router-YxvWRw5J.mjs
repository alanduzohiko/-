import { i as __toESM } from "../_runtime.mjs";
import { C as useRouter, X as require_react, _ as Outlet, b as createRootRoute, f as Scripts, g as createRouter, m as useRouterState, p as HeadContent, v as lazyRouteComponent, w as require_jsx_runtime, x as Link, y as createFileRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { S as BookOpen, _ as Clock3, d as LayoutGrid, o as Search, p as House, s as ScrollText, t as TriangleAlert } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as persist, r as create, t as createJSONStorage } from "../_libs/zustand.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { a as Madhab, i as Coordinates, n as PrayerTimes, r as CalculationMethod, t as qibla } from "../_libs/adhan.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-YxvWRw5J.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var DICT = {
	ku: {
		appName: "میحراب",
		tagline: "قورئان، نوێژ، دوعا و ئەذکار",
		chooseLanguage: "زمان هەڵبژێرە",
		chooseLanguageHint: "دەتوانیت دواتر لە ڕێکخستنەکان بیگۆڕیت. دەقە عەرەبییەکەی قورئان وەک خۆی دەمێنێتەوە.",
		continue: "بەردەوام بە",
		skip: "تێپەڕێنە",
		back: "گەڕانەوە",
		home: "سەرەکی",
		quran: "قورئان",
		prayer: "نوێژ",
		adhkar: "ئەذکار",
		more: "زیاتر",
		duas: "دوعاکان",
		tasbih: "تەسبیح",
		qibla: "قیبلە",
		names: "ناوەکانی خوا",
		bookmarks: "دڵخوازەکان",
		search: "گەڕان",
		settings: "ڕێکخستنەکان",
		about: "دەربارە",
		language: "زمان",
		theme: "ڕووکار",
		themeDark: "تاریک",
		themeLight: "ڕووناک",
		themeSystem: "سیستەم",
		location: "شوێن",
		city: "شار",
		calculationMethod: "شێوازی حیساب",
		asrMadhab: "مەزهەبی عەسر",
		shafi: "شافعی / مالکی / حەنبەلی",
		hanafi: "حەنەفی",
		notifications: "ئاگادارکردنەوەکان",
		prayerReminders: "بیرخستنەوەی نوێژ",
		enableNotifications: "چالاککردنی ئاگادارکردنەوە",
		notificationsDenied: "ڕێگەپێدان ڕەتکرایەوە. لە ڕێکخستنی وێبگەڕەکە چالاکی بکە.",
		notificationsOn: "ئاگادارکردنەوەکان چالاکن.",
		fontSize: "قەبارەی فۆنت",
		quranFontSize: "قەبارەی دەقی قورئان",
		translation: "وەرگێڕان",
		translationNone: "تەنها عەرەبی",
		translationKu: "کوردی (بورهان محەممەد ئەمین)",
		translationEn: "ئینگلیزی (موستەفا خەتتاب)",
		reciter: "قورئانخوێن",
		reciterAlafasy: "میشاری ڕاشید ئەلعەفاسی",
		reciterHusary: "مەحموود خەلیل حوسەری",
		reciterMinshawi: "محەممەد سیدەق مەنشاوی",
		nextPrayer: "نوێژی داهاتوو",
		remaining: "ماوە",
		now: "ئێستا",
		fajr: "بەیانی",
		sunrise: "خۆرهەڵات",
		dhuhr: "نیوەڕۆ",
		asr: "عەسر",
		maghrib: "مەغریب",
		isha: "عیشا",
		hour: "کاتژمێر",
		minute: "خولەک",
		hijriDate: "بەرواری کۆچی",
		gregorianDate: "بەرواری زایینی",
		quickActions: "دەستپێکی خێرا",
		morningAdhkar: "زیکری بەیانی",
		eveningAdhkar: "زیکری ئێوارە",
		afterPrayer: "دوای نوێژ",
		sleepAdhkar: "زیکری خەوتن",
		wakeAdhkar: "زیکری هەستان",
		fortress: "حوسنی موسڵمان",
		readQuran: "خوێندنەوەی قورئان",
		play: "لێدان",
		pause: "وەستان",
		stop: "ڕاگرتن",
		next: "دواتر",
		prev: "پێشوو",
		playSurah: "لێدانی سوورەت",
		playAyah: "لێدانی ئایەت",
		offlineAudio: "تەلاوەت پێویستی بە پەیوەندی هەیە. دەقەکە بەردەستە بەبێ هێڵ.",
		bookmark: "دڵخواز",
		bookmarked: "زیادکرا بۆ دڵخواز",
		unbookmark: "لابردرا لە دڵخواز",
		copy: "لەبەرگرتنەوە",
		copied: "لەبەرگیرا",
		share: "هاوبەشکردن",
		ayah: "ئایەت",
		surah: "سوورەت",
		ayahs: "ئایەت",
		meccan: "مەککی",
		medinan: "مەدەنی",
		juz: "جوزئ",
		bismillah: "بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ",
		searchPlaceholder: "گەڕان لە قورئان، دوعا و ئەذکار…",
		searchQuran: "گەڕان لە قورئان",
		searchDuas: "گەڕان لە دوعا",
		noResults: "هیچ ئەنجامێک نەدۆزرایەوە.",
		emptyBookmarks: "هێشتا هیچ دڵخوازێکت نییە. لە قورئان یان دوعاکان دڵخواز زیاد بکە.",
		emptySearch: "وشەیەک بنووسە بۆ گەڕان.",
		loading: "بارکردن…",
		retry: "دووبارە هەوڵبدە",
		loadError: "نەتوانرا ناوەڕۆک باربکرێت.",
		timesFor: "کاتەکان بۆ",
		qiblaHint: "ئاراستەی قیبلە لە شوێنەکەتەوە. ئامێرەکەت ڕوو بکە بەرەو باکوور یان لە موگناتیسی ئامێر کەڵک وەربگرە.",
		qiblaDegrees: "پلە لە باکووری ڕاستەقینە",
		compassNeed: "بۆ موگناتیسی زیندوو، ڕێگە بە جووڵەی ئامێر بدە.",
		tasbihReset: "سفرکردنەوە",
		tasbihTarget: "ئامانج",
		tasbihCount: "ژمارە",
		tapToCount: "بۆ ژمارەکردن لێرە لێبدە",
		namesOfAllah: "٩٩ ناوی جوانی خوا",
		namesHint: "ناوەکانی خوا بە عەرەبی دەمێننەوە. واتاکە بە زمانی ڕووکار پیشان دەدرێت.",
		meaning: "واتا",
		source: "سەرچاوە",
		virtue: "فەزل",
		repeat: "دووبارەکردنەوە",
		completed: "تەواو بوو",
		remainingCount: "ماوە",
		bothTimes: "بەیانی و ئێوارە",
		morningOnly: "تەنها بەیانی",
		eveningOnly: "تەنها ئێوارە",
		allCategories: "هەموو بەشەکان",
		featured: "دیارترین",
		collection: "کۆکراوە",
		verseOfMoment: "ئایەتی ئەم ساتە",
		open: "کردنەوە",
		save: "پاشەکەوت",
		close: "داخستن",
		done: "تەواو",
		detectLocation: "دۆزینەوەی شوێن",
		locating: "شوێن دەدۆزرێتەوە…",
		locationFailed: "نەتوانرا شوێن بدۆزرێتەوە. شارێک هەڵبژێرە.",
		customLocation: "شوێنی ئێستا",
		methodMWL: "کۆمەڵەی ئیسلامی جیهان",
		methodEgypt: "دەزگای میسری",
		methodUmmAlQura: "ئومولقورا (مەککە)",
		methodKarachi: "کەراچی",
		methodISNA: "ISNA (ئەمریکای باکوور)",
		methodTehran: "ئێنستیوتی جیۆفیزیکی تاران",
		methodTurkey: "دیانەتی تورکیا",
		aboutBody: "میحراب هاوڕێیەکی ئیسلامییە بە پشتگیری تەواوی زمانی کوردی سۆرانی. دەقی عەرەبی قورئان بە عوسمانی حەفس وەک خۆی پارێزراوە. وەرگێڕانی کوردی (بورهان محەممەد ئەمین) و ئینگلیزی وەک بژاردە بەردەستن.",
		aboutQuran: "دەقی قورئان نەگۆڕدراوە، نە وەرگێڕدراوەتە سەر شوێنی عەرەبی، و ڕیزبەندی ئایەت و سوورەت وەک خۆیان ماون.",
		aboutOffline: "قورئان، دوعا و ئەذکار دوای یەکەم بارکردن لەسەر ئامێرەکە دەمێننەوە. تەلاوەت پێویستی بە هێڵی ئینتەرنێت هەیە.",
		aboutReplacement: "ئەمە بەرنامەیەکی سەربەخۆیە. فایلە ئەسڵییەکانی ئەپلیکەیشنی سەرەکی لەم ژینگەیەدا نەهاتنە دەرەوە، بۆیە هاوتایەکی تەواو دروست کرا بە پشتگیری سۆرانی، بەبێ لاسایکردنەوەی ناوی پاکێج یان مۆری واژۆی ئەسڵی.",
		privacy: "نهێنیپارێزی",
		privacyBody: "هیچ ڕیکلام، چاودێری یان کۆکردنەوەی داتای کەسی نییە. ڕێکخستن و دڵخوازەکان تەنها لەسەر ئامێرەکەت دەمێننەوە.",
		version: "وەشان",
		androidNote: "لە ئەندرۆیددا دەتوانیت ئەم بەرنامەیە لە ڕێگەی «زیادکردن بۆ شاشەی سەرەکی» وەک ئەپ دابنێیت.",
		downloadReport: "ڕاپۆرتی تەکنیکی",
		releaseNotes: "تێبینی بڵاوکراوە",
		filter: "فلتەر",
		sort: "ڕیزکردن",
		byNumber: "بە ژمارە",
		byName: "بە ناو",
		jumpToAyah: "بڕۆ بۆ ئایەت",
		lastRead: "دوا خوێندنەوە",
		continueReading: "بەردەوامی خوێندنەوە",
		bookmarksAyah: "ئایەتە دڵخوازەکان",
		bookmarksDua: "دوعاکانی دڵخواز",
		confirmReset: "سفر بکرێتەوە؟",
		yes: "بەڵێ",
		no: "نەخێر",
		offline: "دەرهێڵ",
		online: "سەرهێڵ",
		audioError: "نەتوانرا دەنگ لێبدرێت. پەیوەندییەکە بپشکنە.",
		permissionLocation: "بۆ کاتی نوێژ و قیبلە، ڕێگەدان بە شوێن یارمەتیدەرە. دەتوانیت شارێکیش هەڵبژێریت.",
		onboardingCity: "شارەکەت هەڵبژێرە",
		onboardingCityHint: "بۆ کاتی نوێژ و ئاراستەی قیبلە.",
		start: "دەست پێ بکە",
		settingsSaved: "ڕێکخستنەکان پاشەکەوت کران.",
		darkMode: "دۆخی تاریک",
		largeText: "دەقی گەورە",
		aboutTitle: "دەربارەی میحراب",
		noNetwork: "ئێستا پەیوەندی نییە. ناوەڕۆکی ناوخۆیی بەردەستە.",
		countOf: "لە",
		page: "لاپەڕە",
		closePlayer: "داخستنی لێدەر",
		nowPlaying: "ئێستا دەخوێنرێت",
		allSurahs: "هەموو سوورەتەکان",
		surahList: "لیستی سوورەتەکان",
		duaList: "لیستی دوعاکان",
		notes: "تێبینی",
		read: "بخوێنەوە",
		listen: "گوێ بگرە",
		addBookmark: "زیادکردن بۆ دڵخواز",
		removeBookmark: "لابردن لە دڵخواز",
		searchAyahPlaceholder: "گەڕان لە دەق یان وەرگێڕان",
		nothingHere: "لێرە هیچ نییە.",
		methodHelp: "شێوازی حیساب گۆشەی خۆری فەجر و عیشا دیاری دەکات.",
		compassUnavailable: "موگناتیسی ئامێر لەم وێبگەڕەدا بەردەست نییە. پلەی قیبلە پیشان دراوە.",
		kaaba: "کەعبە",
		north: "باکوور",
		prayerIn: "نوێژ لە",
		passed: "تێپەڕی",
		upcoming: "داهاتوو",
		todayTimes: "کاتەکانی ئەمڕۆ",
		tomorrow: "سبەینێ",
		adjust: "ڕێکخستنی خولەک",
		minutes: "خولەک",
		highLatitude: "پانی بەرز",
		cancel: "پاشگەزبوونەوە",
		ok: "باشە",
		installHint: "بۆ بەکارهێنانی وەک ئەپ: لە وێبگەڕی ئەندرۆید «زیادکردن بۆ شاشەی سەرەکی» هەڵبژێرە.",
		reportTitle: "ڕاپۆرت",
		openSettings: "کردنەوەی ڕێکخستنەکان",
		select: "هەڵبژاردن",
		selected: "هەڵبژێردرا",
		progress: "پێشکەوتن",
		of: "لە",
		roundComplete: "خول تەواو بوو",
		keepGoing: "بەردەوام بە",
		dailyGoal: "ئامانجی ڕۆژانە",
		resetProgress: "سفرکردنەوەی پێشکەوتن",
		bookmarkAdded: "زیادکرا",
		bookmarkRemoved: "لابردرا",
		goHome: "بڕۆ بۆ سەرەکی",
		seeAll: "هەمووی ببینە",
		collections: "کۆکراوەکان",
		afterPrayerShort: "دوای سەلام",
		night: "شەو",
		morning: "بەیانی",
		evening: "ئێوارە",
		category: "بەش",
		arabicText: "دەقی عەرەبی",
		kurdishMeaning: "واتای کوردی",
		englishMeaning: "واتای ئینگلیزی",
		preserveNote: "دەقی عەرەبی قورئان نەگۆڕدراوە.",
		updateLanguage: "گۆڕینی زمان",
		languagePersists: "زمانە هەڵبژێردراوەکە دوای داخستن و کردنەوەی بەرنامەکە دەمێنێتەوە.",
		errorGeneric: "هەڵەیەک ڕوویدا. دووبارە هەوڵبدە.",
		audioLoading: "دەنگ باردەکرێت…",
		recitation: "تەلاوەت",
		translationOn: "پیشاندانی وەرگێڕان",
		translationOff: "شاردنەوەی وەرگێڕان",
		jump: "بڕۆ",
		surahNumber: "ژمارەی سوورەت",
		verseNumber: "ژمارەی ئایەت",
		foundResults: "ئەنجام",
		inQuran: "لە قورئان",
		inDuas: "لە دوعاکان",
		inAdhkar: "لە ئەذکار",
		inNames: "لە ناوەکان"
	},
	ar: {
		appName: "محراب",
		tagline: "قرآن، صلاة، دعاء وأذكار",
		chooseLanguage: "اختر اللغة",
		chooseLanguageHint: "يمكنك تغييرها لاحقًا من الإعدادات. يبقى نص القرآن العربي كما هو.",
		continue: "متابعة",
		skip: "تخطي",
		back: "رجوع",
		home: "الرئيسية",
		quran: "القرآن",
		prayer: "الصلاة",
		adhkar: "الأذكار",
		more: "المزيد",
		duas: "الأدعية",
		tasbih: "التسبيح",
		qibla: "القبلة",
		names: "أسماء الله الحسنى",
		bookmarks: "المفضلة",
		search: "بحث",
		settings: "الإعدادات",
		about: "حول",
		language: "اللغة",
		theme: "المظهر",
		themeDark: "داكن",
		themeLight: "فاتح",
		themeSystem: "النظام",
		location: "الموقع",
		city: "المدينة",
		calculationMethod: "طريقة الحساب",
		asrMadhab: "مذهب العصر",
		shafi: "شافعي / مالكي / حنبلي",
		hanafi: "حنفي",
		notifications: "الإشعارات",
		prayerReminders: "تذكير الصلاة",
		enableNotifications: "تفعيل الإشعارات",
		notificationsDenied: "رُفض الإذن. فعّله من إعدادات المتصفح.",
		notificationsOn: "الإشعارات مفعّلة.",
		fontSize: "حجم الخط",
		quranFontSize: "حجم نص القرآن",
		translation: "الترجمة",
		translationNone: "العربية فقط",
		translationKu: "كردي (برهان محمد أمين)",
		translationEn: "إنجليزي (مصطفى خطاب)",
		reciter: "القارئ",
		reciterAlafasy: "مشاري راشد العفاسي",
		reciterHusary: "محمود خليل الحصري",
		reciterMinshawi: "محمد صديق المنشاوي",
		nextPrayer: "الصلاة القادمة",
		remaining: "المتبقي",
		now: "الآن",
		fajr: "الفجر",
		sunrise: "الشروق",
		dhuhr: "الظهر",
		asr: "العصر",
		maghrib: "المغرب",
		isha: "العشاء",
		hour: "ساعة",
		minute: "دقيقة",
		hijriDate: "التاريخ الهجري",
		gregorianDate: "التاريخ الميلادي",
		quickActions: "اختصارات",
		morningAdhkar: "أذكار الصباح",
		eveningAdhkar: "أذكار المساء",
		afterPrayer: "بعد الصلاة",
		sleepAdhkar: "أذكار النوم",
		wakeAdhkar: "أذكار الاستيقاظ",
		fortress: "حصن المسلم",
		readQuran: "قراءة القرآن",
		play: "تشغيل",
		pause: "إيقاف مؤقت",
		stop: "إيقاف",
		next: "التالي",
		prev: "السابق",
		playSurah: "تشغيل السورة",
		playAyah: "تشغيل الآية",
		offlineAudio: "التلاوة تحتاج اتصالاً. النص متاح دون اتصال.",
		bookmark: "مفضلة",
		bookmarked: "أُضيفت إلى المفضلة",
		unbookmark: "أُزيلت من المفضلة",
		copy: "نسخ",
		copied: "تم النسخ",
		share: "مشاركة",
		ayah: "آية",
		surah: "سورة",
		ayahs: "آيات",
		meccan: "مكية",
		medinan: "مدنية",
		juz: "جزء",
		bismillah: "بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ",
		searchPlaceholder: "ابحث في القرآن والدعاء والأذكار…",
		searchQuran: "البحث في القرآن",
		searchDuas: "البحث في الأدعية",
		noResults: "لا توجد نتائج.",
		emptyBookmarks: "لا مفضلات بعد. أضف آيات أو أدعية.",
		emptySearch: "اكتب كلمة للبحث.",
		loading: "جارٍ التحميل…",
		retry: "إعادة المحاولة",
		loadError: "تعذّر تحميل المحتوى.",
		timesFor: "المواقيت في",
		qiblaHint: "اتجاه القبلة من موقعك. وجّه الجهاز نحو الشمال أو استخدم البوصلة.",
		qiblaDegrees: "درجة من الشمال الحقيقي",
		compassNeed: "للبوصلة الحية، اسمح بحركة الجهاز.",
		tasbihReset: "إعادة تعيين",
		tasbihTarget: "الهدف",
		tasbihCount: "العدد",
		tapToCount: "اضغط للعدّ",
		namesOfAllah: "أسماء الله الحسنى",
		namesHint: "تبقى الأسماء بالعربية. يظهر المعنى بلغة الواجهة.",
		meaning: "المعنى",
		source: "المصدر",
		virtue: "الفضل",
		repeat: "التكرار",
		completed: "اكتمل",
		remainingCount: "المتبقي",
		bothTimes: "صباحًا ومساءً",
		morningOnly: "صباحًا فقط",
		eveningOnly: "مساءً فقط",
		allCategories: "كل الأقسام",
		featured: "مختارات",
		collection: "مجموعة",
		verseOfMoment: "آية هذه اللحظة",
		open: "فتح",
		save: "حفظ",
		close: "إغلاق",
		done: "تم",
		detectLocation: "تحديد الموقع",
		locating: "جارٍ تحديد الموقع…",
		locationFailed: "تعذّر تحديد الموقع. اختر مدينة.",
		customLocation: "الموقع الحالي",
		methodMWL: "رابطة العالم الإسلامي",
		methodEgypt: "الهيئة المصرية",
		methodUmmAlQura: "أم القرى",
		methodKarachi: "كراتشي",
		methodISNA: "ISNA",
		methodTehran: "طهران",
		methodTurkey: "رئاسة الشؤون الدينية",
		aboutBody: "محراب رفيق إسلامي بدعم كامل للغة الكردية السورانية. نص القرآن العربي برواية حفص عن عاصم محفوظ كما هو. الترجمة الكردية والإنجليزية اختياريتان.",
		aboutQuran: "لم يُترجم نص القرآن العربي ولم يُستبدل ولم يُغيَّر ترتيب الآيات والسور.",
		aboutOffline: "القرآن والأدعية والأذكار تبقى على جهازك بعد التحميل الأول. التلاوة تحتاج إنترنت.",
		aboutReplacement: "هذا تطبيق مستقل. تعذّر استخراج ملفات التطبيق الأصلي في هذه البيئة، فبُني بديل مكتمل بدعم السورانية دون انتحال اسم الحزمة أو شهادة التوقيع.",
		privacy: "الخصوصية",
		privacyBody: "لا إعلانات ولا تتبع ولا جمع لبيانات شخصية. الإعدادات والمفضلة تُحفظ على جهازك فقط.",
		version: "الإصدار",
		androidNote: "على أندرويد يمكنك تثبيت التطبيق عبر «إضافة إلى الشاشة الرئيسية».",
		downloadReport: "التقرير التقني",
		releaseNotes: "ملاحظات الإصدار",
		filter: "تصفية",
		sort: "ترتيب",
		byNumber: "حسب الرقم",
		byName: "حسب الاسم",
		jumpToAyah: "الانتقال إلى آية",
		lastRead: "آخر قراءة",
		continueReading: "متابعة القراءة",
		bookmarksAyah: "آيات مفضلة",
		bookmarksDua: "أدعية مفضلة",
		confirmReset: "إعادة التعيين؟",
		yes: "نعم",
		no: "لا",
		offline: "دون اتصال",
		online: "متصل",
		audioError: "تعذّر تشغيل الصوت. تحقق من الاتصال.",
		permissionLocation: "الموقع يساعد في المواقيت والقبلة. يمكنك اختيار مدينة بدلًا من ذلك.",
		onboardingCity: "اختر مدينتك",
		onboardingCityHint: "لمواقيت الصلاة واتجاه القبلة.",
		start: "ابدأ",
		settingsSaved: "تم حفظ الإعدادات.",
		darkMode: "الوضع الداكن",
		largeText: "نص كبير",
		aboutTitle: "حول محراب",
		noNetwork: "لا اتصال حالياً. المحتوى المحلي متاح.",
		countOf: "من",
		page: "صفحة",
		closePlayer: "إغلاق المشغّل",
		nowPlaying: "يُتلى الآن",
		allSurahs: "كل السور",
		surahList: "قائمة السور",
		duaList: "قائمة الأدعية",
		notes: "حاشية",
		read: "اقرأ",
		listen: "استمع",
		addBookmark: "إضافة إلى المفضلة",
		removeBookmark: "إزالة من المفضلة",
		searchAyahPlaceholder: "ابحث في النص أو الترجمة",
		nothingHere: "لا شيء هنا.",
		methodHelp: "طريقة الحساب تحدد زاويتي الفجر والعشاء.",
		compassUnavailable: "بوصلة الجهاز غير متاحة. تُعرض درجة القبلة.",
		kaaba: "الكعبة",
		north: "الشمال",
		prayerIn: "الصلاة بعد",
		passed: "مضت",
		upcoming: "قادمة",
		todayTimes: "مواقيت اليوم",
		tomorrow: "غدًا",
		adjust: "تعديل الدقائق",
		minutes: "دقيقة",
		highLatitude: "خطوط العرض العليا",
		cancel: "إلغاء",
		ok: "حسنًا",
		installHint: "للتثبيت كتطبيق: في متصفح أندرويد اختر «إضافة إلى الشاشة الرئيسية».",
		reportTitle: "تقرير",
		openSettings: "فتح الإعدادات",
		select: "اختيار",
		selected: "محدد",
		progress: "التقدم",
		of: "من",
		roundComplete: "اكتملت الدورة",
		keepGoing: "تابع",
		dailyGoal: "هدف اليوم",
		resetProgress: "تصفير التقدم",
		bookmarkAdded: "أُضيف",
		bookmarkRemoved: "أُزيل",
		goHome: "إلى الرئيسية",
		seeAll: "عرض الكل",
		collections: "المجموعات",
		afterPrayerShort: "بعد السلام",
		night: "ليل",
		morning: "صباح",
		evening: "مساء",
		category: "قسم",
		arabicText: "النص العربي",
		kurdishMeaning: "المعنى الكردي",
		englishMeaning: "المعنى الإنجليزي",
		preserveNote: "نص القرآن العربي لم يُغيَّر.",
		updateLanguage: "تغيير اللغة",
		languagePersists: "تبقى اللغة المختارة بعد إغلاق التطبيق وإعادة فتحه.",
		errorGeneric: "حدث خطأ. حاول مرة أخرى.",
		audioLoading: "جارٍ تحميل الصوت…",
		recitation: "التلاوة",
		translationOn: "إظهار الترجمة",
		translationOff: "إخفاء الترجمة",
		jump: "انتقل",
		surahNumber: "رقم السورة",
		verseNumber: "رقم الآية",
		foundResults: "نتيجة",
		inQuran: "في القرآن",
		inDuas: "في الأدعية",
		inAdhkar: "في الأذكار",
		inNames: "في الأسماء"
	},
	en: {
		appName: "Mihrab",
		tagline: "Quran, prayer, dua and adhkar",
		chooseLanguage: "Choose a language",
		chooseLanguageHint: "You can change this later in Settings. The Arabic Quran text is never replaced.",
		continue: "Continue",
		skip: "Skip",
		back: "Back",
		home: "Home",
		quran: "Quran",
		prayer: "Prayer",
		adhkar: "Adhkar",
		more: "More",
		duas: "Supplications",
		tasbih: "Tasbih",
		qibla: "Qibla",
		names: "Names of Allah",
		bookmarks: "Bookmarks",
		search: "Search",
		settings: "Settings",
		about: "About",
		language: "Language",
		theme: "Appearance",
		themeDark: "Dark",
		themeLight: "Light",
		themeSystem: "System",
		location: "Location",
		city: "City",
		calculationMethod: "Calculation method",
		asrMadhab: "Asr school",
		shafi: "Shafi'i / Maliki / Hanbali",
		hanafi: "Hanafi",
		notifications: "Notifications",
		prayerReminders: "Prayer reminders",
		enableNotifications: "Enable notifications",
		notificationsDenied: "Permission denied. Enable it in the browser settings.",
		notificationsOn: "Notifications are on.",
		fontSize: "Text size",
		quranFontSize: "Quran text size",
		translation: "Translation",
		translationNone: "Arabic only",
		translationKu: "Kurdish (Burhan Muhammad Amin)",
		translationEn: "English (Mustafa Khattab)",
		reciter: "Reciter",
		reciterAlafasy: "Mishary Rashid Alafasy",
		reciterHusary: "Mahmoud Khalil Al-Husary",
		reciterMinshawi: "Mohamed Siddiq El-Minshawi",
		nextPrayer: "Next prayer",
		remaining: "Remaining",
		now: "Now",
		fajr: "Fajr",
		sunrise: "Sunrise",
		dhuhr: "Dhuhr",
		asr: "Asr",
		maghrib: "Maghrib",
		isha: "Isha",
		hour: "hr",
		minute: "min",
		hijriDate: "Hijri date",
		gregorianDate: "Gregorian date",
		quickActions: "Quick actions",
		morningAdhkar: "Morning adhkar",
		eveningAdhkar: "Evening adhkar",
		afterPrayer: "After prayer",
		sleepAdhkar: "Before sleep",
		wakeAdhkar: "Upon waking",
		fortress: "Fortress of the Muslim",
		readQuran: "Read the Quran",
		play: "Play",
		pause: "Pause",
		stop: "Stop",
		next: "Next",
		prev: "Previous",
		playSurah: "Play surah",
		playAyah: "Play verse",
		offlineAudio: "Recitation needs a connection. The text is available offline.",
		bookmark: "Bookmark",
		bookmarked: "Added to bookmarks",
		unbookmark: "Removed from bookmarks",
		copy: "Copy",
		copied: "Copied",
		share: "Share",
		ayah: "Ayah",
		surah: "Surah",
		ayahs: "verses",
		meccan: "Meccan",
		medinan: "Medinan",
		juz: "Juz'",
		bismillah: "بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ",
		searchPlaceholder: "Search Quran, dua and adhkar…",
		searchQuran: "Search the Quran",
		searchDuas: "Search duas",
		noResults: "No results found.",
		emptyBookmarks: "No bookmarks yet. Save a verse or a dua.",
		emptySearch: "Type a word to search.",
		loading: "Loading…",
		retry: "Try again",
		loadError: "Could not load content.",
		timesFor: "Times for",
		qiblaHint: "Qibla direction from your location. Face true north, or use the device compass.",
		qiblaDegrees: "degrees from true north",
		compassNeed: "Allow device motion for a live compass.",
		tasbihReset: "Reset",
		tasbihTarget: "Target",
		tasbihCount: "Count",
		tapToCount: "Tap to count",
		namesOfAllah: "99 Names of Allah",
		namesHint: "The Arabic names stay in Arabic. Meanings follow the interface language.",
		meaning: "Meaning",
		source: "Source",
		virtue: "Virtue",
		repeat: "Repetitions",
		completed: "Completed",
		remainingCount: "Left",
		bothTimes: "Morning and evening",
		morningOnly: "Morning only",
		eveningOnly: "Evening only",
		allCategories: "All sections",
		featured: "Featured",
		collection: "Collection",
		verseOfMoment: "Verse of the moment",
		open: "Open",
		save: "Save",
		close: "Close",
		done: "Done",
		detectLocation: "Detect location",
		locating: "Finding location…",
		locationFailed: "Could not detect location. Pick a city.",
		customLocation: "Current location",
		methodMWL: "Muslim World League",
		methodEgypt: "Egyptian Authority",
		methodUmmAlQura: "Umm al-Qura",
		methodKarachi: "Karachi",
		methodISNA: "ISNA",
		methodTehran: "Tehran",
		methodTurkey: "Diyanet",
		aboutBody: "Mihrab is an Islamic companion with complete Sorani Kurdish support. The Arabic Quran text (Hafs Uthmani) is preserved unchanged. Kurdish (Burhan Muhammad Amin) and English meanings are optional.",
		aboutQuran: "The Arabic Quran was not translated in place, replaced, or reordered.",
		aboutOffline: "Quran, duas and adhkar stay on your device after the first load. Recitation needs a network connection.",
		aboutReplacement: "This is a standalone app. The original APK files were not extractable in this environment, so a complete equivalent was built with Sorani support, without copying the original package name or signing certificate.",
		privacy: "Privacy",
		privacyBody: "No ads, no tracking, and no personal data collection. Settings and bookmarks stay on your device.",
		version: "Version",
		androidNote: "On Android you can install this app with “Add to Home screen”.",
		downloadReport: "Technical report",
		releaseNotes: "Release notes",
		filter: "Filter",
		sort: "Sort",
		byNumber: "By number",
		byName: "By name",
		jumpToAyah: "Jump to ayah",
		lastRead: "Last read",
		continueReading: "Continue reading",
		bookmarksAyah: "Saved verses",
		bookmarksDua: "Saved duas",
		confirmReset: "Reset the counter?",
		yes: "Yes",
		no: "No",
		offline: "Offline",
		online: "Online",
		audioError: "Could not play audio. Check your connection.",
		permissionLocation: "Location helps with prayer times and qibla. You can also pick a city.",
		onboardingCity: "Choose your city",
		onboardingCityHint: "Used for prayer times and qibla.",
		start: "Start",
		settingsSaved: "Settings saved.",
		darkMode: "Dark mode",
		largeText: "Larger text",
		aboutTitle: "About Mihrab",
		noNetwork: "You are offline. Local content is still available.",
		countOf: "of",
		page: "Page",
		closePlayer: "Close player",
		nowPlaying: "Now playing",
		allSurahs: "All surahs",
		surahList: "Surah list",
		duaList: "Dua list",
		notes: "Notes",
		read: "Read",
		listen: "Listen",
		addBookmark: "Add bookmark",
		removeBookmark: "Remove bookmark",
		searchAyahPlaceholder: "Search text or translation",
		nothingHere: "Nothing here yet.",
		methodHelp: "The method sets the Fajr and Isha sun angles.",
		compassUnavailable: "Device compass is not available. The qibla bearing is shown instead.",
		kaaba: "Kaaba",
		north: "North",
		prayerIn: "Prayer in",
		passed: "Passed",
		upcoming: "Upcoming",
		todayTimes: "Today's times",
		tomorrow: "Tomorrow",
		adjust: "Minute adjustment",
		minutes: "minutes",
		highLatitude: "High latitudes",
		cancel: "Cancel",
		ok: "OK",
		installHint: "To use it as an app on Android, choose “Add to Home screen” in the browser.",
		reportTitle: "Report",
		openSettings: "Open settings",
		select: "Select",
		selected: "Selected",
		progress: "Progress",
		of: "of",
		roundComplete: "Round complete",
		keepGoing: "Keep going",
		dailyGoal: "Daily goal",
		resetProgress: "Reset progress",
		bookmarkAdded: "Saved",
		bookmarkRemoved: "Removed",
		goHome: "Go home",
		seeAll: "See all",
		collections: "Collections",
		afterPrayerShort: "After salam",
		night: "Night",
		morning: "Morning",
		evening: "Evening",
		category: "Section",
		arabicText: "Arabic text",
		kurdishMeaning: "Kurdish meaning",
		englishMeaning: "English meaning",
		preserveNote: "The Arabic Quran text has not been changed.",
		updateLanguage: "Change language",
		languagePersists: "Your language stays selected after you close and reopen the app.",
		errorGeneric: "Something went wrong. Please try again.",
		audioLoading: "Loading audio…",
		recitation: "Recitation",
		translationOn: "Show translation",
		translationOff: "Hide translation",
		jump: "Go",
		surahNumber: "Surah number",
		verseNumber: "Verse number",
		foundResults: "results",
		inQuran: "in the Quran",
		inDuas: "in duas",
		inAdhkar: "in adhkar",
		inNames: "in the names"
	}
};
function t(lang, key) {
	return DICT[lang][key] ?? DICT.en[key] ?? key;
}
var CITIES = [
	{
		id: "erbil",
		ku: "هەولێر",
		ar: "أربيل",
		en: "Erbil",
		lat: 36.1911,
		lng: 44.0094,
		tz: "Asia/Baghdad"
	},
	{
		id: "slemani",
		ku: "سلێمانی",
		ar: "السليمانية",
		en: "Sulaymaniyah",
		lat: 35.5616,
		lng: 45.4376,
		tz: "Asia/Baghdad"
	},
	{
		id: "duhok",
		ku: "دهۆک",
		ar: "دهوك",
		en: "Duhok",
		lat: 36.8674,
		lng: 42.9884,
		tz: "Asia/Baghdad"
	},
	{
		id: "kirkuk",
		ku: "کەرکووک",
		ar: "كركوك",
		en: "Kirkuk",
		lat: 35.4681,
		lng: 44.3922,
		tz: "Asia/Baghdad"
	},
	{
		id: "halabja",
		ku: "هەڵەبجە",
		ar: "حلبجة",
		en: "Halabja",
		lat: 35.1778,
		lng: 45.9861,
		tz: "Asia/Baghdad"
	},
	{
		id: "zakho",
		ku: "زاخۆ",
		ar: "زاخو",
		en: "Zakho",
		lat: 37.1441,
		lng: 42.6855,
		tz: "Asia/Baghdad"
	},
	{
		id: "ranya",
		ku: "ڕانیە",
		ar: "رانية",
		en: "Ranya",
		lat: 36.255,
		lng: 44.882,
		tz: "Asia/Baghdad"
	},
	{
		id: "koya",
		ku: "کۆیە",
		ar: "كويسنجق",
		en: "Koya",
		lat: 36.0828,
		lng: 44.6278,
		tz: "Asia/Baghdad"
	},
	{
		id: "baghdad",
		ku: "بەغدا",
		ar: "بغداد",
		en: "Baghdad",
		lat: 33.3152,
		lng: 44.3661,
		tz: "Asia/Baghdad"
	},
	{
		id: "mosul",
		ku: "مووسڵ",
		ar: "الموصل",
		en: "Mosul",
		lat: 36.335,
		lng: 43.1189,
		tz: "Asia/Baghdad"
	},
	{
		id: "basra",
		ku: "بەسرە",
		ar: "البصرة",
		en: "Basra",
		lat: 30.5085,
		lng: 47.7804,
		tz: "Asia/Baghdad"
	},
	{
		id: "najaf",
		ku: "نەجەف",
		ar: "النجف",
		en: "Najaf",
		lat: 32,
		lng: 44.3356,
		tz: "Asia/Baghdad"
	},
	{
		id: "karbala",
		ku: "کەربەلا",
		ar: "كربلاء",
		en: "Karbala",
		lat: 32.616,
		lng: 44.0243,
		tz: "Asia/Baghdad"
	},
	{
		id: "makkah",
		ku: "مەککە",
		ar: "مكة المكرمة",
		en: "Makkah",
		lat: 21.4225,
		lng: 39.8262,
		tz: "Asia/Riyadh"
	},
	{
		id: "madinah",
		ku: "مەدینە",
		ar: "المدينة المنورة",
		en: "Madinah",
		lat: 24.4672,
		lng: 39.6111,
		tz: "Asia/Riyadh"
	},
	{
		id: "istanbul",
		ku: "ئیستەنبوڵ",
		ar: "إسطنبول",
		en: "Istanbul",
		lat: 41.0082,
		lng: 28.9784,
		tz: "Europe/Istanbul"
	},
	{
		id: "tehran",
		ku: "تاران",
		ar: "طهران",
		en: "Tehran",
		lat: 35.6892,
		lng: 51.389,
		tz: "Asia/Tehran"
	},
	{
		id: "amman",
		ku: "عەممان",
		ar: "عمّان",
		en: "Amman",
		lat: 31.9539,
		lng: 35.9106,
		tz: "Asia/Amman"
	},
	{
		id: "cairo",
		ku: "قاهیرە",
		ar: "القاهرة",
		en: "Cairo",
		lat: 30.0444,
		lng: 31.2357,
		tz: "Africa/Cairo"
	},
	{
		id: "london",
		ku: "لەندەن",
		ar: "لندن",
		en: "London",
		lat: 51.5074,
		lng: -.1278,
		tz: "Europe/London"
	}
];
function cityName(city, lang) {
	return city[lang];
}
function bookmarkKey(b) {
	return b.kind === "ayah" ? `a:${b.surah}:${b.ayah}` : `d:${b.id}`;
}
var useAppStore = create()(persist((set, get) => ({
	hydrated: false,
	onboarded: false,
	lang: "ku",
	theme: "dark",
	cityId: "erbil",
	customLat: null,
	customLng: null,
	customLabel: null,
	method: "MuslimWorldLeague",
	madhab: "shafi",
	translation: "ku",
	reciter: "ar.alafasy",
	quranScale: 1,
	uiScale: 1,
	notifications: false,
	bookmarks: [],
	lastRead: null,
	tasbihCount: 0,
	tasbihTarget: 33,
	adhkarProgress: {},
	setHydrated: (v) => set({ hydrated: v }),
	completeOnboarding: () => set({ onboarded: true }),
	setLang: (lang) => set({ lang }),
	setTheme: (theme) => set({ theme }),
	setCityId: (id) => set({
		cityId: id,
		customLat: null,
		customLng: null,
		customLabel: null
	}),
	setCustomLocation: (lat, lng, label) => set({
		customLat: lat,
		customLng: lng,
		customLabel: label,
		cityId: "custom"
	}),
	clearCustomLocation: () => set({
		customLat: null,
		customLng: null,
		customLabel: null,
		cityId: "erbil"
	}),
	setMethod: (method) => set({ method }),
	setMadhab: (madhab) => set({ madhab }),
	setTranslation: (translation) => set({ translation }),
	setReciter: (reciter) => set({ reciter }),
	setQuranScale: (quranScale) => set({ quranScale }),
	setUiScale: (uiScale) => set({ uiScale }),
	setNotifications: (notifications) => set({ notifications }),
	toggleBookmark: (b) => {
		const key = bookmarkKey(b);
		const cur = get().bookmarks;
		set({ bookmarks: cur.some((x) => bookmarkKey(x) === key) ? cur.filter((x) => bookmarkKey(x) !== key) : [b, ...cur] });
	},
	isBookmarked: (b) => get().bookmarks.some((x) => bookmarkKey(x) === bookmarkKey(b)),
	setLastRead: (surah, ayah) => set({ lastRead: {
		surah,
		ayah,
		at: Date.now()
	} }),
	bumpTasbih: () => set({ tasbihCount: get().tasbihCount + 1 }),
	resetTasbih: () => set({ tasbihCount: 0 }),
	setTasbihTarget: (tasbihTarget) => set({
		tasbihTarget,
		tasbihCount: 0
	}),
	setAdhkarProgress: (id, n) => set({ adhkarProgress: {
		...get().adhkarProgress,
		[id]: n
	} }),
	resetAdhkarProgress: (ids) => {
		const next = { ...get().adhkarProgress };
		for (const id of ids) delete next[id];
		set({ adhkarProgress: next });
	}
}), {
	name: "mihrab-v1",
	storage: createJSONStorage(() => localStorage),
	skipHydration: true,
	partialize: (s) => ({
		onboarded: s.onboarded,
		lang: s.lang,
		theme: s.theme,
		cityId: s.cityId,
		customLat: s.customLat,
		customLng: s.customLng,
		customLabel: s.customLabel,
		method: s.method,
		madhab: s.madhab,
		translation: s.translation,
		reciter: s.reciter,
		quranScale: s.quranScale,
		uiScale: s.uiScale,
		notifications: s.notifications,
		bookmarks: s.bookmarks,
		lastRead: s.lastRead,
		tasbihCount: s.tasbihCount,
		tasbihTarget: s.tasbihTarget,
		adhkarProgress: s.adhkarProgress
	})
}));
function getActiveCoords() {
	const s = useAppStore.getState();
	if (s.customLat != null && s.customLng != null) {
		const label = s.customLabel ?? "GPS";
		return {
			lat: s.customLat,
			lng: s.customLng,
			labelKu: label,
			labelAr: label,
			labelEn: label
		};
	}
	const city = CITIES.find((c) => c.id === s.cityId) ?? CITIES[0];
	return {
		lat: city.lat,
		lng: city.lng,
		labelKu: city.ku,
		labelAr: city.ar,
		labelEn: city.en
	};
}
function useT() {
	const lang = useAppStore((s) => s.lang);
	return {
		lang,
		t: (key) => t(lang, key)
	};
}
var TABS = [
	{
		to: "/",
		key: "home",
		icon: House
	},
	{
		to: "/quran",
		key: "quran",
		icon: BookOpen
	},
	{
		to: "/prayer",
		key: "prayer",
		icon: Clock3
	},
	{
		to: "/adhkar",
		key: "adhkar",
		icon: ScrollText
	},
	{
		to: "/more",
		key: "more",
		icon: LayoutGrid
	}
];
function AppShell({ children }) {
	const { t } = useT();
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const hideNav = pathname.startsWith("/quran/") || pathname.startsWith("/duas/") || pathname.startsWith("/adhkar/");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex min-h-dvh w-full max-w-lg flex-col bg-bg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "top-safe sticky top-0 z-20 flex items-center justify-between border-b border-border bg-bg/92 px-4 py-3 backdrop-blur-md",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					className: "text-lg font-medium tracking-tight text-fg",
					children: t("appName")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/search",
					"aria-label": t("search"),
					className: "inline-flex size-11 items-center justify-center rounded-[12px] text-fg",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
						className: "size-5",
						strokeWidth: 1.75
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: cn("flex-1 px-4 pb-28 pt-4", hideNav && "pb-8"),
				children
			}),
			!hideNav ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "bottom-nav fixed inset-x-0 bottom-0 z-30 mx-auto w-full max-w-lg border-t border-border bg-surface/95 backdrop-blur-md",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid grid-cols-5",
					children: TABS.map((tab) => {
						const active = tab.to === "/" ? pathname === "/" : pathname === tab.to || pathname.startsWith(`${tab.to}/`);
						const Icon = tab.icon;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: tab.to,
							className: cn("flex min-h-[64px] flex-col items-center justify-center gap-1 text-[11px]", active ? "text-accent" : "text-muted"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								className: "size-5",
								strokeWidth: active ? 2.2 : 1.7
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(tab.key) })]
						}) }, tab.to);
					})
				})
			}) : null
		]
	});
}
var LANGS = [
	{
		id: "ku",
		native: "کوردی (سۆرانی)",
		latin: "Sorani Kurdish",
		dir: "rtl",
		html: "ckb"
	},
	{
		id: "ar",
		native: "العربية",
		latin: "Arabic",
		dir: "rtl",
		html: "ar"
	},
	{
		id: "en",
		native: "English",
		latin: "English",
		dir: "ltr",
		html: "en"
	}
];
function isRtl(lang) {
	return lang !== "en";
}
function htmlLang(lang) {
	return LANGS.find((l) => l.id === lang)?.html ?? "ckb";
}
var ARABIC_DIGITS = "٠١٢٣٤٥٦٧٨٩";
function formatNumber(n, lang) {
	const s = String(n);
	if (lang === "en") return s;
	return s.replace(/[0-9]/g, (d) => ARABIC_DIGITS[Number(d)] ?? d);
}
function pad2(n) {
	return n < 10 ? `0${n}` : String(n);
}
function formatClock(date, lang) {
	const h = date.getHours();
	const m = date.getMinutes();
	if (lang === "en") {
		const ap = h >= 12 ? "PM" : "AM";
		return `${h % 12 || 12}:${pad2(m)} ${ap}`;
	}
	return `${formatNumber(pad2(h), lang)}:${formatNumber(pad2(m), lang)}`;
}
function formatDuration(ms, lang, t) {
	if (ms < 0) ms = 0;
	const totalMin = Math.floor(ms / 6e4);
	const h = Math.floor(totalMin / 60);
	const m = totalMin % 60;
	if (h <= 0) return `${formatNumber(m, lang)} ${t("minute")}`;
	return `${formatNumber(h, lang)} ${t("hour")} ${formatNumber(m, lang)} ${t("minute")}`;
}
var HIJRI_MONTHS = {
	ku: [
		"محەڕەم",
		"سەفەر",
		"ڕەبیعولئەووەل",
		"ڕەبیعولئاخیر",
		"جومادالئوولا",
		"جومادالئاخیرە",
		"ڕەجەب",
		"شەعبان",
		"ڕەمەزان",
		"شەووال",
		"زولقەعدە",
		"زولحیججە"
	],
	ar: [
		"محرم",
		"صفر",
		"ربيع الأول",
		"ربيع الآخر",
		"جمادى الأولى",
		"جمادى الآخرة",
		"رجب",
		"شعبان",
		"رمضان",
		"شوال",
		"ذو القعدة",
		"ذو الحجة"
	],
	en: [
		"Muharram",
		"Safar",
		"Rabi' al-Awwal",
		"Rabi' al-Thani",
		"Jumada al-Ula",
		"Jumada al-Akhirah",
		"Rajab",
		"Sha'ban",
		"Ramadan",
		"Shawwal",
		"Dhul-Qa'dah",
		"Dhul-Hijjah"
	]
};
var GREG_MONTHS = {
	ku: [
		"کانوونی دووەم",
		"شوبات",
		"ئازار",
		"نیسان",
		"ئایار",
		"حوزەیران",
		"تەممووز",
		"ئاب",
		"ئەیلوول",
		"تشرینی یەکەم",
		"تشرینی دووەم",
		"کانوونی یەکەم"
	],
	ar: [
		"يناير",
		"فبراير",
		"مارس",
		"أبريل",
		"مايو",
		"يونيو",
		"يوليو",
		"أغسطس",
		"سبتمبر",
		"أكتوبر",
		"نوفمبر",
		"ديسمبر"
	],
	en: [
		"January",
		"February",
		"March",
		"April",
		"May",
		"June",
		"July",
		"August",
		"September",
		"October",
		"November",
		"December"
	]
};
var WEEKDAYS = {
	ku: [
		"یەکشەممە",
		"دووشەممە",
		"سێشەممە",
		"چوارشەممە",
		"پێنجشەممە",
		"هەینی",
		"شەممە"
	],
	ar: [
		"الأحد",
		"الاثنين",
		"الثلاثاء",
		"الأربعاء",
		"الخميس",
		"الجمعة",
		"السبت"
	],
	en: [
		"Sunday",
		"Monday",
		"Tuesday",
		"Wednesday",
		"Thursday",
		"Friday",
		"Saturday"
	]
};
function weekdayName(date, lang) {
	return WEEKDAYS[lang][date.getDay()] ?? "";
}
function formatGregorian(date, lang) {
	const d = date.getDate();
	const m = GREG_MONTHS[lang][date.getMonth()];
	const y = date.getFullYear();
	return `${formatNumber(d, lang)} ${m} ${formatNumber(y, lang)}`;
}
function formatHijri(date, lang) {
	try {
		const parts = new Intl.DateTimeFormat("en-u-ca-islamic-umalqura", {
			day: "numeric",
			month: "numeric",
			year: "numeric"
		}).formatToParts(date);
		const day = Number(parts.find((p) => p.type === "day")?.value ?? "1");
		const month = Number(parts.find((p) => p.type === "month")?.value ?? "1");
		const year = Number(parts.find((p) => p.type === "year")?.value ?? "1447");
		const monthName = HIJRI_MONTHS[lang][month - 1] ?? "";
		return `${formatNumber(day, lang)} ${monthName} ${formatNumber(year, lang)}`;
	} catch {
		return "";
	}
}
function Button({ variant = "primary", className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		className: cn("inline-flex min-h-11 items-center justify-center gap-2 rounded-[12px] px-4 text-sm font-medium transition-opacity duration-150 disabled:opacity-40", {
			primary: "bg-accent text-accent-fg hover:opacity-92",
			ghost: "bg-transparent text-fg hover:bg-surface-2",
			outline: "bg-transparent text-fg border border-border-strong hover:bg-surface-2",
			danger: "bg-danger text-fg hover:opacity-92"
		}[variant], className),
		...props
	});
}
function Card({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("rounded-[24px] border border-border bg-surface p-4 shadow-soft", className),
		...props
	});
}
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn("h-11 w-full rounded-[12px] border border-border bg-surface-2 px-3 text-base text-fg outline-none placeholder:text-faint focus:border-border-strong", className),
		...props
	});
}
function SectionTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
		className: cn("text-sm font-medium text-muted", className),
		...props
	});
}
function Chip({ active, className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		className: cn("inline-flex min-h-10 items-center rounded-full border px-3 text-sm", active ? "border-accent bg-accent text-accent-fg" : "border-border bg-surface-2 text-fg", className),
		...props
	});
}
function Empty({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "px-6 py-16 text-center text-sm text-muted",
		children
	});
}
function Spinner() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex items-center justify-center py-16",
		role: "status",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-6 w-6 animate-spin rounded-full border-2 border-border-strong border-t-accent" })
	});
}
function Onboarding() {
	const { t, lang } = useT();
	const setLang = useAppStore((s) => s.setLang);
	const setCityId = useAppStore((s) => s.setCityId);
	const cityId = useAppStore((s) => s.cityId);
	const complete = useAppStore((s) => s.completeOnboarding);
	const [step, setStep] = (0, import_react.useState)(0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex min-h-dvh max-w-lg flex-col bg-bg px-5 py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: t("appName")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 text-3xl font-medium tracking-tight",
						children: t("chooseLanguage")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-prose text-sm leading-relaxed text-muted",
						children: step === 0 ? t("chooseLanguageHint") : t("onboardingCityHint")
					})
				]
			}),
			step === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3",
				children: LANGS.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setLang(l.id),
					className: `rounded-[20px] border px-4 py-4 text-start ${lang === l.id ? "border-accent bg-surface" : "border-border bg-surface-2"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-lg",
						children: l.native
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-1 text-sm text-muted",
						children: l.latin
					})]
				}, l.id))
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid max-h-[55vh] gap-2 overflow-auto pr-1",
				children: CITIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setCityId(c.id),
					className: `rounded-[16px] border px-4 py-3 text-start ${cityId === c.id ? "border-accent bg-surface" : "border-border bg-surface-2"}`,
					children: cityName(c, lang)
				}, c.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-auto flex gap-3 pt-8",
				children: [step === 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					className: "flex-1",
					onClick: () => setStep(0),
					children: t("back")
				}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "flex-1",
					onClick: () => {
						if (step === 0) setStep(1);
						else complete();
					},
					children: step === 0 ? t("continue") : t("start")
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "mt-4 p-3 text-xs leading-relaxed text-muted",
				children: t("preserveNote")
			})
		]
	});
}
var PRAYER_ORDER = [
	"fajr",
	"sunrise",
	"dhuhr",
	"asr",
	"maghrib",
	"isha"
];
function paramsFor(method, madhab) {
	const p = (method === "Egyptian" ? CalculationMethod.Egyptian : method === "UmmAlQura" ? CalculationMethod.UmmAlQura : method === "Karachi" ? CalculationMethod.Karachi : method === "NorthAmerica" ? CalculationMethod.NorthAmerica : method === "Tehran" ? CalculationMethod.Tehran : method === "Turkey" ? CalculationMethod.Turkey : CalculationMethod.MuslimWorldLeague)();
	p.madhab = madhab === "hanafi" ? Madhab.Hanafi : Madhab.Shafi;
	return p;
}
function computePrayerTimes(lat, lng, date, method, madhab) {
	const coords = new Coordinates(lat, lng);
	const pt = new PrayerTimes(coords, date, paramsFor(method, madhab));
	return {
		fajr: pt.fajr,
		sunrise: pt.sunrise,
		dhuhr: pt.dhuhr,
		asr: pt.asr,
		maghrib: pt.maghrib,
		isha: pt.isha
	};
}
function nextPrayer(times, now = /* @__PURE__ */ new Date()) {
	for (const id of PRAYER_ORDER) {
		if (id === "sunrise") continue;
		if (times[id].getTime() > now.getTime()) return {
			id,
			at: times[id]
		};
	}
	return null;
}
function currentPrayer(times, now = /* @__PURE__ */ new Date()) {
	const seq = [
		"fajr",
		"dhuhr",
		"asr",
		"maghrib",
		"isha"
	];
	let cur = null;
	for (const id of seq) if (now.getTime() >= times[id].getTime()) cur = id;
	return cur;
}
function qiblaBearing(lat, lng) {
	return qibla(new Coordinates(lat, lng));
}
var KEY = "mihrab-notified";
function startPrayerReminders() {
	const tick = () => {
		const s = useAppStore.getState();
		if (!s.notifications || typeof Notification === "undefined" || Notification.permission !== "granted") return;
		const coords = getActiveCoords();
		const now = /* @__PURE__ */ new Date();
		const upcoming = nextPrayer(computePrayerTimes(coords.lat, coords.lng, now, s.method, s.madhab), now);
		if (!upcoming) return;
		const diff = upcoming.at.getTime() - now.getTime();
		if (diff > 9e4 || diff < 0) return;
		const stamp = `${now.toDateString()}-${upcoming.id}`;
		if (sessionStorage.getItem(KEY) === stamp) return;
		sessionStorage.setItem(KEY, stamp);
		const name = t(s.lang, upcoming.id === "sunrise" ? "sunrise" : upcoming.id);
		try {
			new Notification(t(s.lang, "appName"), { body: `${t(s.lang, "nextPrayer")}: ${name}` });
		} catch {}
	};
	tick();
	const id = window.setInterval(tick, 3e4);
	return () => window.clearInterval(id);
}
var styles_default = "/assets/styles-CXe3NovM.css";
var APP_NAME = "میحراب";
function RootInner() {
	const hydrated = useAppStore((s) => s.hydrated);
	const onboarded = useAppStore((s) => s.onboarded);
	const lang = useAppStore((s) => s.lang);
	const theme = useAppStore((s) => s.theme);
	const uiScale = useAppStore((s) => s.uiScale);
	const setHydrated = useAppStore((s) => s.setHydrated);
	(0, import_react.useEffect)(() => {
		const result = useAppStore.persist.rehydrate();
		Promise.resolve(result).then(() => setHydrated(true));
	}, [setHydrated]);
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		const root = document.documentElement;
		root.lang = htmlLang(lang);
		root.dir = isRtl(lang) ? "rtl" : "ltr";
		root.dataset.theme = theme;
		root.style.fontSize = `${16 * uiScale}px`;
	}, [
		hydrated,
		lang,
		theme,
		uiScale
	]);
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		return startPrayerReminders();
	}, [hydrated]);
	if (!hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "min-h-dvh bg-bg" });
	if (!onboarded) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Onboarding, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) });
}
var Route$16 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1, viewport-fit=cover"
			},
			{ title: APP_NAME },
			{
				name: "theme-color",
				content: "#0c1210"
			},
			{
				name: "description",
				content: "قورئان، نوێژ، دوعا و ئەذکار بە کوردی سۆرانی"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Noto+Naskh+Arabic:wght@400;500;600;700&family=Noto+Sans+Arabic:wght@400;500;600;700&display=swap"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "ckb",
		dir: "rtl",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RootInner, {}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				position: "top-center",
				theme: "dark"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	})
});
var $$splitComponentImporter$15 = () => import("./routes-ConfmVzX.mjs");
var Route$15 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$15, "component") });
var $$splitComponentImporter$14 = () => import("./about-BFUi4S0C.mjs");
var Route$14 = createFileRoute("/about")({ component: lazyRouteComponent($$splitComponentImporter$14, "component") });
var $$splitComponentImporter$13 = () => import("./adhkar-BMzcyr7i.mjs");
var Route$13 = createFileRoute("/adhkar")({ component: lazyRouteComponent($$splitComponentImporter$13, "component") });
var $$splitComponentImporter$12 = () => import("./bookmarks-DrrXoyiO.mjs");
var Route$12 = createFileRoute("/bookmarks")({ component: lazyRouteComponent($$splitComponentImporter$12, "component") });
var $$splitComponentImporter$11 = () => import("./duas-CcpuxW2U.mjs");
var Route$11 = createFileRoute("/duas")({ component: lazyRouteComponent($$splitComponentImporter$11, "component") });
var $$splitComponentImporter$10 = () => import("./more-CwIagcmj.mjs");
var Route$10 = createFileRoute("/more")({ component: lazyRouteComponent($$splitComponentImporter$10, "component") });
var $$splitComponentImporter$9 = () => import("./names-Hn3Gza3j.mjs");
var Route$9 = createFileRoute("/names")({ component: lazyRouteComponent($$splitComponentImporter$9, "component") });
var $$splitComponentImporter$8 = () => import("./prayer-ChUZdNCo.mjs");
var Route$8 = createFileRoute("/prayer")({ component: lazyRouteComponent($$splitComponentImporter$8, "component") });
var $$splitComponentImporter$7 = () => import("./qibla-C7uCSgjL.mjs");
var Route$7 = createFileRoute("/qibla")({ component: lazyRouteComponent($$splitComponentImporter$7, "component") });
var $$splitComponentImporter$6 = () => import("./quran-DLSZR0ix.mjs");
var Route$6 = createFileRoute("/quran")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./search-DthDvWkP.mjs");
var Route$5 = createFileRoute("/search")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./settings-Bnu2eVme.mjs");
var Route$4 = createFileRoute("/settings")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./tasbih-BJqTiE9M.mjs");
var Route$3 = createFileRoute("/tasbih")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./adhkar._id-CI0MLDJK.mjs");
var Route$2 = createFileRoute("/adhkar/$id")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./duas._id-DOY5p_aa.mjs");
var Route$1 = createFileRoute("/duas/$id")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./quran._n-DWuBhLuN.mjs");
var Route = createFileRoute("/quran/$n")({
	validateSearch: (s) => ({ ayah: typeof s.ayah === "number" ? s.ayah : s.ayah ? Number(s.ayah) : void 0 }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var IndexRoute = Route$15.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$16
});
var AboutRoute = Route$14.update({
	id: "/about",
	path: "/about",
	getParentRoute: () => Route$16
});
var AdhkarRoute = Route$13.update({
	id: "/adhkar",
	path: "/adhkar",
	getParentRoute: () => Route$16
});
var BookmarksRoute = Route$12.update({
	id: "/bookmarks",
	path: "/bookmarks",
	getParentRoute: () => Route$16
});
var DuasRoute = Route$11.update({
	id: "/duas",
	path: "/duas",
	getParentRoute: () => Route$16
});
var MoreRoute = Route$10.update({
	id: "/more",
	path: "/more",
	getParentRoute: () => Route$16
});
var NamesRoute = Route$9.update({
	id: "/names",
	path: "/names",
	getParentRoute: () => Route$16
});
var PrayerRoute = Route$8.update({
	id: "/prayer",
	path: "/prayer",
	getParentRoute: () => Route$16
});
var QiblaRoute = Route$7.update({
	id: "/qibla",
	path: "/qibla",
	getParentRoute: () => Route$16
});
var QuranRoute = Route$6.update({
	id: "/quran",
	path: "/quran",
	getParentRoute: () => Route$16
});
var SearchRoute = Route$5.update({
	id: "/search",
	path: "/search",
	getParentRoute: () => Route$16
});
var SettingsRoute = Route$4.update({
	id: "/settings",
	path: "/settings",
	getParentRoute: () => Route$16
});
var TasbihRoute = Route$3.update({
	id: "/tasbih",
	path: "/tasbih",
	getParentRoute: () => Route$16
});
var AdhkarIdRoute = Route$2.update({
	id: "/$id",
	path: "/$id",
	getParentRoute: () => AdhkarRoute
});
var DuasIdRoute = Route$1.update({
	id: "/$id",
	path: "/$id",
	getParentRoute: () => DuasRoute
});
var QuranNRoute = Route.update({
	id: "/$n",
	path: "/$n",
	getParentRoute: () => QuranRoute
});
var AdhkarRouteChildren = { AdhkarIdRoute };
var AdhkarRouteWithChildren = AdhkarRoute._addFileChildren(AdhkarRouteChildren);
var DuasRouteChildren = { DuasIdRoute };
var DuasRouteWithChildren = DuasRoute._addFileChildren(DuasRouteChildren);
var QuranRouteChildren = { QuranNRoute };
var rootRouteChildren = {
	IndexRoute,
	AboutRoute,
	AdhkarRoute: AdhkarRouteWithChildren,
	BookmarksRoute,
	DuasRoute: DuasRouteWithChildren,
	MoreRoute,
	NamesRoute,
	PrayerRoute,
	QiblaRoute,
	QuranRoute: QuranRoute._addFileChildren(QuranRouteChildren),
	SearchRoute,
	SettingsRoute,
	TasbihRoute
};
var routeTree = Route$16._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { t as A, isRtl as C, useAppStore as D, getActiveCoords as E, CITIES as O, formatNumber as S, useT as T, LANGS as _, PRAYER_ORDER as a, formatGregorian as b, nextPrayer as c, Card as d, Chip as f, Spinner as g, SectionTitle as h, Route$2 as i, cn as j, cityName as k, qiblaBearing as l, Input as m, Route as n, computePrayerTimes as o, Empty as p, Route$1 as r, currentPrayer as s, router_exports as t, Button as u, formatClock as v, weekdayName as w, formatHijri as x, formatDuration as y };
