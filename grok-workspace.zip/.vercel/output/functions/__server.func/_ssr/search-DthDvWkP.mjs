import { i as __toESM } from "../_runtime.mjs";
import { X as require_react, w as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { D as useAppStore, S as formatNumber, T as useT, g as Spinner, h as SectionTitle, m as Input } from "./router-YxvWRw5J.mjs";
import { i as loadHisn } from "./content-By8KyBT8.mjs";
import { a as loadMeta, i as loadKu, n as loadArabic, r as loadEn, s as surahDisplayName } from "./quran-DO9SoaPp.mjs";
import { t as ASMA } from "./asma-DPftgxM1.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/search-DthDvWkP.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SearchPage() {
	const { t, lang } = useT();
	const translation = useAppStore((s) => s.translation);
	const [q, setQ] = (0, import_react.useState)("");
	const [ready, setReady] = (0, import_react.useState)(false);
	const [meta, setMeta] = (0, import_react.useState)([]);
	const [ar, setAr] = (0, import_react.useState)([]);
	const [tr, setTr] = (0, import_react.useState)(null);
	const [hisn, setHisn] = (0, import_react.useState)([]);
	const [ayahHits, setAyahHits] = (0, import_react.useState)([]);
	const [duaHits, setDuaHits] = (0, import_react.useState)([]);
	const [nameHits, setNameHits] = (0, import_react.useState)([]);
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		(async () => {
			const [m, a, h] = await Promise.all([
				loadMeta(),
				loadArabic(),
				loadHisn()
			]);
			setMeta(m);
			setAr(a);
			setHisn(h);
			setReady(true);
		})();
	}, []);
	(0, import_react.useEffect)(() => {
		if (translation === "none") {
			setTr(null);
			return;
		}
		(translation === "ku" ? loadKu() : loadEn()).then(setTr);
	}, [translation]);
	(0, import_react.useEffect)(() => {
		const s = q.trim();
		if (s.length < 2) {
			setAyahHits([]);
			setDuaHits([]);
			setNameHits([]);
			return;
		}
		setBusy(true);
		const id = window.setTimeout(() => {
			const low = s.toLowerCase();
			const ayahs = [];
			outer: for (let si = 0; si < ar.length; si++) {
				const verses = ar[si] ?? [];
				for (let ai = 0; ai < verses.length; ai++) {
					const text = verses[ai] ?? "";
					const meaning = tr?.[si]?.[ai] ?? "";
					if (text.includes(s) || meaning.toLowerCase().includes(low)) {
						const surah = meta[si];
						ayahs.push({
							surah: si + 1,
							ayah: ai + 1,
							ar: text,
							tr: meaning || void 0,
							name: surah ? surahDisplayName(surah, lang) : String(si + 1)
						});
						if (ayahs.length >= 30) break outer;
					}
				}
			}
			const duas = [];
			for (const item of hisn) {
				const title = lang === "ku" ? item.ku : lang === "ar" ? item.ar : item.en;
				const blob = `${item.ar} ${item.ku} ${item.en} ${item.texts.join(" ")}`;
				if (blob.toLowerCase().includes(low) || blob.includes(s)) {
					duas.push({
						id: item.id,
						title,
						snippet: item.texts[0] ?? item.ar
					});
					if (duas.length >= 20) break;
				}
			}
			const names = ASMA.filter((n) => n.ar.includes(s) || n.ku.includes(s) || n.en.toLowerCase().includes(low) || n.tr.toLowerCase().includes(low)).slice(0, 12);
			setAyahHits(ayahs);
			setDuaHits(duas);
			setNameHits(names);
			setBusy(false);
		}, 180);
		return () => window.clearTimeout(id);
	}, [
		q,
		ar,
		tr,
		hisn,
		meta,
		lang
	]);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spinner, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-medium",
				children: t("search")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value: q,
				onChange: (e) => setQ(e.target.value),
				placeholder: t("searchPlaceholder"),
				autoFocus: true
			}),
			q.trim().length < 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: t("emptySearch")
			}) : null,
			busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-faint",
				children: t("loading")
			}) : null,
			q.trim().length >= 2 && !busy && !ayahHits.length && !duaHits.length && !nameHits.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: t("noResults")
			}) : null,
			ayahHits.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SectionTitle, {
				className: "mb-2",
				children: [
					t("inQuran"),
					" · ",
					formatNumber(ayahHits.length, lang)
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2",
				children: ayahHits.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/quran/$n",
					params: { n: String(h.surah) },
					search: { ayah: h.ayah },
					className: "block rounded-[16px] border border-border bg-surface p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted",
						children: [
							h.name,
							" · ",
							t("ayah"),
							" ",
							formatNumber(h.ayah, lang)
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-quran mt-1 line-clamp-2",
						dir: "rtl",
						children: h.ar
					})]
				}) }, `${h.surah}:${h.ayah}`))
			})] }) : null,
			duaHits.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
				className: "mb-2",
				children: t("inDuas")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2",
				children: duaHits.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/duas/$id",
					params: { id: h.id },
					className: "block rounded-[16px] border border-border bg-surface p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium",
						children: h.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-quran mt-1 line-clamp-2 text-sm",
						dir: "rtl",
						children: h.snippet
					})]
				}) }, h.id))
			})] }) : null,
			nameHits.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
				className: "mb-2",
				children: t("inNames")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2",
				children: nameHits.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-[16px] border border-border bg-surface p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-quran text-xl",
						dir: "rtl",
						children: n.ar
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: lang === "ku" ? n.ku : lang === "ar" ? n.tr : n.en
					})]
				}, n.n))
			})] }) : null
		]
	});
}
//#endregion
export { SearchPage as component };
