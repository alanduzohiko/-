import { w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { D as useAppStore, O as CITIES, T as useT, _ as LANGS, d as Card, f as Chip, h as SectionTitle, k as cityName, u as Button } from "./router-YxvWRw5J.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-Bnu2eVme.js
var import_jsx_runtime = require_jsx_runtime();
var METHODS = [
	{
		id: "MuslimWorldLeague",
		key: "methodMWL"
	},
	{
		id: "Egyptian",
		key: "methodEgypt"
	},
	{
		id: "UmmAlQura",
		key: "methodUmmAlQura"
	},
	{
		id: "Karachi",
		key: "methodKarachi"
	},
	{
		id: "NorthAmerica",
		key: "methodISNA"
	},
	{
		id: "Tehran",
		key: "methodTehran"
	},
	{
		id: "Turkey",
		key: "methodTurkey"
	}
];
var RECITERS = [
	{
		id: "ar.alafasy",
		key: "reciterAlafasy"
	},
	{
		id: "ar.husary",
		key: "reciterHusary"
	},
	{
		id: "ar.minshawi",
		key: "reciterMinshawi"
	}
];
function SettingsPage() {
	const { t, lang } = useT();
	const store = useAppStore();
	async function enableNotes() {
		if (!("Notification" in window)) {
			toast.error(t("notificationsDenied"));
			return;
		}
		if (await Notification.requestPermission() === "granted") {
			store.setNotifications(true);
			toast.success(t("notificationsOn"));
		} else {
			store.setNotifications(false);
			toast.error(t("notificationsDenied"));
		}
	}
	async function detect() {
		toast.message(t("locating"));
		navigator.geolocation.getCurrentPosition((pos) => {
			store.setCustomLocation(pos.coords.latitude, pos.coords.longitude, t("customLocation"));
			toast.success(t("settingsSaved"));
		}, () => toast.error(t("locationFailed")), {
			enableHighAccuracy: true,
			timeout: 8e3
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-medium",
				children: t("settings")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
					className: "mb-2",
					children: t("language")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-3 text-xs text-muted",
					children: t("languagePersists")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-2",
					children: LANGS.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
						active: lang === l.id,
						onClick: () => store.setLang(l.id),
						children: l.native
					}, l.id))
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
				className: "mb-2",
				children: t("theme")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
					active: store.theme === "dark",
					onClick: () => store.setTheme("dark"),
					children: t("themeDark")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
					active: store.theme === "light",
					onClick: () => store.setTheme("light"),
					children: t("themeLight")
				})]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
					className: "mb-2",
					children: t("city")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					className: "mb-3 w-full",
					onClick: () => void detect(),
					children: t("detectLocation")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid max-h-56 gap-2 overflow-auto",
					children: CITIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => store.setCityId(c.id),
						className: `rounded-[14px] border px-3 py-2 text-start text-sm ${store.cityId === c.id && store.customLat == null ? "border-accent bg-surface" : "border-border bg-surface-2"}`,
						children: cityName(c, lang)
					}, c.id))
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
					className: "mb-2",
					children: t("calculationMethod")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 text-xs text-muted",
					children: t("methodHelp")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-2",
					children: METHODS.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
						active: store.method === m.id,
						onClick: () => store.setMethod(m.id),
						children: t(m.key)
					}, m.id))
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
				className: "mb-2",
				children: t("asrMadhab")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
					active: store.madhab === "shafi",
					onClick: () => store.setMadhab("shafi"),
					children: t("shafi")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
					active: store.madhab === "hanafi",
					onClick: () => store.setMadhab("hanafi"),
					children: t("hanafi")
				})]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
				className: "mb-2",
				children: t("translation")
			}), [
				["none", "translationNone"],
				["ku", "translationKu"],
				["en", "translationEn"]
			].map(([id, key]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
				className: "mb-2 me-2",
				active: store.translation === id,
				onClick: () => store.setTranslation(id),
				children: t(key)
			}, id))] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
				className: "mb-2",
				children: t("reciter")
			}), RECITERS.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
				className: "mb-2 me-2",
				active: store.reciter === r.id,
				onClick: () => store.setReciter(r.id),
				children: t(r.key)
			}, r.id))] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
				className: "mb-2",
				children: t("quranFontSize")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "range",
				min: .85,
				max: 1.45,
				step: .05,
				value: store.quranScale,
				onChange: (e) => store.setQuranScale(Number(e.target.value)),
				className: "w-full"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
				className: "mb-2",
				children: t("fontSize")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "range",
				min: .9,
				max: 1.25,
				step: .05,
				value: store.uiScale,
				onChange: (e) => store.setUiScale(Number(e.target.value)),
				className: "w-full"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
				className: "mb-2",
				children: t("notifications")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: t("prayerReminders")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-3 w-full",
					onClick: () => void enableNotes(),
					children: t("enableNotifications")
				})]
			})] })
		]
	});
}
//#endregion
export { SettingsPage as component };
