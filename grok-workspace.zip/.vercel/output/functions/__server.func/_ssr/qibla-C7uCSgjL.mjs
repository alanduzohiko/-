import { i as __toESM } from "../_runtime.mjs";
import { X as require_react, w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as getActiveCoords, S as formatNumber, T as useT, d as Card, l as qiblaBearing } from "./router-YxvWRw5J.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/qibla-C7uCSgjL.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function QiblaPage() {
	const { t, lang } = useT();
	const coords = getActiveCoords();
	const bearing = (0, import_react.useMemo)(() => qiblaBearing(coords.lat, coords.lng), [coords.lat, coords.lng]);
	const [heading, setHeading] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const handler = (e) => {
			const h = e.webkitCompassHeading ?? (typeof e.alpha === "number" ? 360 - e.alpha : null);
			if (h != null) setHeading(h);
		};
		window.addEventListener("deviceorientation", handler);
		return () => window.removeEventListener("deviceorientation", handler);
	}, []);
	const rotation = heading == null ? bearing : bearing - heading;
	const city = lang === "ku" ? coords.labelKu : lang === "ar" ? coords.labelAr : coords.labelEn;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-medium",
				children: t("qibla")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: city
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "flex flex-col items-center p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative size-64",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 rounded-full border border-border-strong" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-6 rounded-full border border-border" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute inset-0 flex items-start justify-center pt-4 transition-transform duration-200",
								style: { transform: `rotate(${rotation}deg)` },
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-24 w-1 rounded-full bg-accent" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "absolute inset-0 flex items-center justify-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs text-muted",
									children: t("kaaba")
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "absolute top-2 left-1/2 -translate-x-1/2 text-[10px] text-faint",
								children: t("north")
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-6 tabular-nums text-2xl font-medium",
						children: [formatNumber(Math.round(bearing), lang), "°"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: t("qiblaDegrees")
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm leading-relaxed text-muted",
				children: heading == null ? t("compassUnavailable") : t("qiblaHint")
			})
		]
	});
}
//#endregion
export { QiblaPage as component };
