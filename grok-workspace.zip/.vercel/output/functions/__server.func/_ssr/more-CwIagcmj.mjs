import { w as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Settings, b as Bookmark, f as Info, g as Compass, i as Sparkles, m as Hash, o as Search, s as ScrollText } from "../_libs/lucide-react.mjs";
import { T as useT } from "./router-YxvWRw5J.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/more-CwIagcmj.js
var import_jsx_runtime = require_jsx_runtime();
var ITEMS = [
	{
		to: "/duas",
		key: "duas",
		icon: ScrollText
	},
	{
		to: "/tasbih",
		key: "tasbih",
		icon: Hash
	},
	{
		to: "/qibla",
		key: "qibla",
		icon: Compass
	},
	{
		to: "/names",
		key: "names",
		icon: Sparkles
	},
	{
		to: "/bookmarks",
		key: "bookmarks",
		icon: Bookmark
	},
	{
		to: "/search",
		key: "search",
		icon: Search
	},
	{
		to: "/settings",
		key: "settings",
		icon: Settings
	},
	{
		to: "/about",
		key: "about",
		icon: Info
	}
];
function MorePage() {
	const { t } = useT();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-2xl font-medium",
			children: t("more")
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "overflow-hidden rounded-[24px] border border-border bg-surface",
			children: ITEMS.map((it) => {
				const Icon = it.icon;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "border-b border-border last:border-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: it.to,
						className: "flex min-h-14 items-center gap-3 px-4 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
							className: "size-5 text-muted",
							strokeWidth: 1.75
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(it.key) })]
					})
				}, it.to);
			})
		})]
	});
}
//#endregion
export { MorePage as component };
