import { i as __toESM } from "../_runtime.mjs";
import { X as require_react, w as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { D as useAppStore, S as formatNumber, T as useT, g as Spinner, h as SectionTitle, p as Empty } from "./router-YxvWRw5J.mjs";
import { i as loadHisn } from "./content-By8KyBT8.mjs";
import { a as loadMeta, n as loadArabic, s as surahDisplayName } from "./quran-DO9SoaPp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/bookmarks-DrrXoyiO.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function BookmarksPage() {
	const { t, lang } = useT();
	const bookmarks = useAppStore((s) => s.bookmarks);
	const [meta, setMeta] = (0, import_react.useState)(null);
	const [ar, setAr] = (0, import_react.useState)(null);
	const [hisn, setHisn] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		Promise.all([
			loadMeta(),
			loadArabic(),
			loadHisn()
		]).then(([m, a, h]) => {
			setMeta(m);
			setAr(a);
			setHisn(h);
		});
	}, []);
	const ayahs = bookmarks.filter((b) => b.kind === "ayah");
	const duas = bookmarks.filter((b) => b.kind === "dua");
	if (!meta || !ar || !hisn) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spinner, {});
	if (!bookmarks.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: t("emptyBookmarks") });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-medium",
				children: t("bookmarks")
			}),
			ayahs.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
				className: "mb-2",
				children: t("bookmarksAyah")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2",
				children: ayahs.map((b) => {
					if (b.kind !== "ayah") return null;
					const s = meta[b.surah - 1];
					const text = ar[b.surah - 1]?.[b.ayah - 1] ?? "";
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/quran/$n",
						params: { n: String(b.surah) },
						search: { ayah: b.ayah },
						className: "block rounded-[16px] border border-border bg-surface p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted",
							children: [
								s ? surahDisplayName(s, lang) : b.surah,
								" · ",
								t("ayah"),
								" ",
								formatNumber(b.ayah, lang)
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-quran mt-1 line-clamp-3",
							dir: "rtl",
							children: text
						})]
					}) }, `a-${b.surah}-${b.ayah}`);
				})
			})] }) : null,
			duas.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
				className: "mb-2",
				children: t("bookmarksDua")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-2",
				children: duas.map((b) => {
					if (b.kind !== "dua") return null;
					const item = hisn.find((x) => x.id === b.id);
					const title = item ? lang === "ku" ? item.ku : lang === "ar" ? item.ar : item.en : b.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/duas/$id",
						params: { id: b.id },
						className: "block rounded-[16px] border border-border bg-surface p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium",
							children: title
						}), item?.texts[0] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-quran mt-1 line-clamp-2 text-sm",
							dir: "rtl",
							children: item.texts[0]
						}) : null]
					}) }, b.id);
				})
			})] }) : null
		]
	});
}
//#endregion
export { BookmarksPage as component };
