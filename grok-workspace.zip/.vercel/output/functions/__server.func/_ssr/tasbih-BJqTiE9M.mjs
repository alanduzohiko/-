import { w as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { D as useAppStore, S as formatNumber, T as useT, f as Chip, u as Button } from "./router-YxvWRw5J.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tasbih-BJqTiE9M.js
var import_jsx_runtime = require_jsx_runtime();
var TARGETS = [
	33,
	99,
	100
];
function TasbihPage() {
	const { t, lang } = useT();
	const count = useAppStore((s) => s.tasbihCount);
	const target = useAppStore((s) => s.tasbihTarget);
	const bump = useAppStore((s) => s.bumpTasbih);
	const reset = useAppStore((s) => s.resetTasbih);
	const setTarget = useAppStore((s) => s.setTasbihTarget);
	const round = Math.floor(count / target);
	const inRound = count % target;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-[70vh] flex-col items-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "self-start text-2xl font-medium",
				children: t("tasbih")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 flex gap-2",
				children: TARGETS.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, {
					active: target === n,
					onClick: () => setTarget(n),
					children: formatNumber(n, lang)
				}, n))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => {
					bump();
					if ((count + 1) % target === 0) toast.success(t("roundComplete"));
				},
				className: "tasbih-btn mt-10 flex size-56 flex-col items-center justify-center rounded-full border border-border-strong bg-surface text-fg shadow-soft",
				"aria-label": t("tapToCount"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "tabular-nums text-6xl font-medium tracking-tight",
					children: formatNumber(inRound, lang)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "mt-2 text-sm text-muted",
					children: [
						t("of"),
						" ",
						formatNumber(target, lang)
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-6 text-sm text-muted",
				children: [
					t("progress"),
					": ",
					formatNumber(count, lang),
					" · ",
					t("roundComplete"),
					" ",
					formatNumber(round, lang)
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				className: "mt-6",
				onClick: reset,
				children: t("tasbihReset")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-8 max-w-xs text-center text-sm text-faint",
				children: t("tapToCount")
			})
		]
	});
}
//#endregion
export { TasbihPage as component };
