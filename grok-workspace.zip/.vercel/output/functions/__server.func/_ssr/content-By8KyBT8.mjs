//#region node_modules/.nitro/vite/services/ssr/assets/content-By8KyBT8.js
var daily = null;
var hisn = null;
async function loadJson(path) {
	const res = await fetch(path);
	if (!res.ok) throw new Error(`Failed ${path}`);
	return await res.json();
}
async function loadDaily() {
	if (daily) return daily;
	daily = await loadJson("/data/adhkar-daily.json");
	return daily;
}
async function loadHisn() {
	if (hisn) return hisn;
	hisn = await loadJson("/data/hisn.json");
	return hisn;
}
function filterDaily(items, which) {
	return items.filter((x) => x.type === 0 || (which === "morning" ? x.type === 1 : x.type === 2));
}
var FEATURED_HISN = [
	{
		key: "afterPrayer",
		ar: "الأذكار بعد السلام من الصلاة"
	},
	{
		key: "sleepAdhkar",
		ar: "أذكار النوم"
	},
	{
		key: "wakeAdhkar",
		ar: "أذكار الاستيقاظ من النوم"
	}
];
//#endregion
export { loadHisn as i, filterDaily as n, loadDaily as r, FEATURED_HISN as t };
