import { i as __toESM } from "../_runtime.mjs";
import { X as require_react, w as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { v as ChevronRight, y as ChevronLeft } from "../_libs/lucide-react.mjs";
import { C as isRtl, D as useAppStore, S as formatNumber, T as useT, d as Card, g as Spinner, i as Route$2, j as cn, u as Button } from "./router-YxvWRw5J.mjs";
import { i as loadHisn, n as filterDaily, r as loadDaily, t as FEATURED_HISN } from "./content-By8KyBT8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/adhkar._id-CI0MLDJK.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AdhkarDetail() {
	const { id } = Route$2.useParams();
	const { t, lang } = useT();
	const progress = useAppStore((s) => s.adhkarProgress);
	const setProgress = useAppStore((s) => s.setAdhkarProgress);
	const reset = useAppStore((s) => s.resetAdhkarProgress);
	const [daily, setDaily] = (0, import_react.useState)(null);
	const [hisn, setHisn] = (0, import_react.useState)(void 0);
	(0, import_react.useEffect)(() => {
		if (id === "morning" || id === "evening") loadDaily().then(setDaily);
		else {
			const map = {
				after: FEATURED_HISN[0].ar,
				sleep: FEATURED_HISN[1].ar,
				wake: FEATURED_HISN[2].ar
			};
			loadHisn().then((list) => {
				const title = map[id];
				setHisn(title ? list.find((x) => x.ar === title) ?? null : list.find((x) => x.id === id) ?? null);
			});
		}
	}, [id]);
	const items = (0, import_react.useMemo)(() => {
		if (!daily) return [];
		if (id === "morning") return filterDaily(daily, "morning");
		if (id === "evening") return filterDaily(daily, "evening");
		return [];
	}, [daily, id]);
	const title = id === "morning" ? t("morningAdhkar") : id === "evening" ? t("eveningAdhkar") : id === "after" ? t("afterPrayer") : id === "sleep" ? t("sleepAdhkar") : id === "wake" ? t("wakeAdhkar") : hisn ? lang === "ku" ? hisn.ku : lang === "ar" ? hisn.ar : hisn.en : t("adhkar");
	const ids = items.map((x) => x.id);
	const rtl = isRtl(lang);
	if ((id === "morning" || id === "evening") && !daily) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spinner, {});
	if (id !== "morning" && id !== "evening" && hisn === void 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spinner, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/adhkar",
				className: "inline-flex size-11 items-center justify-center",
				"aria-label": t("back"),
				children: rtl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-xl font-medium",
				children: title
			})]
		}), items.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "outline",
			className: "w-full",
			onClick: () => reset(ids),
			children: t("resetProgress")
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "space-y-3",
			children: items.map((item) => {
				const done = progress[item.id] ?? 0;
				const target = item.count || 1;
				const complete = done >= target;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: cn("p-4", complete && "opacity-70"),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-quran text-xl",
							dir: "rtl",
							children: item.ar
						}),
						lang !== "ar" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm leading-relaxed text-muted",
							children: lang === "ku" ? item.ku : item.en
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-faint",
								children: [
									t("repeat"),
									": ",
									lang === "ku" ? item.countKu : lang === "ar" ? item.countAr : item.countEn
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setProgress(item.id, complete ? 0 : done + 1),
								className: "min-h-11 min-w-24 rounded-full bg-accent px-4 text-sm font-medium text-accent-fg",
								children: complete ? t("completed") : `${formatNumber(done, lang)} / ${formatNumber(target, lang)}`
							})]
						}),
						item.sourceAr ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-xs text-faint",
							children: [
								t("source"),
								": ",
								lang === "en" ? item.sourceEn || item.sourceAr : item.sourceAr
							]
						}) : null
					]
				}) }, item.id);
			})
		})] }) : hisn ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HisnView, { item: hisn }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: t("nothingHere")
		})]
	});
}
function HisnView({ item }) {
	const { t, lang } = useT();
	const saved = useAppStore((s) => s.isBookmarked({
		kind: "dua",
		id: item.id
	}));
	const toggle = useAppStore((s) => s.toggleBookmark);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				className: "w-full",
				onClick: () => toggle({
					kind: "dua",
					id: item.id
				}),
				children: saved ? t("removeBookmark") : t("addBookmark")
			}),
			item.texts.map((text, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-quran text-xl leading-loose",
					dir: "rtl",
					children: text
				})
			}, i)),
			item.notes.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted",
					children: t("notes")
				}), item.notes.map((n, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm leading-relaxed text-muted",
					dir: "rtl",
					children: n
				}, i))]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-faint",
				children: lang === "ku" ? item.ku : lang === "en" ? item.en : item.ar
			})
		]
	});
}
//#endregion
export { AdhkarDetail as component };
