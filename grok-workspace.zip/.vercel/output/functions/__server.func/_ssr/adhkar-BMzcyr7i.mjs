import { w as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Sunrise, r as Sun, s as ScrollText, u as Moon } from "../_libs/lucide-react.mjs";
import { T as useT, d as Card, h as SectionTitle } from "./router-YxvWRw5J.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/adhkar-BMzcyr7i.js
var import_jsx_runtime = require_jsx_runtime();
function AdhkarHome() {
	const { t } = useT();
	const items = [
		{
			to: "/adhkar/morning",
			label: t("morningAdhkar"),
			icon: Sun,
			hint: t("morning")
		},
		{
			to: "/adhkar/evening",
			label: t("eveningAdhkar"),
			icon: Moon,
			hint: t("evening")
		},
		{
			to: "/adhkar/after",
			label: t("afterPrayer"),
			icon: Sunrise,
			hint: t("afterPrayerShort")
		},
		{
			to: "/adhkar/sleep",
			label: t("sleepAdhkar"),
			icon: Moon,
			hint: t("night")
		},
		{
			to: "/adhkar/wake",
			label: t("wakeAdhkar"),
			icon: Sunrise,
			hint: t("morning")
		},
		{
			to: "/duas",
			label: t("fortress"),
			icon: ScrollText,
			hint: t("allCategories")
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-medium",
				children: t("adhkar")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: t("collections")
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3",
				children: items.map((it) => {
					const Icon = it.icon;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: it.to,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
							className: "flex items-center gap-4 p-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex size-11 items-center justify-center rounded-[12px] bg-surface-2 text-accent",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block font-medium",
									children: it.label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-xs text-muted",
									children: it.hint
								})]
							})]
						})
					}, it.to);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: t("tasbih") }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/tasbih",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
					className: "p-4 font-medium",
					children: t("tasbih")
				})
			})
		]
	});
}
//#endregion
export { AdhkarHome as component };
