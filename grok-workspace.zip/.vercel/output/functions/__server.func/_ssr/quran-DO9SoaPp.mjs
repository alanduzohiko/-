//#region node_modules/.nitro/vite/services/ssr/assets/quran-DO9SoaPp.js
var cache = {
	meta: null,
	ar: null,
	ku: null,
	en: null
};
async function loadJson(path) {
	const res = await fetch(path);
	if (!res.ok) throw new Error(`Failed ${path}`);
	return await res.json();
}
async function loadMeta() {
	if (cache.meta) return cache.meta;
	cache.meta = (await loadJson("/data/quran-meta.json")).surahs;
	return cache.meta;
}
async function loadArabic() {
	if (cache.ar) return cache.ar;
	cache.ar = await loadJson("/data/quran-ar.json");
	return cache.ar;
}
async function loadKu() {
	if (cache.ku) return cache.ku;
	cache.ku = await loadJson("/data/quran-ku.json");
	return cache.ku;
}
async function loadEn() {
	if (cache.en) return cache.en;
	cache.en = await loadJson("/data/quran-en.json");
	return cache.en;
}
function globalAyahIndex(surah, ayah, meta) {
	let n = 0;
	for (const s of meta) if (s.n < surah) n += s.ayahs;
	return n + ayah;
}
function reciterAudioUrl(reciter, globalIndex) {
	return `https://cdn.islamic.network/quran/audio/128/${reciter}/${globalIndex}.mp3`;
}
function surahDisplayName(s, lang) {
	if (lang === "ku") return s.ku;
	if (lang === "ar") return s.ar.replace(/^سُورَةُ\s*/, "");
	return s.en;
}
//#endregion
export { loadMeta as a, loadKu as i, loadArabic as n, reciterAudioUrl as o, loadEn as r, surahDisplayName as s, globalAyahIndex as t };
