import { i as __toESM } from "../_runtime.mjs";
import { X as require_react, w as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { S as BookOpen, g as Compass, m as Hash, r as Sun, s as ScrollText, u as Moon } from "../_libs/lucide-react.mjs";
import { A as t, D as useAppStore, E as getActiveCoords, T as useT, b as formatGregorian, c as nextPrayer, d as Card, h as SectionTitle, o as computePrayerTimes, v as formatClock, w as weekdayName, x as formatHijri, y as formatDuration } from "./router-YxvWRw5J.mjs";
import { a as loadMeta, n as loadArabic, s as surahDisplayName } from "./quran-DO9SoaPp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-ConfmVzX.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PRAYER_KEYS = {
	fajr: "fajr",
	dhuhr: "dhuhr",
	asr: "asr",
	maghrib: "maghrib",
	isha: "isha"
};
function Home() {
	const { t: t$1, lang } = useT();
	const method = useAppStore((s) => s.method);
	const madhab = useAppStore((s) => s.madhab);
	const lastRead = useAppStore((s) => s.lastRead);
	const coords = getActiveCoords();
	const [now, setNow] = (0, import_react.useState)(() => /* @__PURE__ */ new Date());
	const [verse, setVerse] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const id = setInterval(() => setNow(/* @__PURE__ */ new Date()), 3e4);
		return () => clearInterval(id);
	}, []);
	const times = (0, import_react.useMemo)(() => computePrayerTimes(coords.lat, coords.lng, now, method, madhab), [
		coords.lat,
		coords.lng,
		method,
		madhab,
		now
	]);
	const upcoming = nextPrayer(times, now) ?? {
		id: "fajr",
		at: times.fajr
	};
	(0, import_react.useEffect)(() => {
		let alive = true;
		(async () => {
			const [meta, ar] = await Promise.all([loadMeta(), loadArabic()]);
			const day = Math.floor(Date.now() / 864e5);
			const s = meta[day % meta.length];
			const ayah = day % s.ayahs + 1;
			if (!alive) return;
			setVerse({
				n: s.n,
				ayah,
				ar: ar[s.n - 1]?.[ayah - 1] ?? "",
				name: surahDisplayName(s, lang)
			});
		})();
		return () => {
			alive = false;
		};
	}, [lang]);
	const cityLabel = lang === "ku" ? coords.labelKu : lang === "ar" ? coords.labelAr : coords.labelEn;
	const remain = upcoming.at.getTime() - now.getTime();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5 rise",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						weekdayName(now, lang),
						" · ",
						cityLabel
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 text-2xl font-medium tracking-tight",
					children: t$1("appName")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: formatHijri(now, lang)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-faint",
					children: formatGregorian(now, lang)
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: t$1("nextPrayer") }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex items-end justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-3xl font-medium tracking-tight",
							children: t$1(PRAYER_KEYS[upcoming.id === "sunrise" ? "fajr" : upcoming.id])
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 tabular-nums text-muted",
							children: formatClock(upcoming.at, lang)
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-end",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-faint",
								children: t$1("remaining")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "tabular-nums text-accent",
								children: formatDuration(remain, lang, (k) => t$1(k))
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/prayer",
						className: "mt-4 inline-flex text-sm text-accent",
						children: t$1("todayTimes")
					})
				]
			}),
			lastRead ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/quran/$n",
				params: { n: String(lastRead.surah) },
				search: { ayah: lastRead.ayah },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "flex items-center justify-between p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: t$1("continueReading") }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm",
						children: [
							t$1("surah"),
							" ",
							lastRead.surah,
							" · ",
							t$1("ayah"),
							" ",
							lastRead.ayah
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "size-5 text-muted" })]
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, {
				className: "mb-3",
				children: t$1("quickActions")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quick, {
						to: "/adhkar/morning",
						label: t$1("morningAdhkar"),
						icon: Sun
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quick, {
						to: "/adhkar/evening",
						label: t$1("eveningAdhkar"),
						icon: Moon
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quick, {
						to: "/quran",
						label: t$1("readQuran"),
						icon: BookOpen
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quick, {
						to: "/qibla",
						label: t$1("qibla"),
						icon: Compass
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quick, {
						to: "/duas",
						label: t$1("fortress"),
						icon: ScrollText
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quick, {
						to: "/tasbih",
						label: t$1("tasbih"),
						icon: Hash
					})
				]
			})] }),
			verse ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/quran/$n",
				params: { n: String(verse.n) },
				search: { ayah: verse.ayah },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
					className: "p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTitle, { children: t$1("verseOfMoment") }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-quran mt-3 text-xl leading-loose",
							dir: "rtl",
							children: verse.ar
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-sm text-muted",
							children: [
								verse.name,
								" · ",
								t(lang, "ayah"),
								" ",
								verse.ayah
							]
						})
					]
				})
			}) : null
		]
	});
}
function Quick({ to, label, icon: Icon }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		className: "flex min-h-[88px] flex-col justify-between rounded-[20px] border border-border bg-surface p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
			className: "size-5 text-accent",
			strokeWidth: 1.75
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-sm font-medium",
			children: label
		})]
	});
}
//#endregion
export { Home as component };
