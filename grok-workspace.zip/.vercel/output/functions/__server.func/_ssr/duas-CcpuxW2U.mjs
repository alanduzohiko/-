import { i as __toESM } from "../_runtime.mjs";
import { X as require_react, w as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { S as formatNumber, T as useT, g as Spinner, m as Input } from "./router-YxvWRw5J.mjs";
import { i as loadHisn } from "./content-By8KyBT8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/duas-CcpuxW2U.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function DuasPage() {
	const { t, lang } = useT();
	const [list, setList] = (0, import_react.useState)(null);
	const [q, setQ] = (0, import_react.useState)("");
	const [err, setErr] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		loadHisn().then(setList).catch(() => setErr(true));
	}, []);
	const filtered = (0, import_react.useMemo)(() => {
		if (!list) return [];
		const s = q.trim().toLowerCase();
		if (!s) return list.filter((x) => x.id !== "h001");
		return list.filter((x) => x.ku.includes(q) || x.ar.includes(q) || x.en.toLowerCase().includes(s) || x.texts.some((tx) => tx.includes(q)));
	}, [list, q]);
	if (err) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children: t("loadError")
	});
	if (!list) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spinner, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-medium",
				children: t("fortress")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: t("duas")
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value: q,
				onChange: (e) => setQ(e.target.value),
				placeholder: t("searchDuas")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "divide-y divide-border overflow-hidden rounded-[24px] border border-border bg-surface",
				children: filtered.map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/duas/$id",
					params: { id: item.id },
					className: "flex items-center gap-3 px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "w-8 tabular-nums text-sm text-muted",
						children: formatNumber(i + 1, lang)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-medium",
							children: lang === "ku" ? item.ku : lang === "ar" ? item.ar : item.en
						}), lang !== "ar" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block truncate text-xs text-muted",
							dir: "rtl",
							children: item.ar
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block truncate text-xs text-muted",
							children: item.en
						})]
					})]
				}) }, item.id))
			}),
			!filtered.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: t("noResults")
			}) : null
		]
	});
}
//#endregion
export { DuasPage as component };
