import { i as __toESM } from "../_runtime.mjs";
import { X as require_react, w as require_jsx_runtime, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { D as useAppStore, S as formatNumber, T as useT, g as Spinner, m as Input } from "./router-YxvWRw5J.mjs";
import { a as loadMeta, s as surahDisplayName } from "./quran-DO9SoaPp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/quran-DLSZR0ix.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function QuranList() {
	const { t, lang } = useT();
	const lastRead = useAppStore((s) => s.lastRead);
	const [meta, setMeta] = (0, import_react.useState)(null);
	const [q, setQ] = (0, import_react.useState)("");
	const [err, setErr] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		loadMeta().then(setMeta).catch(() => setErr(true));
	}, []);
	const filtered = (0, import_react.useMemo)(() => {
		if (!meta) return [];
		const s = q.trim().toLowerCase();
		if (!s) return meta;
		return meta.filter((x) => x.ku.includes(q) || x.ar.includes(q) || x.en.toLowerCase().includes(s) || String(x.n) === s);
	}, [meta, q]);
	if (err) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted",
		children: t("loadError")
	});
	if (!meta) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spinner, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-2xl font-medium",
				children: t("quran")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: t("preserveNote")
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value: q,
				onChange: (e) => setQ(e.target.value),
				placeholder: t("searchQuran"),
				"aria-label": t("searchQuran")
			}),
			lastRead ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/quran/$n",
				params: { n: String(lastRead.surah) },
				search: { ayah: lastRead.ayah },
				className: "block rounded-[16px] border border-border bg-surface-2 px-4 py-3 text-sm",
				children: [
					t("continueReading"),
					" · ",
					t("surah"),
					" ",
					formatNumber(lastRead.surah, lang),
					" · ",
					t("ayah"),
					" ",
					formatNumber(lastRead.ayah, lang)
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "divide-y divide-border overflow-hidden rounded-[24px] border border-border bg-surface",
				children: filtered.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/quran/$n",
					params: { n: String(s.n) },
					className: "flex items-center gap-3 px-4 py-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex size-10 shrink-0 items-center justify-center rounded-[12px] bg-surface-2 tabular-nums text-sm text-muted",
							children: formatNumber(s.n, lang)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "block font-medium",
								children: surahDisplayName(s, lang)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "block text-xs text-muted",
								children: [
									lang === "en" ? s.enMean : s.ar.replace(/^سُورَةُ\s*/, ""),
									" · ",
									formatNumber(s.ayahs, lang),
									" ",
									t("ayahs"),
									" · ",
									s.rev === "M" ? t("meccan") : t("medinan")
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-quran text-lg text-accent",
							dir: "rtl",
							children: s.ar.replace(/^سُورَةُ\s*/, "")
						})
					]
				}) }, s.n))
			})
		]
	});
}
//#endregion
export { QuranList as component };
