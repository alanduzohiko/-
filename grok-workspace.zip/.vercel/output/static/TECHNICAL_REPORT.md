# Technical report — Mihrab (میحراب)

## Identity

| Field | Value |
|---|---|
| Application name | میحراب / Mihrab |
| Package / app id | standalone web app (not the original Android package) |
| Version | 1.0.0 |
| Framework | TanStack Start + React 19 |
| Build method | Vite production build |
| Minimum client | Android 11 browser / Chrome 90+ (and modern desktop) |
| Target | Current evergreen browsers |
| Android 11 compatible | Yes, as an installable web app (Add to Home screen) |

## Original APKs

The uploaded files were referenced as:

- `PRIMARY_APP.apk` (~117 MB)
- `REFERENCE_KURDISH_APP.apk` (~102 MB)

They were **not extractable** in this environment (`Binary file, content not extracted`). There is no Android SDK, apktool, or signing key here, so the original APK could not be decompiled, rebuilt, or re-signed.

A **standalone replacement** was built instead. It does **not** impersonate the original package name, signing certificate, ads, or tracking.

## Original package / signing

| Question | Answer |
|---|---|
| Original package name preserved? | No — original APK not available |
| Original signing identity preserved? | No |
| Can this update the original app? | No. Uninstall is not relevant; this is a new app |
| Native APK delivered? | Not possible without the original binary and an Android build toolchain |

## Features reproduced

- Quran reader (114 surahs, 6236 ayahs, Hafs Uthmani Arabic)
- Optional Kurdish and English meanings
- Recitation via streaming (Alafasy, Husary, Minshawi) — needs network
- Prayer times (adhan-js, several calculation methods, Hanafi/Shafi asr)
- Qibla bearing
- Morning / evening adhkar with counters
- Hisn al-Muslim (Fortress of the Muslim) in 134 sections
- Tasbih
- 99 Names of Allah
- Search across Quran, duas, names
- Bookmarks
- Language: Sorani Kurdish, Arabic, English
- RTL for Kurdish and Arabic
- Theme, font size, city / GPS, notifications
- Offline text after first load; audio remains online-only

## Features that could not be copied from the original

- Original branding, package name, and signing key
- Any proprietary audio packs bundled inside the APKs
- Original private APIs, encrypted databases, or licensed recitation files
- A sideloadable `.apk` binary (no Android SDK in this environment)

## Tests performed

- Data pipeline: 114 surahs, 6236 Arabic ayahs, Kurdish + English editions
- Hisn: 134 categories, all titles translated to Sorani and English
- Daily adhkar: 34 items with Sorani meanings
- Typecheck and production build (see session logs)
- Browser smoke on desktop and mobile viewports
- Manual UI pass: onboarding language, RTL, Quran Arabic, prayer times, adhkar counters, search, settings persistence

## Known limitations

- Recitation requires internet (CDN).
- Prayer notifications only fire while the app/browser is open, after permission.
- Device compass for qibla depends on browser support.
- This is not an update over the original Play/sideload APK.
